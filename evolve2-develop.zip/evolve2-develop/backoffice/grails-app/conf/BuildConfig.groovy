grails.servlet.version = "3.0" // Change depending on target container compliance (2.5 or 3.0)
grails.project.class.dir = "target/classes"
grails.project.test.class.dir = "target/test-classes"
grails.project.test.reports.dir = "target/test-reports"
grails.project.work.dir = "target/work"
grails.project.target.level = 1.8
grails.project.source.level = 1.8
grails.server.port.http = 8080
grails.server.port.https = 8443
//grails.project.war.file = "target/${appName}-${appVersion}.war"

grails.project.fork = [
    // configure settings for the test-app JVM, uses the daemon by default
    test: [maxMemory: 768, minMemory: 64, debug: false, maxPerm: 256, daemon:true],
//    test:false,
    // configure settings for the run-app JVM
    run: [maxMemory: 768, minMemory: 64, debug: false, maxPerm: 256, forkReserve:false],
//    run:false,
    // configure settings for the run-war JVM
    war: [maxMemory: 768, minMemory: 64, debug: false, maxPerm: 256, forkReserve:false],
    // configure settings for the Console UI JVM
    console: [maxMemory: 768, minMemory: 64, debug: false, maxPerm: 256]
]

grails.project.dependency.resolver = "maven" // or ivy
grails.project.dependency.resolution = {
    // inherit Grails' default dependencies
    inherits("global") {
        // specify dependency exclusions here; for example, uncomment this to disable ehcache:
        // excludes 'ehcache'
        excludes 'xercesImpl'
    }
    log "error" // log level of Ivy resolver, either 'error', 'warn', 'info', 'debug' or 'verbose'
    checksums true // Whether to verify checksums on resolve
    legacyResolve false // whether to do a secondary resolve on plugin installation, not advised and here for backwards compatibility

    repositories {
        inherits true // Whether to inherit repository definitions from plugins

        grailsPlugins()
        grailsHome()
        mavenLocal()
        grailsCentral()
        mavenCentral()
        mavenRepo "http://repo.spring.io/milestone"
        mavenRepo "http://repo1.maven.org/maven2/"
		mavenRepo "http://repo.grails.org/grails/core"
    }

    dependencies {
        // specify dependencies here under either 'build', 'compile', 'runtime', 'test' or 'provided' scopes e.g.
        // runtime 'mysql:mysql-connector-java:5.1.29'
        // runtime 'org.postgresql:postgresql:9.3-1101-jdbc41'
        test "org.grails:grails-datastore-test-support:1.0.2-grails-2.4"
		compile 'commons-beanutils:commons-beanutils:1.8.3'
        runtime 'mysql:mysql-connector-java:5.1.34'
        compile 'com.maxmind.geoip2:geoip2:2.7.0'
        compile 'org.apache.httpcomponents:httpclient:4.5.2'
        //compile "com.mashape.unirest:unirest-java:1.4.9"
        //compile 'com.cronutils:cron-utils:6.0.2'
		
    }

    plugins {
        // plugins for the build system only
        build ":tomcat:8.0.20"

        // plugins for the compile step
        compile ":scaffolding:2.1.2"
        compile ':cache:1.1.8'
        compile ":asset-pipeline:2.1.1"
        compile ":spring-security-core:2.0-RC4"
        compile ":quartz:1.0.2"
        // plugins outside the Grails core
        compile ":excel-export:0.2.1"
		compile "org.grails.plugins:export:1.6"
		
		compile ":csv:0.3.1"
        compile "org.grails.plugins:wslite:0.7.2.0"
        compile "org.grails.plugins:remote-pagination:0.4.8"
		
        // plugins needed at runtime but not for compilation
        runtime ":hibernate4:4.3.8.1" // or ":hibernate:3.6.10.18"
        runtime ":database-migration:1.4.0"

        // This is just used by the API, if we extract the API, we can remove this.
        runtime ":cors:1.1.6"
        runtime "org.grails.plugins:jquery:1.11.1"
    }
}

grails.plugin.location.coreservices = "../coreservices"
grails.plugin.location.reporting = "../reporting"
grails.plugin.location.sightline = "../sightline"
grails.plugin.location.messaging = "../messages"
grails.plugin.location.bonus = "../bonus"
grails.plugin.location.payments = "../payments"
grails.plugin.location.promotion = "../promotion"
grails.plugin.location.notifications = "../notifications"
//grails.plugin.location.jackpot = "../jackpot"
// SWH, commented this out so production builds dont get content manaagment code by accident.  Comment back in when we start developing/using it again.
//    grails.plugin.location.contentmanagement = "../contentmanagement"


