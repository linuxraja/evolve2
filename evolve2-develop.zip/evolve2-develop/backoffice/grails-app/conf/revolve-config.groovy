// copy this file to $home/.grails/
// or set an environtment variable revolve.config.location with its path
grails.plugin.databasemigration.updateOnStartContexts = ['UK']
evolve2.mode="UK" // "US" or "UK"
grails.plugin.databasemigration.updateOnStartFileNames = ['changelog.xml']
grails.plugin.databasemigration.updateOnStart = true