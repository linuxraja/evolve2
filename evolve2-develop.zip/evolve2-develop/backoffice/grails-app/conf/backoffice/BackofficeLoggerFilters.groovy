package backoffice

import org.apache.log4j.MDC

class BackofficeLoggerFilters {

    /**
     * Please note after interceptors will not work if response from controller is render text or other
     * works like a charm if model and view is returned/rendered.
     *
     * before interceptor has no issues so logger id is generated and prefixed in logs from controller to domain layers
     * So the total time calculation of HTTP Request-Response processing time cannot be calculated if rendered text or other,
     * for that we should define an afterinterceptor in each controller and calculate time and log in respective controllers.
     * eg in quickFireServerController of games connect
     *
     * Sinice almost all controller action returns a view or modal so no issues in backoffice !!!
     */
    def filters = {
        all(controller:'*', action:'*') {
            long start = System.currentTimeMillis()
            before = {
                MDC.put 'backOfficeLoggerId', UUID.randomUUID().toString()
            }
            after = {Map model ->
                //log.debug "<- ${MDC.get("backOfficeLoggerId")} Backoffice Filter - Total Time Taken to complete the request is ${(System.currentTimeMillis()) - start} MS"
                log.debug "<- Backoffice Filter - Total Time Taken to complete the request is ${(System.currentTimeMillis()) - start} MS"
            }
            afterView = {Exception e ->
                if(e){
                   // log.debug "<- ${MDC.get("backOfficeLoggerId")} Backoffice VIEW EXCEPTION Filter - Total Time Taken to complete the request is ${(System.currentTimeMillis()) - start} MS"
                    log.debug "<- Backoffice VIEW EXCEPTION Filter - Total Time Taken to complete the request is ${(System.currentTimeMillis()) - start} MS"
                }else {
                    //log.debug "<- ${MDC.get("backOfficeLoggerId")} Backoffice VIEW Filter - Total Time Taken to complete the request is ${(System.currentTimeMillis()) - start} MS"
                    log.debug "<- Backoffice VIEW Filter - Total Time Taken to complete the request is ${(System.currentTimeMillis()) - start} MS"
                }
            }
        }
    }
}
