package backoffice
import com.nektan.revolve.extras.Utils
import org.apache.log4j.MDC


class IpFilters  {

    def filters = {

        all() {
            before = {
                String ip = Utils.getIP(request)
                MDC.put "IP", ip
            }

            after = { Map model ->
            }

            afterView = { Exception e ->
               MDC.remove 'IP'
            } // afterView()
        }
    } // filters


}
