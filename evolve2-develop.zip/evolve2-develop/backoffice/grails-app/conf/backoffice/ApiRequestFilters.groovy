package backoffice

import com.nektan.revolve.api.EvolveConstants
import com.nektan.revolve.api.evolve1.PlayerController

import javax.servlet.http.Cookie
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse
import java.util.concurrent.atomic.AtomicLong
import org.apache.log4j.MDC

class ApiRequestFilters implements EvolveConstants {

    private static final AtomicLong REQUEST_NUMBER_COUNTER = new AtomicLong()
    private static final String START_TIME_ATTRIBUTE = 'Controller__START_TIME__'
    private static final String REQUEST_NUMBER_ATTRIBUTE = 'Controller__REQUEST_NUMBER__'

    def paramService

    boolean logToken = false
    boolean logPath = false
    boolean logResponseModel = false

    def filters = {

        all( namespace: 'evolve1|v1|payments' ) {

			before = {

                long start = System.currentTimeMillis()
                long currentRequestNumber = REQUEST_NUMBER_COUNTER.incrementAndGet()

                String token = ""
                String reallyTheToken = null
                checkRequest(request,response)
                reallyTheToken = request.cookies.find { it.name == cookieSessionCorrelation }?.value  // TODO: Heiko check if this is correct as it is null for v1 at least.
                if (reallyTheToken == null) {
                    reallyTheToken = request.cookies.find { it.name == cookieSessionCorrelation }?.value
                }
                token += "$EvolveConstants.cookieSessionCorrelation=$reallyTheToken "

                String reallyTheRequestCorrelationId = request.getHeader("requestCorrelationId")
                reallyTheRequestCorrelationId = reallyTheRequestCorrelationId ? reallyTheRequestCorrelationId : currentRequestNumber

				String userCorrelation = request.cookies.find { it.name == cookieUserCorrelation }?.value
				if ( userCorrelation ) {
					token += "${cookieUserCorrelation}=$userCorrelation "
				}

				token += "requestCorrelationId=$reallyTheRequestCorrelationId "


				if (reallyTheToken != null) {
                    MDC.put "correlationData", token
                }

                request[START_TIME_ATTRIBUTE] = start
                request[REQUEST_NUMBER_ATTRIBUTE] = currentRequestNumber

                log.debug "-> /$controllerName/$actionName/ Params: ${params.fields?.tokenize(',')} "
            }

            after = { Map model ->

                long start = request[START_TIME_ATTRIBUTE]
                long end = System.currentTimeMillis()
                long requestNumber = request[REQUEST_NUMBER_ATTRIBUTE]

                String token = ""

                log.debug "<- ${controllerName}/${actionName}/ responseStatus=$response.status ms=${end - start}"
            }

            afterView = { Exception e ->

                if ( e ) {

                    String token = ""
                    checkRequest(request,response)
                    token += "$EvolveConstants.cookieSessionCorrelation=${request.cookies.find { it.name == cookieSessionCorrelation }?.value} "
                    token += "requestCorrelationId=${request.getHeader("requestCorrelationId")} "

                    long start = request[START_TIME_ATTRIBUTE]
                    long end = System.currentTimeMillis()
                    long requestNumber = request[REQUEST_NUMBER_ATTRIBUTE]

                    log.fatal "<- /${controllerName}/${actionName}/ responseStatus=$response.status ms=${end - start}"
                    log.fatal "EXCEPTION $e"
                    log.fatal "EXCEPTION ${e.printStackTrace()}"
                } // if (e)

                if (MDC.get('correlationData') != null) {
                    MDC.remove 'correlationData'
                }

            } // afterView()
        }
    }



    /**
     * Check for missing headers and session tokens and create them if not already set
     * @param request
     * @param response
     */
    void checkRequest(HttpServletRequest request, HttpServletResponse response) {
        Cookie cookie
        response.setHeader('X-Frame-Options','DENY')

        if ( request.getHeader(HEADER_SESSION_CORRELATION_ID) == null ) {
            cookie = request.cookies.find { it.name == cookieSessionCorrelation }
            if ( cookie ) {
                response.setHeader( HEADER_SESSION_CORRELATION_ID, cookie.value )
            } else {
                String sessionid = UUID.randomUUID().toString()
                /*cookie = new Cookie( EvolveConstants.cookieSessionCorrelation, sessionid)
                cookie.setPath("/")
                cookie.setMaxAge(1800)
                response.addCookie(cookie)*/
                response.setHeader( HEADER_SESSION_CORRELATION_ID, sessionid )
            }
        }

        if ( request.getHeader(HEADER_REQUEST_CORRELATION_ID) == null ) {
            String sessionid = UUID.randomUUID().toString()
            response.setHeader( HEADER_REQUEST_CORRELATION_ID, sessionid )
        }
    }
}
