import com.nektan.revolve.backoffice.RevolveUserDetailService
import com.nektan.revolve.backoffice.CustomTimeoutSessionListener
import com.nektan.revolve.backoffice.OperatorAuthenticationSuccessEventListener
import com.nektan.revolve.backoffice.OperatorAuthenticationFailureBadCredentialsEventListener
import com.nektan.revolve.backoffice.MySecurityEventListener

beans = {
	userDetailsService(RevolveUserDetailService)

	customTimeoutSessionListener(CustomTimeoutSessionListener) {
		paramService = ref('paramService')
	}

	operatorAuthenticationSuccessEventListener(OperatorAuthenticationSuccessEventListener) {
		operatorService = ref('operatorService')
	}

	operatorAuthenticationFailureBadCredentialsEventListener(OperatorAuthenticationFailureBadCredentialsEventListener) {
		operatorService = ref('operatorService')
	}

	mySecurityEventListener(MySecurityEventListener)

	groovySql(groovy.sql.Sql, ref('dataSource'))
}

