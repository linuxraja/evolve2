import com.nektan.revolve.api.AccountTypes
import com.nektan.revolve.api.BonusRewardType
import com.nektan.revolve.api.BonusType
import com.nektan.revolve.api.PlayerRewardStatus
import com.nektan.revolve.backoffice.SessionJob
import com.nektan.revolve.backoffice.StatisticsJob
import com.nektan.revolve.coreservices.*
import com.nektan.revolve.services.PlayerService
import grails.converters.JSON
import grails.plugin.springsecurity.annotation.Secured
import java.text.DecimalFormat;
import java.net.URLEncoder
import java.net.URLDecoder
import org.codehaus.groovy.runtime.DateGroovyMethods
import java.text.DecimalFormat
import org.apache.commons.lang.StringUtils;


/**
 * This is the bootstrap for production use. Do not put any development bootstrapping here!
 *
 */
class BootStrap {

    def grailsApplication
    def dataSource
    def customTimeoutSessionListener
	def pluginService
	def paramService
    def transactionService
    def playerEventService

    def init = { servletContext ->


        // DONT REMOVE THIS DEFINITIONS!
        // THEY ADD TWO HELPER METHODS TO THE String-CLASS

        String.metaClass.encodeURL = {
            java.net.URLEncoder.encode(delegate)
        }

	    String.metaClass.decodeURL = {
		    java.net.URLDecoder.decode(delegate)
	    }

        String.metaClass.indexesOf = { match ->
            def ret = []
            def idx = -1
            while( ( idx = delegate.indexOf( match, idx + 1 ) ) > -1 ) {
                ret << idx
            }
            ret
        }


        log.info "Starting BootStrap"

        transactionService.addObserver(playerEventService)

        boolean isForUS = grailsApplication.config.evolve2.mode == "US"

        try {
            servletContext.addListener(customTimeoutSessionListener)
        } catch (UnsupportedOperationException e) {
            log.warn(e)
            // unit tests can ignore this
        }

        DecimalFormat df = new DecimalFormat("##0.00");
        JSON.registerObjectMarshaller(Account) {
            return [balance: df.format(it.balance), currency: it.currency.toString(), id: it.id, type: AccountTypes.DESCRIPTIONS[it.type]]
        }

        if (isForUS) {
            JSON.registerObjectMarshaller(SecurityQuestion) {
                return [id: it.id, question: it.question]
            }
        } else {
            JSON.registerObjectMarshaller(SecurityQuestion) {
                return [id: it.id, text: it.question]
            }
        }

        JSON.registerObjectMarshaller(Param) {
            return [key: it.paramKey, value: it.val]
        }

        def pattern = "#,##0.00"
        def currencyFormat = new DecimalFormat(pattern)

        JSON.registerObjectMarshaller(PlayerBonus) {
            return [
                    awardedDate: "${DateGroovyMethods.format(it.dateCreated, "EEE, dd MMM yyyy HH:mm:ss Z")}",
                    bonusAmount: "${currencyFormat.format(it.awardedAmount)}",
                    name: "${it.playerDescription}",
                    expireDate: "${DateGroovyMethods.format(it.expires, "EEE, dd MMM yyyy HH:mm:ss Z")}",
                    activationDate: "",
                    status: "${PlayerRewardStatus.getStatusType(it.status).name}",
                    allowedGames: "${(it.bonus.bonusType != BonusType.Manual.id && it.bonus.rewardType == BonusRewardType.BonusFunds.id && it.bonus.freeRoundsGameConfig != null ) ? it.bonus.freeRoundsGameConfig*.game.shortName : ''}"
            ]
        }

        JSON.createNamedConfig('gametransaction') {
            it.registerObjectMarshaller(Transaction) { Transaction transaction ->

                if ( transaction.debit == 0 && transaction.credit == 0 ) {
                    return null
                }

                String description = (null != transaction.game) ? transaction.game.name : transaction.description;

                if ( transaction.voidingTransaction != null ) {
                    description += " (cancelled)"
                }

                if ( transaction.voidedTransaction != null ) {
                    description = "Void game play: " + ((null != transaction.game) ? transaction.game.name : description);
                }

                return [
                        gamePlayStateId: transaction.id,
                        gameName: "${description}",
                        gameDate: "${DateGroovyMethods.format(transaction.createdAt, "EEE, dd MMM yyyy HH:mm:ss Z")}",
                        gamePayoutAmount: "${currencyFormat.format(transaction.credit)}",
                        gameStakeAmount: "${currencyFormat.format(transaction.debit)}",
                        gameCurrency: "${transaction.account.currency.iso}"
                ]
            }
        }

        JSON.createNamedConfig('jackpotwinningtransactions') {
            it.registerObjectMarshaller(Transaction) { Transaction transaction ->

                if ( transaction.debit == 0 && transaction.credit == 0 ) {
                    return null
                }

                String description = transaction.type.name;

                String gameName = (null != transaction.game) ? transaction.game.name : transaction.description;

                return [
                        transactionType    : "${description}",
                        gameName           : "${gameName}",
                        transactionCurrency: "${transaction.account.currency.iso}",
                        transactionReference: "${transaction.description}",
                        transactionAmount  : "${currencyFormat.format(transaction.credit)}",
                        transactionDate    : "${DateGroovyMethods.format(transaction.createdAt, "EEE, dd MMM yyyy HH:mm:ss Z")}"
                ]
            }
        }

        JSON.createNamedConfig('financialtransaction') {
            it.registerObjectMarshaller(TransactionView) { TransactionView transaction ->
                String description = transaction.type.shortName;

                if ( transaction.voidingTransaction != null ) {
                    description += " (cancelled)"
                }

                if ( transaction.voidedTransaction != null ) {
                    description = "Void "+transaction.type.shortName
                }

                return [
                        transactionType    : "${description}",
                        transactionCurrency: "${transaction.account.currency.iso}",
                        transactionReference: "${transaction.description}",
                        voucher            : "",
                        transactionAmount  : "${currencyFormat.format(transaction.credit + (-transaction.debit) )}",
                        transactionDate    : "${DateGroovyMethods.format(transaction.createdAt, "EEE, dd MMM yyyy HH:mm:ss Z")}",
                        feeAmount          : "${(StringUtils.equalsIgnoreCase(transaction.paymentMethod,"boku"))?(transaction.feeAmount == null ? "" : currencyFormat.format(transaction.feeAmount)):""}",
                ]
            }
        }


        log.info("Creating roles")

        Permission portalPermission = Permission.findWhere(name: "PORTAL_VIEW", category: "Portal", description: "Allows to see the main portal of the backoffice.")
        Permission playerViewPermission = Permission.findWhere(name: "PLAYER_VIEW", category: "Player", description: "Search and view players.")
        Permission transactionGlobalView = Permission.findWhere(name: "TRANSACTIONS_GLOBAL_VIEW", category: "Transactions", description: "Search for all transactions.")
        Permission transactionsPlayerView = Permission.findWhere(name: "TRANSACTIONS_PLAYER_ONLY", category: "Transactions", description: "View transactions for a selected player only.")
        Permission transactionsManualAdjustments = Permission.findWhere(name: "TRANSACTIONS_MANUAL_ADJUSTMENTS", category: "Transactions", description: "Allows to make manual adjustments on a player account.")


        Role userRole = Role.findByAuthority('ROLE_USER')
        if (userRole == null) {
            userRole = new Role(authority: 'ROLE_USER', category: "User",
                    description: "Basic backoffice user").save(failOnError: true)

            userRole.addToPermissions(portalPermission).save(failOnError: true)
            userRole.addToPermissions(playerViewPermission).save(failOnError: true)
            userRole.addToPermissions(transactionsPlayerView).save(failOnError: true)
        }




        if (!isForUS) {
            // this should idealy be in liquibase
            log.info("creating NYX user")
            Role superUserRole = Role.findByAuthority('ROLE_SUPERUSER')
            Operator nektanNyxUser = Operator.findByUsername("nektan")
            Site site1 = Site.findByShortName("ROOT")
            if (nektanNyxUser == null) {
                nektanNyxUser = new Operator(
                        username: "nektan", lastName: "NYX Game Adapter DO NOT SUSPEND", firstName: "SYSTEM", password: "nektan1",
                        email: "nektanoperator@nektan.com", operates: site1,
                        debitLimit: paramService.getBigDecimal("operator.limit.debit"),
                        creditLimit: paramService.getBigDecimal("operator.limit.credit"),
                        neverExpires: true,
                        description: "Do not Suspend",
                        debitLimitCapForADay: paramService.getBigDecimal("operator.limit.debit.daily"),
                        creditLimitCapForADay:paramService.getBigDecimal("operator.limit.credit.daily")
                ).save(failOnError: true)
                OperatorRole.create(nektanNyxUser, superUserRole, true)
            } else {
                nektanNyxUser.neverExpires = true
                nektanNyxUser.lastName = "NYX Game Adapter DO NOT SUSPEND"
                nektanNyxUser.description = "NYX Game Adapter DO NOT SUSPEND"
                nektanNyxUser.save(failOnError: true)
            }
        } // is for US - create NYX user

        log.info "Creating NoteTypes"
        // Example for creating NoteType
        // NoteType.findOrSaveWhere(shortName: NoteType.SHORT_NAMES.FRAUD, name: "Fraud", editable: true, selectable: true)
 //       NoteType.findOrSaveWhere(shortName: NoteType.SHORT_NAMES.VOIDING_TRANSACTION, name: "Voiding Transaction", editable: false, selectable: true)

        log.info "Creating payment methods"
        // Example for creating new payment methods
        // PaymentMethod.findOrSaveWhere(shortName: "skrill", name: "Skrill", description: "Skrill")

        log.info "Creating Player Statuses"
        // Example for creating new Player Statuses
        // PlayerStatus.findOrSaveWhere(name: "active", colorcode: "#55ba64", description: "Active")  // 1
//       PlayerStatus.findOrSaveWhere(name: "W2G", colorcode: "#3a10ab", description: "W2G requirement pending", canLogin: true, canPlay: true, canDeposit: true, canWithdraw: false, canReactivate: true, canResendPassword: true)


        log.info "Creating Params"
        // Example for creating new params
//        Param.findOrSaveWhere(paramKey: "logging.logResponseModel", val:'false', paramType: "Boolean",description: "Log the response model returned by the view.", system: true, editable: true)

        log.info "creating Permissions"
// e.g.          Permission transactionsManualAdjustments = Permission.findWhere(name: "TRANSACTIONS_MANUAL_ADJUSTMENTS", category: "Transactions", description: "Allows to make manual adjustments on a player account.")

        log.info "adding Permissions to superuser"
        Role superUserRole = Role.findByAuthority('ROLE_SUPERUSER')

        log.info "Creating countries and currencies"
        // Example for creating new countries and currencies
        // Currency gbp = Currency.findOrSaveWhere(iso: "GBP", name: "Pounds Sterling", decimalPlaces: 2, prefix: '£').save(flush: true)
        // ExchangeRate.findByFromAndTo(usd,crd) ?: new ExchangeRate(from: usd, to: crd, rate: 100).save(failOnError: true)
        // Country gb = Country.findOrSaveWhere(iso2: "GB", iso3: "GBR", name: "Great Britain", dialcode: "44", removeLeadingZero: true, taxRate: new BigDecimal(15))

        log.info "Creating account types"

        log.info "Creating Platforms"
        // Platform platform = Platform.findByShortName("mob") ?: new Platform(shortName: "mob", name: "mobile", description: "HTML5 mobile").save(failOnError: true)

        log.info "Creating Transaction Types"
        // TransactionType deposit = TransactionType.findOrSaveWhere(shortName: "deposit", name: "deposit", description: "deposit into balance from external source")

        log.info "Creating subtypes"
        // TransactionSubtype.findByShortName(TransactionSubtype.TYPES.OTHER) ?: new TransactionSubtype(shortName: TransactionSubtype.TYPES.OTHER, name: "Other", description: "manual adjustment with no applicable type", transactionType: manualTransactionType).save(failOnError: true)

        log.info "Creating security questions"
        // new SecurityQuestion(question: "What's your favourite colour?").save(failOnError: true)

        log.info "Creating Document Types"
        // DocumentType documentType = DocumentType.findByName("idcard")

        log.info "Creating VIP Levels"
        // VIPLevel vipLevel = VIPLevel.findByShortname("viplevel_2")

        log.info "Creating Security Levels"
        // SecurityLevel securityLevel = SecurityLevel.findByShortname("securitylevel_2")

        log.info "Starting Statistics Job"
	    StatisticsJob.schedule( paramService.getInt("statistics.update") * 1000 * 60 )

        log.info "End of BootStrap"
    }

    def destroy = {
    }
}
