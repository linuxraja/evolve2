import com.nektan.revolve.coreservices.*
import com.nektan.revolve.api.AccountTypes
import com.nektan.revolve.messages.Template
import com.nektan.revolve.messages.TemplateType
import grails.converters.JSON
import grails.util.Environment

class DevelopmentBootStrap {

    def grailsApplication
    def transaction
    def playerService
    def pluginService
    def paramService


    def init = { servletContext ->

        environments {

            development {

                def filePath
                def text
                def json

                log.info "Start of DevelopmentBootStrap"

                boolean isForUS = grailsApplication.config.evolve2.mode == "US"

                Currency gbp = Currency.findByIso("GBP")  // created in the main bootStrap
                Currency USD = Currency.findByIso("USD")
                Currency credits = Currency.findByIso("CRD")

                // Define some countries
                def us
                us = Country.findByIso2("US")

                // grab some transaction types
                TransactionType depositType, withdrawalType, gameType, manualType
                depositType = TransactionType.findByShortName("deposit")
                withdrawalType = TransactionType.findByShortName("withdrawal")
                gameType = TransactionType.findByShortName(TransactionType.SHORT_NAME.game.toString())
                manualType = TransactionType.findByShortName(TransactionType.SHORT_NAME.manual.toString())

                // Define different transaction sub types
                TransactionSubtype testFunds, comps, promo
                testFunds = TransactionSubtype.findByShortName(TransactionSubtype.TYPES.TESTFUNDS)
                promo = TransactionSubtype.get(TransactionSubtype.IDS.PROMO)
                if (testFunds == null || promo == null) {
                    log.info "*** MISSING SUBTYPES"
                }

                log.info "Creating Sites"

                def site1, site2, winzino
                final String WINZ = "WINZINO-CASINO"
                site1 = Site.findByShortName("ROOT") // created with bootstrap
                if (isForUS) {
                    site2 = Site.findByShortName("respindev ")
                    if (site2 == null) {
                        site2 = new Site(shortName: "respindev ", name: "Respin Developer Site", description: "Respin Developer Site", currency: credits, geocomply: false,
                                geoFence: "(39.52589821181087, -119.82358932495117),(39.52650232419637, -119.82012391090393),(39.52243894653557, -119.81876134872437),(39.52142099595068, -119.82224822044373)",
                                parent: site1, fromEmail: "respin@respin.net", url: "http://www.respin.net",
                                playerMobileNumberDesc: "10 digits", playerMobileNumberRegexp: "^\\d{10}\$",
                                minDeposit: 0.01, maxDeposit: 500, maxDailyDeposit: 2000, maxWeeklyDeposit: 100000, maxMonthlyDeposit: 1000000).save(failOnError: true)
                    } else if (site2.playerMobileNumberRegexp == null) {
                        site2.playerMobileNumberRegexp = "^\\d{10}\$"
                        site2.playerMobileNumberDesc = "10 digits"
                        site2.save(failOnError: true)
                    }
                    // Is the below needed? There is no mapping table...
                    site1.addToSubSites(site2).save(failOnError: true)

                } else {
                    site2 = Site.findByShortName("CHOMP") ?: new Site(shortName: "CHOMP", name: "Chomp Casino", description: "Chomp UK casino is fab", url: "https://local.chompcasino.co.uk", depositUrl: "", fromEmail: "", parent: site1).save(failOnError: true, flush: true)
                    // Is the below needed? There is no mapping table...
                    site1.addToSubSites(site2).save(flush: true, failOnError: true)
                    winzino = Site.findByShortName(WINZ)
                    if (winzino == null) {
                        winzino = new Site(shortName: WINZ, name: "Winzino", description: "Winzino Casino", geocomply: false, parent: site1, url: "https://winzino.qa.nektan.com",
                                depositUrl: "https://winzino.qa.nektan.com/lobby/winzino/epg/deposit", minDeposit: 10, maxDeposit: 1000, maxIdle: 12345).save(failOnError: true)
                    }
                } // else not for US
                log.info "Sites created."


                log.info("Creating operator")

                Permission portalPermission = Permission.findWhere(name: "PORTAL_VIEW", category: "Portal", description: "Allows to see the main portal of the backoffice.")
                Permission playerViewPermission = Permission.findWhere(name: "PLAYER_VIEW", category: "Player", description: "Search and view players.")
                Permission transactionGlobalView = Permission.findWhere(name: "TRANSACTIONS_GLOBAL_VIEW", category: "Transactions", description: "Search for all transactions.")
                Permission transactionsPlayerView = Permission.findWhere(name: "TRANSACTIONS_PLAYER_ONLY", category: "Transactions", description: "View transactions for a selected player only.")
                Permission transactionsManualAdjustments = Permission.findWhere(name: "TRANSACTIONS_MANUAL_ADJUSTMENTS", category: "Transactions", description: "Allows to make manual adjustments on a player account.")

                Role advancedUserRole = Role.findByAuthority('ROLE_ADVANCED_USER')
                if (advancedUserRole == null) {
                    advancedUserRole = new Role(authority: 'ROLE_ADVANCED_USER', category: "User",
                            description: "Advanced backoffice user").save(failOnError: true)
                    advancedUserRole.addToPermissions(portalPermission).save(failOnError: true)
                    advancedUserRole.addToPermissions(playerViewPermission).save(failOnError: true)
                    advancedUserRole.addToPermissions(transactionsPlayerView).save(failOnError: true)
                    advancedUserRole.addToPermissions(transactionsManualAdjustments).save(failOnError: true)
                    advancedUserRole.addToPermissions(transactionGlobalView).save(failOnError: true)
                }

                Operator operator1 = Operator.findByUsername("operator1")
                if (operator1 == null) {
                    operator1 = new Operator(
                            username: "operator1", lastName: "Mouse", firstName: "Micky", password: "1234",
                            email: "op@test.com", operates: site1,
                            debitLimit: new BigDecimal(paramService.getInt("operator.limit.debit")),
                            creditLimit: new BigDecimal(paramService.getInt("operator.limit.credit")),
                            debitLimitCapForADay: new BigDecimal(paramService.getInt("operator.limit.debit.daily")),
                            creditLimitCapForADay: new BigDecimal(paramService.getInt("operator.limit.credit.daily"))).save(failOnError: true)
                    OperatorRole.create(operator1, advancedUserRole, true)
                }

                // These are defined in liquibase (for UK and US)
                RGS rgs = RGS.findWhere(name: "ROC")
                GameCategory slots = GameCategory.findWhere(shortName: "slots")
                GameCategory bingo = GameCategory.findWhere(shortName: "bingo")

                log.info "creating games"

                Game game1, game4, game5
                game1 = Game.findByName("Plucky Pirates") ?: new Game(name: "Plucky Pirates", shortName: "PLUCKY-PIRATES-SLOTS", description: "Plucky Pirates 5 line ROC", rgs: rgs, category: slots, externalId: "pluck123", defaultWageringContribution: 100, minBetWageringContribution: 0.10, isDeleted: false).save(failOnError: true)
                game4 = Game.findByName("Bingo") // in liquibase
                game5 = Game.findByName("Rapid Bingo") // in liquibase


                log.info "Creating Players"
                // create players
                filePath = "resources/players_20.json"
                text = grailsApplication.getParentContext().getResource("classpath:$filePath").getInputStream().getText()
                json = JSON.parse(text)

                PlayerStatus ps = PlayerStatus.findByName("active");

                def player
                for (playerData in json) {
                    String username = ((String) playerData['userName'])
                    player = Player.findByUserName(username)
                    if (player == null) {

                        def playerParams = [:]
                        playerParams.createdAt = new Date().parse("yyyy-M-d", (String) playerData['createdAt'])
                        playerParams.userName = username
                        playerParams.password = playerData['password']
                        playerParams.firstName = playerData['firstName']
                        playerParams.lastName = playerData['lastName']
                        playerParams.dateOfBirth = new java.sql.Date((new Date().parse("yyyy-M-d", (String) playerData['dateOfBirth'])).getTime())
                        playerParams.email = playerData['email']
                        playerParams.site = [id: site2.id.toString()]
                        playerParams.mobileNumber = playerData['mobileNumber'] + "0"
                        playerParams.address_1 = "410 South Rampart"
                        playerParams.state = "NV"
                        playerParams.city = "Las Vegas"
                        playerParams.playerStatus = ps
                        playerParams.country = us
                        playerParams.gender = "M"
                        playerParams.salutation = "Mr"
                        playerParams.postcode = "89145"
						playerParams.currency = [id : "1"]
                        player = playerService.create(playerParams)
                        if (player.hasErrors()) {
                            throw new RuntimeException("player creation failed " + player.errors.toString())
                        }
                    }
                }
                log.info("Players created")

                //create some accounts (and a currency) and attach them to the first three players

                log.info "create notes"
                def notes = Note.findByPlayer(player);
                if (notes == null) {
                    NoteType generalType = NoteType.findByShortName(NoteType.SHORT_NAMES.GENERAL)

                    // now a note with a child (open)
                    Note n2 = new Note(player: player, type: generalType, text: "Created a strange player", author: operator1, contactChannel: 0).save(failOnError: true)
                    n2.parent = n2
                    n2.save(failOnError: true, flush: true)
                    Note n3 = new Note(player: player, type: generalType, parent: n2, text: "Player Checked, seems ok", author: operator1, contactChannel: 0).save(failOnError: true)

                    // now a closed note
                    Note n4 = new Note(player: player, type: generalType, text: "He likes the colour green, wibble", author: operator1, open: false, contactChannel: 0).save(failOnError: true)
                    n4.parent = n4
                    n4.save(failOnError: true, flush: true)
                }


                log.info "creating test transactions"

                NoteType manualNoteType = NoteType.findByShortName(NoteType.SHORT_NAMES.MANUAL_TRANSACTION)

                // if any transactions exist in the system, then dont do this!!!
                long transactionCount = Transaction.count()
                if (transactionCount == 0) {

                    def random = new Random()
                    int externalInstanceGameId = 100
                    Account acc

                    Player[] players = Player.findAll()
                    players.eachWithIndex { Player p, int i ->
                        acc = Account.findByPlayerAndType(p, AccountTypes.CASH)

                        // deposit some funds
                        new Transaction(createdAt: (new Date().minus(4)), type: depositType, description: "Deposit of cash", site: p.site, credit: new BigDecimal(1000), debit: BigDecimal.ZERO, account: acc).save(failOnError: true)

                        // create a manual transaction and a note.
                        Transaction t = new Transaction(createdAt: (new Date().minus(3)), type: manualType, subType: promo, description: "Super Mega Promotion", site: p.site, credit: new BigDecimal(10), debit: new BigDecimal(0), account: acc, operator: operator1).save(failOnError: true)
                        Note n = new Note(player: p, type: manualNoteType, transaction: t, text: "Created some test funds for our nice player, no fraud, honest", author: operator1).save(failOnError: true)
                        n.parent = n
                        n.save(failOnError: true, flush: true)

                        // play some bingo.
                        new Transaction(createdAt: new Date().previous(), type: gameType, game: game4, externalGameInstanceId: externalInstanceGameId, description: "Bought 10 bingo tickets", site: p.site, credit: BigDecimal.ZERO, debit: new BigDecimal(10), account: acc).save(failOnError: true)
                        new Transaction(createdAt: new Date(), type: gameType, game: game4, externalGameInstanceId: externalInstanceGameId, description: "Won 5 on ticket id 123", site: p.site, credit: new BigDecimal(5), debit: BigDecimal.ZERO, account: acc).save(failOnError: true)
                        new Transaction(createdAt: new Date(), type: gameType, game: game4, externalGameInstanceId: externalInstanceGameId, description: "Won 1 on ticket id 124", site: p.site, credit: new BigDecimal(4), debit: BigDecimal.ZERO, account: acc).save(failOnError: true)
                        externalInstanceGameId++
                        // some slot games
                        for (i = 0; i < 20; i++) {
                            new Transaction(createdAt: new Date().minus(random.nextInt(3)), type: gameType, game: game1, externalGameInstanceId: externalInstanceGameId++, description: "Slot game", site: p.site, debit: new BigDecimal(random.nextInt(30) + 1), credit: new BigDecimal(random.nextInt(28)), account: acc).save(failOnError: true)
                        }
                    }// for each account
                }  // if didnt find a transaction.

                log.info "creating test transactions ... done"

//                if (Environment.current == Environment.PRODUCTION && isForUS) {
                if (isForUS) {

                    log.info "creating RespinUsers"

                    // create a bunch of respin users requested by jazz. 3 were created above
                    if (Player.findByUserName("RespinUser1") == null) {
                        Site chomp = Site.findByShortName("respindev")
                        SecurityQuestion question = SecurityQuestion.get(1)
                        for (int i = 1; i <= 11; i++) {
                            def playerParams = [:]
                            playerParams.createdAt = new Date()
                            playerParams.userName = "RespinUser" + i
                            playerParams.password = 'password'
                            playerParams.firstName = "Jazz"
                            playerParams.lastName = "Matazz"
                            playerParams.dateOfBirth = new java.sql.Date((new Date().parse("yyyy-M-d", "1970-01-01")).getTime())
                            playerParams.email = "respin" + i + "@respin.com"
                            playerParams.site = [id: chomp.id.toString()]
                            // force 10 digit mobile number for US.
                            playerParams.mobileNumber = "" + (1111110000 + i)
                            playerParams.address_1 = "410 South Rampart"
                            playerParams.state = "NV"
                            playerParams.city = "Las Vegas"
                            playerParams.playerStatus = ps
                            playerParams.country = us
                            playerParams.gender = "M"
                            playerParams.salutation = "Mr"
                            playerParams.postcode = "89145"
                            playerParams.securityQuestion = question
                            playerParams.securityAnswer = "wibble"
                            player = playerService.create(playerParams)

                            if (player.hasErrors()) {
                                throw new RuntimeException("player creation failed " + player.errors.toString())
                            }

                            Account acc = Account.findByPlayerAndType(player, AccountTypes.CASH)
                            new Transaction(createdAt: new Date(), type: depositType, description: "Deposit of cash", site: player.site, credit: new BigDecimal(1000000), debit: BigDecimal.ZERO, account: acc).save(failOnError: true)
                        }

                        log.info "creating RespinUsers ... done"
                    }
                } // development
            } // environments
            log.info "End of DevelopmentBootStrap"
        } // init
        def destroy = {
        }
    }
}