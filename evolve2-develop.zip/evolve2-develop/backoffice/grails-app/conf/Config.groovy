
import grails.plugin.springsecurity.SecurityConfigType


// locations to search for config files that get merged into the main config;
// config files can be ConfigSlurper scripts, Java properties files, or classes
// in the classpath in ConfigSlurper format

grails.config.locations = [ "file:${userHome}/.grails/${appName}-config.groovy"]

 if (System.properties["${appName}.config.location"]) {
    grails.config.locations << "file:" + System.properties["${appName}.config.location"]
 }

grails.project.groupId = appName // change this to alter the default package name and Maven publishing destination

// The ACCEPT header will not be used for content negotiation for user agents containing the following strings (defaults to the 4 major rendering engines)
grails.mime.disable.accept.header.userAgents = ['Gecko', 'WebKit', 'Presto', 'Trident']
grails.mime.types = [ html: ['text/html','application/xhtml+xml'],
                      xml: ['text/xml', 'application/xml'],
                      text: 'text-plain',
                      js: 'text/javascript',
                      rss: 'application/rss+xml',
                      atom: 'application/atom+xml',
                      css: 'text/css',
                      csv: 'text/csv',
                      pdf: 'application/pdf',
                      rtf: 'application/rtf',
                      excel: 'application/vnd.ms-excel',
                      ods: 'application/vnd.oasis.opendocument.spreadsheet',
                      all: '*/*',
                      json: ['application/json','text/json'],
                      form: 'application/x-www-form-urlencoded',
                      multipartForm: 'multipart/form-data'
]

// URL Mapping Cache Max Size, defaults to 5000
//grails.urlmapping.cache.maxsize = 1000

// Legacy setting for codec used to encode data with ${}
grails.views.default.codec = "html"

// The default scope for controllers. May be prototype, session or singleton.
// If unspecified, controllers are prototype scoped.
grails.controllers.defaultScope = 'singleton'

// GSP settings
grails {
    views {
        gsp {
            encoding = 'UTF-8'
            htmlcodec = 'xml' // use xml escaping instead of HTML4 escaping
            codecs {
                expression = 'html' // escapes values inside ${}
                scriptlet = 'html' // escapes output from scriptlets in GSPs
                taglib = 'none' // escapes output from taglibs
                staticparts = 'none' // escapes output from static template parts
            }
        }
        // escapes all not-encoded output at final stage of outputting
        // filteringCodecForContentType.'text/html' = 'html'
    }
}

// SWH: this is to override the Id generation in the audit plugin to be cluster friendly
auditLog{
    idMapping = [generator:"native", type:"long"]
    //verbose = true // verbosely log all changed values to db
    //logIds = true  // log db-ids of associated objects.
    }

grails.converters.encoding = "UTF-8"
// scaffolding templates configuration
grails.scaffolding.templates.domainSuffix = 'Instance'

// Set to false to use the new Grails 1.2 JSONBuilder in the render method
grails.json.legacy.builder = false
// enabled native2ascii conversion of i18n properties files
grails.enable.native2ascii = true
// packages to include in Spring bean scanning
grails.spring.bean.packages = []
// whether to disable processing of multi part requests
grails.web.disable.multipart=false

// request parameters to mask when logging exceptions
grails.exceptionresolver.params.exclude = ['password']

// configure auto-caching of queries by default (if false you can cache individual queries with 'cache: true')
grails.hibernate.cache.queries = false

// configure passing transaction's read-only attribute to Hibernate session, queries and criterias
// set "singleSession = false" OSIV mode in hibernate configuration after enabling
grails.hibernate.pass.readonly = false
// configure passing read-only to OSIV session by default, requires "singleSession = false" OSIV mode
grails.hibernate.osiv.readonly = false

environments {
    development {
        grails.logging.jul.usebridge = true
        grails.gsp.enable.reload=true
    }

    heiko {
        grails.logging.jul.usebridge = true
        grails.gsp.enable.reload=true
    }
    production {
        grails.logging.jul.usebridge = false
        // TODO: grails.serverURL = "http://www.changeme.com"
    }
}


//grails.plugins.httplogger.enabled = true
//grails.plugins.httplogger.headers = 'Cookie, Accept-Language, X-MyHeader'
//grails.plugins.httplogger.includeUrls = ['/api/**']
//grails.plugins.httplogger.excludeUrls = ['/**/*.js']

/// / log4j configuration
log4j.main = {

    // Example of changing the log pattern for the default console appender:
    //
    appenders {
        console name:'stdout', layout:pattern(conversionPattern: '%X{backOfficeLoggerId} %d %c{2}: %X{correlationData} %m%n')
    }

    root {
        error 'stdout'
    }

    error  'org.codehaus.groovy.grails.web.servlet',        // controllers
           'org.codehaus.groovy.grails.web.pages',          // GSP
           'org.codehaus.groovy.grails.web.sitemesh',        // layouts
          'org.codehaus.groovy.grails.web.mapping.filter', // URL mapping
           'org.codehaus.groovy.grails.web.mapping',        // URL mapping
           'org.codehaus.groovy.grails.commons',            // core / classloading
           'org.codehaus.groovy.grails.plugins',            // plugins
           'org.codehaus.groovy.grails.orm.hibernate',      // hibernate integration
           'org.springframework',
           'org.hibernate',
           'net.sf.ehcache.hibernate'
    fatal 'org.hibernate.tool.hbm2ddl.SchemaExport'
    info 'grails.plugin.springsecurity.web.filter.DebugFilter','grails.plugins.httplogger'

    all additivity: false,
            'stdout': [
                    'grails.app.controllers.com.nektan',
                    'grails.app.domain.com.nektan',
                    'grails.app.services.com.nektan',
                    'grails.app.taglib.com.nektan',
                    'grails.app.conf.com.nektan',
                    'grails.app.filters.backoffice',
                    'grails.app.jobs.com.nektan',
                    "grails.app.conf"
            ]

}


// Added by the Spring Security Core plugin:
grails.plugin.springsecurity.userLookup.userDomainClassName = 'com.nektan.revolve.coreservices.Operator'
grails.plugin.springsecurity.userLookup.authorityJoinClassName = 'com.nektan.revolve.coreservices.OperatorRole'
grails.plugin.springsecurity.authority.className = 'com.nektan.revolve.coreservices.Role'
grails.plugin.springsecurity.requestMap.className = 'com.nektan.revolve.backoffice.Requestmap'
grails.plugin.springsecurity.securityConfigType = SecurityConfigType.Annotation
grails.plugin.springsecurity.logout.postOnly = false
grails.plugin.springsecurity.controllerAnnotations.staticRules = [
	'/ckeditor/**':     ['permitAll'],
    '/uploads/**':      ['permitAll'],
    '/api/**':          ['permitAll'],
    '/sightline/**':    ['permitAll'],
    '/assets/**':       ['permitAll'],
    '/**/js/**':        ['permitAll'],
    '/**/css/**':       ['permitAll'],
    '/**/images/**':    ['permitAll'],
    '/**/fonts/**':     ['permitAll'],
    '/**/favicon.ico':  ['permitAll'],
	'/operator/passwordExpired':['permitAll'],
	'/operator/updatePassword':['permitAll']
]
grails.plugin.springsecurity.failureHandler.exceptionMappings = [
		'org.springframework.security.authentication.CredentialsExpiredException': '/operator/passwordExpired'
]
grails.plugin.springsecurity.apf.storeLastUsername = true
grails.plugin.springsecurity.useSecurityEventListener = true

// move this out if we separate the API
cors.url.pattern = '/api/*'


environments {

	development {
		grails {
			mail {
				host = "127.0.0.1"
				port = 1025
			}
		}
	} // development

	production {

		grails {
			mail {
				host = "127.0.0.1"
				port = 25
			}
		}
	} // production

} // environments

grails.converters.default.pretty.print=true
revolve.player.encryptSecurityAnswer=false

// override these in your local config files for US
evolve2.mode="UK" // "US" or "UK"
grails.plugin.databasemigration.changelogFileName = 'changelog.xml'
// by default does not update on startup, unless sepcified in your local config file.

evolve2.gameserverUrl='http://localhost:8080/gameserver/games/nektan/'
evolve2.IGTUrl='http://localhost:8080/gameserver/games/nektan/slotsGame?'
evolve2.NYXUrl='https://ogs-gl-stage.nyxgib.eu/game/'
evolve2.ROCUrl='http://localhost:8080/gameserver/games/nektan/slotsGame?'

grails.plugins.remotepagination.enableBootstrap = true