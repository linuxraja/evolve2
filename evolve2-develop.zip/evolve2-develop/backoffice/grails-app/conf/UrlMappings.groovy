import javax.lang.model.element.Name
import javax.xml.stream.events.Namespace

class UrlMappings {

    static mappings = {
        "/$controller/$action?/$id?(.$format)?"{
            constraints {
                // apply constraints here
            }
        }

        "/" (controller: "Portal", action: "index")
        "500"(view:'/error')

        // for backoffice security
        "/login/$action?"(controller: "login")
        "/logout/$action?"(controller: "logout")


        // for ROC Bingo api
        "/api/v1/sessions/auth" (namespace: "v1", controller: "Session", action: "authenticatePlayer" )
        "/api/v1/sessions/create" (namespace: "v1", controller: "Session", action: "createSession" )
        "/api/v1/sessions/refresh" (namespace: "v1", controller: "Session", action: "refreshSession" )
        "/api/v1/sessions/close" (namespace: "v1", controller: "Session", action: "closeSession" )
        "/api/v1/players/details" (namespace: "v1", controller: "Player", action: "getDetails")
        "/api/v1/players/create" (namespace: "v1", controller: "Player", action: "createPlayer")
        "/api/v1/players/password" (namespace: "v1", controller: "Player", action: "changePassword")
        "/api/v1/players/resetPassword" (namespace: "v1", controller: "Player", action: "resetPassword")
        "/api/v1/players/resendUsername" (namespace: "v1", controller: "Player", action: "resendUsername")
		"/api/v1/players/updatePassword" (namespace: "v1", controller: "Player", action: "updatePassword")
        "/api/v1/players/getSecurityQuestion" (namespace: "v1", controller: "Player", action: "getSecurityQuestion")
        "/api/v1/players/resetPasswordNow" (namespace: "v1", controller: "Player", action: "resetPasswordNow")


        // deprecated, use /game/tranaction instead.
        "/api/v1/accounts/transaction/create/game" (namespace: "v1", controller: "Game", action: "createGameTransaction")

        "/api/v1/accounts/balance" (namespace: "v1", controller: "Account", action: "getBalance")
        "/api/v1/accounts/statement" (namespace: "v1", controller: "Account", action: "retrieveTransactions")

        "/api/v1/game/start" (namespace: "v1", controller: "Game", action: "startGame")
        "/api/v1/game/transaction" (namespace: "v1", controller: "Game", action: "createGameTransaction")
        "/api/v1/game/end" (namespace: "v1", controller: "Game", action: "endGame")
        "/api/v1/game/list" (namespace: "v1", controller: "Game", action: "list")

        "/api/v1/geo/check" (namespace: "v1", controller: "GeoFence", action: "siteAtLocation")
        "/api/v1/geo/inLocation" (namespace: "v1", controller: "GeoFence", action: "isInLocation")

       "/api/v1/sightline/channelCheckAdvanced" (namespace: "v1", controller: "Sightline", action: "channelCheckAdvanced")
        "/api/v1/sightline/getBalance"          (namespace: "v1", controller: "Sightline", action: "getBalance")
        "/api/v1/sightline/transfer"            (namespace: "v1", controller: "Sightline", action: "transfer")

        "/api/v1/settings/getSecurityQuestions" (namespace: "v1", controller: "Settings", action: "getSecurityQuestions")
        "/api/v1/settings/getSettings"          (namespace: "v1", controller: "Settings", action: "getSettings")

        // Evolve 1 Lobby API
        "/api/account/" (namespace: "evolve1", controller: "player", action: "register")
        "/api/account/verifyEmail" (namespace: "evolve1", controller: "player", action: "verifyEmail")
		"/api/promobonus/$bonusCode" (namespace: "evolve1", controller: "player", action: "promoCodeRedemption")

        "/api/account/login" (namespace: "evolve1", controller: "player", action: "login")
        "/api/account/guestLogin" (namespace: "evolve1", controller: "player", action: "guestLogin")
        "/api/account/logout" (namespace: "evolve1", controller: "Player", action: "logout")

        "/api/account/profile" (namespace: "evolve1", controller: "Player", action: "profile")
        "/api/account/redirectedProfile" (namespace: "evolve1", controller: "Player", action: "redirectedProfile")
		"/api/account/depositTermsAndConditions" (namespace: "evolve1", controller: "Player", action: "depositTermsAndConditions")
		"/api/account/termsAndConditions" (namespace: "evolve1", controller: "Player", action: "termsAndConditions")
        "/api/account/privacyPolicy" (namespace: "evolve1", controller: "Player", action: "updatePrivacyPolicy")
		"/api/account/paymentMethodChangeThreshold" (namespace: "evolve1", controller: "Player", action: "getPaymentMethodChangeThreshold")
        "/api/account/updateMobileNumber" (namespace: "evolve1", controller: "Player", action: "updateMobileNumber")
        "/api/account/validateSMS" (namespace: "evolve1", controller: "Player", action: "validateSMS")
        "/api/account/resendSMS" (namespace: "evolve1", controller: "Player", action: "resendSMS")

		"/api/account/emailCheck" (namespace: "evolve1", controller: "player", action: "emailCheck")
        "/api/account/selfExclude" (namespace: "evolve1", controller: "Player", action: "selfExclude")


        "/api/account/balance" (namespace: "evolve1", controller: "Player", action: "balance")
		"/api/account/redirectedBalance" (namespace: "evolve1", controller: "Player", action: "redirectedBalance")
		"/api/loyalty/redemption" (namespace: "evolve1", controller: "Player", action: "getLoyaltyDetails")
		"/api/loyalty/redemption/$noOfBlocks" (namespace: "evolve1", controller: "Player", action: "redeemLoyaltyPoints")
        "/api/account/getAllChallengeQuestions" (namespace: "evolve1", controller: "Player", action: "challengeQuestions")

        "/api/account/changeContactableSettings" (namespace: "evolve1", controller: "Player", action: "changeContactableSettings")
        "/api/account/changeSmsContactableSettings" (namespace: "evolve1", controller: "Player", action: "changeSMSContactableSettings")
        "/api/account/setAutoLoginPreferences" (namespace: "evolve1", controller: "player", action: "autoLoginPreference")
        "/api/account/changePassword" (namespace: "evolve1", controller: "Player", action: "changePassword")
        "/api/account/reactivatePlayer" (namespace: "evolve1", controller: "Player", action: "reactivatePlayer")
        "/api/account/password-reset" (namespace: "evolve1", controller: "Player", action: "passwordReset")
        "/api/account/password" (namespace: "evolve1", controller: "Player", action: "changePassword2")
		"/api/account/setRealityCheckLimit" (namespace: "evolve1", controller: "Player", action: "setRealityCheckLimit")
        "/api/account/bonusDetails" (namespace: "evolve1", controller: "player", action: "getBonusDetails")
        "/api/account/allBonusDetails" (namespace: "evolve1", controller: "player", action: "getAllBonusDetails")
        "/api/account/freeSpinDetails" (namespace: "evolve1", controller: "player", action: "getFreeSpinDetails")
        "/api/account/cancelAllBonuses" (namespace:"evolve1",controller: "player",action: "cancelAllBonuses")
        "/api/account/cancelActiveBonus" (namespace:"evolve1",controller: "player",action: "cancelActiveBonus")
        "/api/account/bonusOptOut" (namespace:"evolve1",controller: "player",action: "bonusOptOut")
        "/api/account/checkPlayerEligibleDepositBonus" (namespace: "evolve1", controller: "player", action: "getPlayerEligibleDepositBonus")
        "/api/account/checkPlayerEligibleDepositBonusForBonusCode" (namespace: "evolve1", controller: "player", action: "getPlayerEligibleDepositBonusForBonusCode")
        "/api/account/changeWithdrawalConfirmation" (namespace: "evolve1", controller: "player", action: "changeWithdrawalConfirmation")

        // Need to remove below 3 endpoints when the app is ready, JIRA# REV-880
        "/api/accountsystem/bonusDetails" (namespace: "evolve1", controller: "player", action: "getBonusDetails")
        "/api/accountsystem/freeSpinDetails" (namespace: "evolve1", controller: "player", action: "getFreeSpinDetails")
        "/api/accountsystem/checkPlayerEligibleDepositBonus" (namespace: "evolve1", controller: "player", action: "getPlayerEligibleDepositBonus")
        "/api/accountsystem/checkPlayerEligibleDepositBonusForBonusCode" (namespace: "evolve1", controller: "player", action: "getPlayerEligibleDepositBonusForBonusCode")

        "/api/account/optInToPromotion" (namespace: "evolve1", controller: "player", action: "optInToPromotion")
        "/api/account/isBonusCodeValid" (namespace: "evolve1", controller: "player", action: "isBonusCodeValid")

        "/api/limits/deposit" (namespace: "evolve1", controller: "Player", action: "limits")

        "/api/account/getGameHistory" (namespace: "evolve1", controller: "history", action: "gameHistory")
        "/api/account/getBonusHistory" (namespace: "evolve1", controller: "history", action: "bonusHistory")
        "/api/account/getTransactionHistory" (namespace: "evolve1", controller: "history", action: "financialTransactionHistory")
        "/api/account/getCashRewardsHistory" (namespace: "evolve1", controller: "history", action: "cashRewardsHistory")
        "/api/account/getJackpotWinningHistory" (namespace: "evolve1", controller: "history", action: "jackpotWinningHistory")
        "/api/account/getHistoricalGameHistory" (namespace: "evolve1", controller: "history", action: "getHistoricalGameHistory")
        "/api/account/getHistoricalAccountHistory" (namespace: "evolve1", controller: "history", action: "getHistoricalAccountHistory")

        "/api/account/$accountSystemTag/$game/$gameTag" (namespace: "evolve1", controller: "gameServer", action: "launch")
        "/api/accountsystems/$accountSystemTag/$game/$gameTag" (namespace: "evolve1", controller: "gameServer", action: "launch")
        "/api/accountsystem/initialize" (namespace: "evolve1", controller: "gameServer", action: "initialise")
        "/api/accountsystem/launch/netent" (namespace: "evolve1", controller: "gameServer", action: "netentLaunch")
        "/api/accountsystem/launch/netentDealer" (namespace: "evolve1", controller: "gameServer", action: "netentTableGamesLaunch")
        "/api/accountsystem/launch/netentMobile" (namespace: "evolve1", controller: "gameServer", action: "netentMobileLaunch")
        "/api/accountsystem/launch/netentTableMobile" (namespace: "evolve1", controller: "gameServer", action: "netentTableGameMobileLaunch")
        "/api/accountsystem/launch/animation" (namespace: "evolve1", controller: "gameServer", action: "animation")
        "/api/accountsystem/quickfire/realityCheck" (namespace: "evolve1", controller: "gameServer", action: "quickfireRealityCheck")
        "/api/accountsystem/launch/evolution" (namespace: "evolve1", controller: "gameServer", action: "evolutionLaunch")


        "/api/psp/epg/createTransaction" (namespace: "payments", controller: "epg", action: "createTransaction")
        "/api/psp/epg/managePendingWithdrawals" (namespace: "payments", controller: "epg", action: "managePendingWithdrawals")
        "/api/psp/epg/manageAccount" (namespace: "payments", controller: "epg", action: "manageAccount")
        "/api/psp/epg/status" (namespace: "payments", parseRequest: false, controller: "epg", action: "status")
        "/api/psp/epg/paymentStatus" (namespace: "payments", controller: "epg", action: "paymentStatus")
        "/api/psp/epg/paymentSolutions" (namespace: "payments", controller: "epg", action: "paymentSolutions")
        "/api/psp/epg/customerDetails" (namespace: "payments", controller: "epg", action: "getCustomerDetails")
        "/api/psp/epg/charge" (namespace: "payments", controller: "epg", action: "charge")
        "/api/psp/epg/authToken" (namespace: "payments", controller: "epg", action: "getAuthToken")
        "/api/psp/epg/directAPI" (namespace: "payments", controller: "epg", action: "directAPI")
        "/api/psp/epg/exchangeRate" (namespace: "payments", controller: "epg", action: "getExchangeRate")


        "/api/nektanRGSsession" (namespace: "evolve1", controller: "gameServer", action:"nektanRGSSession")

		// for NetEnt api
		"/api/account/getNetentBonusInfo" (namespace: "evolve1", controller: "NetEntBonus", action: "netentEndpoint" )

		"/api/quickfireadmin/rollback" (namespace: "evolve1", controller: "QuickFireAdmin", action: "getRollbackQueueData" )
		"/api/quickfireadmin/win" (namespace: "evolve1", controller: "QuickFireAdmin", action: "getCommitQueueData" )
		"/api/quickfireadmin/endgame" (namespace: "evolve1", controller: "QuickFireAdmin", action: "getFailedEndGameQueue" )

        "/api/accountsystems/$accountSystemTag/config" (namespace: "v1", controller: "Player", action: "getSiteConfiguration")

        "/api/pusher/authenticate" (namespace: "evolve1", controller: "PusherAuthentication", action: "authenticatePlayer")
        "/api/pusher/playerMessages" (namespace: "evolve1", controller: "PusherAuthentication", action: "playerMessages")
        "/api/pusher/playerMessagesAcknowledgment" (namespace: "evolve1", controller: "PusherAuthentication", action: "playerMessagesAcknowledgment")
        //"/api/accountsystems/$accountSystemTag/config/$ip" (namespace: "v1", controller: "Player", action: "getSiteConfiguration")

        // Jackpot Rest Client API for spring boot jackpot app
        "/api/jackpot/getOpenWinsForPlayer" (namespace: "evolve1", controller: "Player", action: "getOpenWinsForPlayer")
        "/api/jackpot/winJackpot" (namespace: "evolve1", controller: "Player", action: "winJackpot")
        "/api/jackpot/creditJackpot" (namespace: "evolve1", controller: "Player", action: "creditJackpot")

    }
}
