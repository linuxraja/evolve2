// Last change by $Author$
// Change date: $LastChangedDate$
// Version: $Rev$
// ID: $Id$

dataSource {
    pooled = true
    driverClassName = "com.mysql.jdbc.Driver"
    dialect = "org.hibernate.dialect.MySQL5InnoDBDialect"
    properties {
        maxActive = -1
        minEvictableIdleTimeMillis=1800000
        timeBetweenEvictionRunsMillis=1800000
        numTestsPerEvictionRun=3
        testOnBorrow=true
        testWhileIdle=true
        testOnReturn=true
        validationQuery="SELECT 1"
    }
}

dataSource_reporting {
    pooled = true
    driverClassName = "com.mysql.jdbc.Driver"
    dialect = "org.hibernate.dialect.MySQL5InnoDBDialect"
    properties {
        maxActive = -1
        minEvictableIdleTimeMillis=1800000
        timeBetweenEvictionRunsMillis=1800000
        numTestsPerEvictionRun=3
        testOnBorrow=true
        testWhileIdle=true
        testOnReturn=true
        validationQuery="SELECT 1"
    }
}

dataSource_wh_rev {
    pooled = true
    driverClassName = "com.mysql.jdbc.Driver"
    dialect = "org.hibernate.dialect.MySQL5InnoDBDialect"
    properties {
        maxActive = -1
        minEvictableIdleTimeMillis=1800000
        timeBetweenEvictionRunsMillis=1800000
        numTestsPerEvictionRun=3
        testOnBorrow=true
        testWhileIdle=true
        testOnReturn=true
        validationQuery="SELECT 1"
    }
}

dataSource_wh {
    pooled = true
    driverClassName = "com.mysql.jdbc.Driver"
    dialect = "org.hibernate.dialect.MySQL5InnoDBDialect"
    properties {
        maxActive = -1
        minEvictableIdleTimeMillis=1800000
        timeBetweenEvictionRunsMillis=1800000
        numTestsPerEvictionRun=3
        testOnBorrow=true
        testWhileIdle=true
        testOnReturn=true
        validationQuery="SELECT 1"
    }
}

hibernate {
    cache.use_second_level_cache = true
    cache.use_query_cache = false
//    cache.region.factory_class = 'org.hibernate.cache.ehcache.EhCacheRegionFactory' // Hibernate 4
    cache.region.factory_class = 'org.hibernate.cache.ehcache.SingletonEhCacheRegionFactory' // Hibernate 4 multiple datasource fix.
    singleSession = true // configure OSIV singleSession mode
    flush.mode = 'manual' // OSIV session flush mode outside of transactional context
}

// environment specific settings create-drop update

environments {
    development {
        dataSource {
     //       dbCreate = "update"
            url = "jdbc:mysql://127.0.0.1:3306/revolve"
            username = "revolve"
            password = "revolve"
            //logSql = true
        }
        dataSource_reporting {
           url = "jdbc:mysql://127.0.0.1:3306/revolve"
           username = "revolve"
           password = "revolve"
        }
        dataSource_wh_rev {
            url = "jdbc:mysql://127.0.0.1:3306/revolve"
            username = "revolve"
            password = "revolve"
        }
        dataSource_wh {
            url = "jdbc:mysql://127.0.0.1:3306/revolve"
            username = "revolve"
            password = "revolve"
        }
    }

    liquibase {
        dataSource {
            url = "jdbc:mysql://127.0.0.1:3306/revolve_liquibase"
            username = "revolve"
            password = "revolve"
        }

        dataSource_reporting {
            url = "jdbc:mysql://127.0.0.1:3306/revolve_reporting"
            username = "revolve"
            password = "revolve"
        }
        dataSource_wh_rev {
            url = "jdbc:mysql://127.0.0.1:3306/revolve_liquibase"
            username = "revolve"
            password = "revolve"
        }
        dataSource_wh {
            url = "jdbc:mysql://127.0.0.1:3306/revolve_liquibase"
            username = "revolve"
            password = "revolve"
        }
    }

    heiko {
        dataSource {
            //logSql = true
            dbCreate = "update"
            url = "jdbc:mysql://127.0.0.1:3306/revolve"
            username = "revolve"
            password = "WNJG8q3UrwrphW"
        }

        dataSource_reporting {
            url = "jdbc:mysql://127.0.0.1:3306/revolve_reporting"
            username = "revolve"
            password = "WNJG8q3UrwrphW"
        }
        dataSource_wh_rev {
            url = "jdbc:mysql://127.0.0.1:3306/revolve"
            username = "revolve"
            password = "revolve"
        }
        dataSource_wh {
            url = "jdbc:mysql://127.0.0.1:3306/revolve"
            username = "revolve"
            password = "revolve"
        }
    }

    test {
        dataSource {
            //dbCreate = "update"
//            dbCreate = "create"
            url = "jdbc:mysql://127.0.0.1:3306/revolve"
            username = "revolve"
            password = "WNJG8q3UrwrphW"
        }
    }

    production {
        dataSource {
            pooled = false
            jndiName = "java:comp/env/revolve"
            // logSql = true
        }

        dataSource_reporting {
            pooled = false
            jndiName = "java:comp/env/revolve"
        }

        dataSource_wh_rev {
            pooled = false
            jndiName = "java:comp/env/warehouse-revolve"
        }

        dataSource_wh {
            pooled = false
            jndiName = "java:comp/env/warehouse"
        }
    }
}
