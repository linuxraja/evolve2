INSERT INTO bonus_current_platform (bonus_id,current_platform_id)
select b.id bonus_id , p.id platform_id
From bonus  b, platform p
where bonus_type IN (8);