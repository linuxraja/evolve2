DROP PROCEDURE IF EXISTS populate_sgfd;
/

CREATE PROCEDURE `populate_sgfd`(in $rdate varchar(10))
begin
SET SQL_SAFE_UPDATES = 0;
#
delete from site_game_fact_daily where day=$rdate;
#
insert into site_game_fact_daily(day,game_id,site_id,currency,player_currency,wager_count,wager,wager_voided,wins,wins_voided,dateTs)

select date(t.created_at) day,t.game_id,t.site_id,'GBP' currency,acc.currency_id player_currency,
	sum(if(acc.type =1 and type_id=3 and voided_transaction_id is null,1,0)) wager_count,
	round(sum(if(acc.type =1 and type_id=3 and voided_transaction_id is null,debit*exchange_rate ,0)),2) wager,
	round(sum(if(acc.type =1 and type_id=3 and voided_transaction_id is not null , credit*exchange_rate ,0)),2) wager_void,
	round(sum(if(acc.type =1 and type_id=3 and voided_transaction_id is null , credit*exchange_rate ,0)),2) wins,
	round(sum(if(acc.type =1 and type_id=3 and voided_transaction_id is not null, debit*exchange_rate,0)),2) wins_void,
    now() dateTs
 from
transaction t
inner join account acc  on t.account_id=acc.id inner join revolve.currency cur on acc.currency_id=cur.id
inner join xe.exchange_rate ex on ex.currency=iso and ex.date_rate=date(t.created_at)
where acc.type in (1) and t.type_id=3
and t.created_at >= $rdate and t.created_at < adddate($rdate,1)
group by date(t.created_at),t.game_id,t.site_id,acc.currency_id;
END
/