INSERT INTO `param` (`id`, `version`, `description`, `editable`, `param_key`, `param_type`, `system`, `val`) VALUES
	(61, 0, 'true if each view of a bonus in the bonus module should be logged', b'1', 'bonus.view.log.enable', 'Boolean', b'1', 'true'),
	(62, 0, 'EPG Payments Secrect Key', b'1', 'epg.payments.password', 'Password', b'0', 'epgandnektan'),
	(63, 0, 'EPG Payments Product ID', b'1', 'epg.payments.productid', 'String', b'0', '15000'),
	(64, 0, 'EPG Payments Merchant ID', b'1', 'epg.payments.merchantid', 'String', b'0', '1050'),
	(65, 0, 'EPG Tokenize endpoint', b'1', 'epg.payments.tokenizeurl', 'String', b'0', 'https://staging.easypaymentgateway.com/EPGCheckout/rest/online/tokenize'),
	(66, 0, 'UK only. The max number of players with same fields.  0 = disable checks, 1 = no dupes, 3= max 3 dupes etc.', b'1', 'api.duplicates.max', 'Integer', b'1', '3');

