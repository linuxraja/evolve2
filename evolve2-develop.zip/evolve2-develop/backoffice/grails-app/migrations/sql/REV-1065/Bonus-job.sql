DROP PROCEDURE IF EXISTS bonus_status_check_job;
/

CREATE PROCEDURE `bonus_status_check_job`()
begin
DECLARE done INT DEFAULT 0;
declare v_id bigint(20);
declare cur1 cursor for select id From bonus where status in (1, 2, 3) and end_time <= now();
declare cur2 cursor for select id From bonus where bonus_type in (1,2,5,6,7,9,8) and status = 2 and start_time <= now();
declare continue handler for not found set done=1;
    open cur1;
      igmLoopC1: loop
          fetch cur1 into v_id;
             if done = 1 then leave igmLoopC1;
             end if;
             update bonus set status = 5 where id=v_id;
      end loop igmLoopC1;
    close cur1;
    set done=0;
    open cur2;
      igmLoopC2: loop
        fetch cur2 into v_id;
          if done = 1 then leave igmLoopC2;
          end if;
          update bonus set status = 1 where id=v_id;
        end loop igmLoopC2;
    close cur2;
END
/