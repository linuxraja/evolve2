package com.nektan.revolve.backoffice

class SessionJob {

    def paramService
    def sessionService

    static triggers = {
        simple startDelay: 1000 * 60, repeatInterval: 1000 * 60
    }

    def execute() {
      sessionService.invalidateOldSessions()
    }
}
