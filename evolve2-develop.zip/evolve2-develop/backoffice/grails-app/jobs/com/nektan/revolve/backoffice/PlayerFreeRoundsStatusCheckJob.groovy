package com.nektan.revolve.backoffice

import com.nektan.revolve.services.ParamService
import com.nektan.revolve.services.PlayerBonusService
import com.nektan.revolve.services.PlayerFreeRoundsService;

class PlayerFreeRoundsStatusCheckJob {
    
	PlayerFreeRoundsService playerFreeRoundsService
	ParamService paramService

	static triggers = {
        simple repeatInterval: 1000 * 60 * 60
    }
	
	def execute() {
		boolean run = paramService.getBoolean('player.freeRounds.statusCheck.schedule.enable')
		if (run) {
			log.info ("Scheduled Player free rounds status check Job running at " + (new Date()).toString())
			playerFreeRoundsService.checkForExpirationAndActivatePending()
		}
	}
}
