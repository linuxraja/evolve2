package com.nektan.revolve.backoffice

class StatisticsJob {

	def statisticsService

    def execute() {
	    statisticsService.updateData()
    }
}
