package com.nektan.revolve.backoffice

class OperatorExpiryJob {

	def operatorService

    static triggers = {
        simple repeatInterval: 1000 * 60 * 60 * 12
//        simple repeatInterval: 1000 * 60
    }

    def execute() {
        log.info("Starting Operator Expiry Job starting at."+ (new Date()).toString())
	    operatorService.expirePasswords()
    }
}
