package com.nektan.revolve.backoffice

import com.nektan.revolve.services.ParamService
import com.nektan.revolve.services.PlayerBonusService;

class PlayerBonusStatusCheckJob {
    
	PlayerBonusService playerBonusService
	ParamService paramService

	static triggers = {
        simple repeatInterval: 1000 * 60 * 60
    }
	
	def execute() {
		boolean run = paramService.getBoolean('player.bonus.statusCheck.schedule.enable')
		if (run) {
			log.info ("Scheduled Player bonus status check Job running at " + (new Date()).toString())
			playerBonusService.checkForExpirationAndActivatePending()
		}
	}
}
