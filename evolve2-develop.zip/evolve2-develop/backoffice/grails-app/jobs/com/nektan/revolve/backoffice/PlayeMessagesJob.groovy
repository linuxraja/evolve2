/*
package com.nektan.revolve.backoffice

import com.nektan.revolve.services.ExternalPusherService
import com.nektan.revolve.services.ParamService

*/
/**
 * Created by aniketh.chilke on 10/31/2018.
 *//*

class PlayeMessagesJob {

    ExternalPusherService externalPusherService
    ParamService paramService

    static triggers = {
        // every one min
        simple startDelay: 1000 * 60, repeatInterval: 60000
    }

    def execute() {
         boolean run = paramService.getBoolean('pusher.notifications.schedule.enable')
         if (run) {
             log.info ("PlayeMessagesJob execute Scheduled Player notifications Job running at " + (new Date()).toString())
             long startTime = System.currentTimeMillis();
             externalPusherService.pushPlayerMessagesFromJob();
             log.info("PlayeMessagesJob execute Scheduled Player notifications Job completed In " + (System.currentTimeMillis() - startTime) + " MS");
        }
    }
}
*/
