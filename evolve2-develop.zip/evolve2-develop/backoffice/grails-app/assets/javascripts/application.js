// This is a manifest file that'll be compiled into application.js.
//
// Any JavaScript file within this directory can be referenced here using a relative path.
//
// You're free to add application-wide JavaScript to this file, but it's generally better 
// to create separate JavaScript files as needed.
//
//= require jquery-2.1.1
//= require_tree .
//= require_self

if (typeof jQuery !== 'undefined') {
	$(document).ajaxStart(function () {
		$('#spinner').show();
	}).ajaxComplete(function () {
		$('#spinner').fadeOut("fast");
	}).ajaxError(function () {
		$('#spinner').fadeOut("fast");
	});
}


if (!Date.prototype.adjustDate) {
	Date.prototype.adjustDate = function (days) {
		var date;

		days = days || 0;

		if (days === 0) {
			date = new Date(this.getTime());
		} else if (days > 0) {
			date = new Date(this.getTime());
			date.setDate(date.getDate() + days);
		} else {
			date = new Date(
					this.getFullYear(),
					this.getMonth(),
					this.getDate() - Math.abs(days),
					this.getHours(),
					this.getMinutes(),
					this.getSeconds(),
					this.getMilliseconds()
			);
		}
		this.setTime(date.getTime());
		return this;
	};
}