package com.nektan.revolve.backoffice

import grails.plugin.springsecurity.annotation.Secured
import org.apache.commons.lang.StringUtils
import wslite.soap.SOAPFaultException

import com.nektan.revolve.api.ReturnCodes
import com.nektan.revolve.coreservices.GameRound
import com.nektan.revolve.services.GameRoundService
import com.nektan.revolve.services.GameTransactionService
import com.nektan.revolve.services.PlayerBonusService
import com.nektan.revolve.services.ParamService
import com.nektan.revolve.services.PlayerService
import com.nektan.revolve.coreservices.Player

import wslite.soap.SOAPClient
import wslite.soap.SOAPResponse
import wslite.http.HTTPRequest
import wslite.http.HTTPResponse
import wslite.http.HTTPClientException
import wslite.http.auth.HTTPBasicAuthorization

@Secured(['ROLE_PERMISSION_TRANSACTIONS_GLOBAL_VIEW'])
class QuickFireAdminController {

	static String QUICKFIRE_WSDL_URL	='QUICKFIRE_WSDL_URL'
	static String QUICKFIRE_WSDL_USERNAME	='QUICKFIRE_WSDL_USERNAME'
	static String QUICKFIRE_WSDL_PASSWORD	='QUICKFIRE_WSDL_PASSWORD'
	static String QUICKFIRE_SERVERID	='QUICKFIRE_SERVERID'
	
	ParamService paramService
	GameRoundService gameRoundService
	GameTransactionService gameTransactionService
	PlayerService playerService
	PlayerBonusService playerBonusService
	def client
	private def send(String action, Closure cl) {
        withExceptionHandler {
            sendWithLogging(action, cl)
        }
    }

    private SOAPResponse sendWithLogging(String action, Closure cl) {
        SOAPResponse response = client.send(SOAPAction: action, cl)
        log(response?.httpRequest, response?.httpResponse)
        return response
    }

    private SOAPResponse withExceptionHandler(Closure cl) {
        try {
            cl.call()
        } catch (SOAPFaultException soapEx) {
			log(soapEx.httpRequest,soapEx.httpResponse)           
            def message = soapEx.hasFault() ? soapEx.fault.text() : soapEx.message
            //throw new Exception(message)
        } catch (HTTPClientException  httpEx) {
			log(httpEx.httpRequest,httpEx.httpResponse)			
			 //throw new Exception("a")
        }
    }

    private void log(HTTPRequest request, HTTPResponse response) {
        log.info("HTTPRequest $request with content:\n${request?.contentAsString}")
        log.info("HTTPResponse $response with content:\n${response?.contentAsString}")
    }
	//def proxy
    def getRollbackQueueData() { 
		client = getSoapClient()	
		def response = send("http://mgsops.net/AdminAPI_Admin/IVanguardAdmin2/GetRollbackQueueData") {		    
		    soapNamespacePrefix "soapenv" 		   
			envelopeAttributes ("xmlns:adm":"http://mgsops.net/AdminAPI_Admin","xmlns:arr":"http://schemas.microsoft.com/2003/10/Serialization/Arrays")		   
		    body {
		        'adm:GetRollbackQueueData'{
		            'adm:serverIds'{
						'arr:int'(paramService.getInt("QUICKFIRE_SERVERID"))
		            }
		        }
		    }
		}			
		def queueDataResp=response?.GetRollbackQueueDataResponse?.GetRollbackQueueDataResult
		List responsList=new ArrayList()	
		def respList=null
		queueDataResp?.QueueDataResponse?.each{
			if(it  && it.LoginName!=null && it.LoginName!=''){
				respList=[:]
				Player p=playerService.findById(Long.valueOf(''+it.LoginName))
				respList['email']=p.email				
				def gRound=p.id+'-'+it.TransactionNumber
				respList['userName']=gRound
				respList['amount']=it.PayoutAmount?it.PayoutAmount:it.ChangeAmount
				respList['gameName']=it.GameName
				respList['rowId']=it.RowId
				respList['externalTransactionId']=it.MgsPayoutReferenceNumber?it.MgsPayoutReferenceNumber:it.MgsReferenceNumber
				respList['userId']=it.UserId
				responsList.add(respList)
			}		
		}
		render(view: 'list', model:[quickFireInstances: responsList,type:'rollback'])
	}
	def update(){	
		List<ManullyCompleteGame> listQueData=new ArrayList<ManullyCompleteGame>();
		List<ManullyCompleteGame> listData=new ArrayList<ManullyCompleteGame>();
		if(params.userUpdate){
			int serverId = paramService.getInt("QUICKFIRE_SERVERID")
			for(String userDat:params.list('userUpdate')){
				
				if(userDat.length()>0 && userDat.split("\\|\\|").length>1){
					String[] user=userDat.split("\\|\\|")		
							
					String email=user[0]
					String rowId=user[1]
					String userId=null
					String gameName=null
					String externalTransactionId=null
					long amount=0
					if(user.length>2){
						userId=user[2]
						externalTransactionId=user[3]
						gameName=user[4]
						amount=Long.valueOf(user[5])
						amount=amount/100
					}
					GameRound gameRound = GameRound.findByExternalRoundId(email)
					String gameSessionToken=gameRound?.gameSession?.token
					if(params.type=='rollback'){
						def results=gameTransactionService.submitRollback(gameSessionToken,rowId,'QUICKFIRE_RGS',gameName)
						if( results.returnCode == ReturnCodes.Code.OK ) {
							def exttransactionid=results.transaction !=null ? results.transaction.id : results.bonusTransaction.id
							listQueData.add(new ManuallyValidateBet(externalReference:exttransactionid,rowId:rowId,
							serverId:serverId,unlockType:'RollbackQueue',userId:userId))
						}
					}else if(params.type=='win'){
	
						double amt=amount/100
						def results = gameTransactionService.submitWin(
								gameSessionToken,
								"QUICKFIRE_RGS",
								gameName,
								email,
								rowId,
								new BigDecimal(amount ),
								"")
						if( results.returnCode == ReturnCodes.Code.OK ) {
							def exttransactionid=results.transaction !=null ? results.transaction.id : results.bonusTransaction.id
							listQueData.add(new ManuallyValidateBet(externalReference:exttransactionid,rowId:rowId,
							serverId:serverId,unlockType:'CommitQueue',userId:userId))
						}
					}else{
						if(gameRound && gameRound.isActive()){
							gameRoundService.closeGameRound(gameRound, 1)
							playerBonusService.detachGameRound(gameRound)
						}
						listData.add(new ManullyCompleteGame(serverId:serverId,rowId:rowId))
					}
				}
			}
			if(params.type=='endgame'){
				if(listData){
					getManuallyCompleteGame(listData)
				}
				redirect(action: 'getFailedEndGameQueue', params: null)
			}else{
				if(listQueData){
					getManuallyValidateBet(listQueData)
				}
				if(params.type=='win'){
					redirect(action: 'getCommitQueueData', params: null)					
				}else{
					redirect(action: 'getRollbackQueueData', params: null)					
				}
			}
		}else{
			if(params.type=='endgame'){
				redirect(action: 'getFailedEndGameQueue', params: null)
			}else if(params.type=='win'){
				redirect(action: 'getCommitQueueData', params: null)	
			}else{
				redirect(action: 'getRollbackQueueData', params: null)	
			}
		}
		
	}
	def getCommitQueueData() {
		client = getSoapClient()
		def response =send("http://mgsops.net/AdminAPI_Admin/IVanguardAdmin2/GetCommitQueueData") {			
			soapNamespacePrefix "soapenv"      // "soap-env" is default			
			envelopeAttributes ("xmlns:adm":"http://mgsops.net/AdminAPI_Admin","xmlns:arr":"http://schemas.microsoft.com/2003/10/Serialization/Arrays")		   
			body {
				'adm:GetCommitQueueData'{
					'adm:serverIds'{
						'arr:int'(paramService.getInt("QUICKFIRE_SERVERID"))//(paramService.getString("QUICKFIRE_SERVERID"))
		            }
				}
			}
		}
		def queueDataResp=response?.GetCommitQueueDataResponse?.GetCommitQueueDataResult
		println response?.GetCommitQueueDataResponse
		List responsList=new ArrayList()
		def respList=null
		queueDataResp?.QueueDataResponse?.each{
			if(it  && it.LoginName!=null && it.LoginName!=''){
				respList=[:]
				println(it)
				Player p=playerService.findById(Long.valueOf(''+it.LoginName))
				respList['email']=p.email
				def gRound=p.id+'-'+it.TransactionNumber
				respList['userName']=gRound
				def amount=it.ChangeAmount
				respList['amount']=amount
				respList['gameName']=it.GameName
				respList['rowId']=it.RowId
				respList['externalTransactionId']=it.RowId
				respList['userId']=it.UserId
				responsList.add(respList)
			}	
		}		
		render(view: 'list', model:[quickFireInstances: responsList,type:'win'])
	}
	
	private def getManuallyValidateBet(List<ManuallyValidateBet> manualValidateBetRequests) {
		def client = getSoapClient()		
		def response = client.send(SOAPAction: "http://mgsops.net/AdminAPI_Admin/IVanguardAdmin2/ManuallyValidateBet") {			
			soapNamespacePrefix "soapenv"      // "soap-env" is default			
			envelopeAttributes ("xmlns:adm":"http://mgsops.net/AdminAPI_Admin","xmlns:arr":"http://schemas.microsoft.com/2003/10/Serialization/Arrays",'xmlns:ori':"http://schemas.datacontract.org/2004/07/Orion.Contracts.VanguardAdmin.DataStructures")
			
			body {
				'adm:ManuallyValidateBet' {
					'adm:validateRequests'{
						for(ManuallyValidateBet mb:manualValidateBetRequests){							
							'ori:ValidteBetRequest'{
								'ori:ExternalReference'(mb.externalReference)
								'ori:RowId'(mb.rowId)
								'ori:ServerId'(mb.serverId)
								'ori:UnlockType'(mb.unlockType)
								'ori:UserId'(mb.userId)
							}
						}
					}
				}
			}
		}
		return response?.ManuallyValidateBet
	}
	
	def getFailedEndGameQueue() {
		def client = getSoapClient()
		def response = client.send(SOAPAction: "http://mgsops.net/AdminAPI_Admin/IVanguardAdmin2/GetFailedEndGameQueue") {			
			soapNamespacePrefix "soap-env"      // "soap-env" is default			
			envelopeAttributes ("xmlns:adm":"http://mgsops.net/AdminAPI_Admin","xmlns:arr":"http://schemas.microsoft.com/2003/10/Serialization/Arrays")			
			body {
				'adm:GetFailedEndGameQueue'('xmlns:adm':"http://mgsops.net/AdminAPI_Admin") {
					'adm:serverIds'{
						'arr:int'(paramService.getInt("QUICKFIRE_SERVERID"))//(paramService.getString("QUICKFIRE_SERVERID"))
		            }
				}
			}
		}
		def queueDataResp=response?.GetFailedEndGameQueueResponse?.GetFailedEndGameQueueResult
		
		List responsList=new ArrayList()
		def respList=[]
		queueDataResp?.GetFailedGamesResponse?.each{
			if(it  && it.UniqueId!=null && it.UniqueId!=''){
				if(StringUtils.isNumeric(Long.valueOf(''+it.UniqueId))) {
						Player p = playerService.findById(Long.valueOf(''+it.UniqueId))
						def gRound = p.id + '-' + it.TransNumber
						respList.email = p.email
						respList.userName=gRound
					respList.rowId=it.RowId
					responsList.add(respList)
				}
			}
		}			
		render(view: 'list', model:[quickFireInstances: responsList,type:'endgame'])
	}
	
	private Boolean getManuallyCompleteGame(List<ManullyCompleteGame> completeGameList){
		def client = getSoapClient()		
		def response = client.send(SOAPAction: "http://mgsops.net/AdminAPI_Admin/IVanguardAdmin2/ManuallyCompleteGame") {		
			soapNamespacePrefix "soapenv"      // "soap-env" is default			
			envelopeAttributes ("xmlns:adm":"http://mgsops.net/AdminAPI_Admin",'xmlns:ori':"http://schemas.datacontract.org/2004/07/Orion.Contracts.VanguardAdmin.DataStructures")
		
			body {
				'adm:ManuallyCompleteGame'{
					'adm:requests'{
						for(ManullyCompleteGame mcg:completeGameList){			
							'ori:CompleteGameRequest'(){								
								'ori:RowId'(mcg.rowId)
								'ori:ServerId'(mcg.serverId)						
							}
						}
					}
				}
			}
		}
		return response?.ManuallyCompleteGame?.CompleteGameResponse
		
	}
	
	class ManuallyValidateBet{
		def externalReference
		def rowId
		def serverId
		def unlockType
		def userId
	}
	class ManullyCompleteGame{
		def rowId
		def serverId
	}
	
	private def getSoapClient(){
		String SOAPclient = paramService.getString("QUICKFIRE_WSDL_URL")//paramService.getString("QUICKFIRE_WSDL_URL")
		String userName = paramService.getString("QUICKFIRE_WSDL_USERNAME")
		String passd =  paramService.getString("QUICKFIRE_WSDL_PASSWORD")
		

		SOAPClient client = new SOAPClient(SOAPclient)
		client.httpClient.defaultHeaders['Request-Id'] = UUID.randomUUID().toString()
		client.authorization = new HTTPBasicAuthorization( userName, passd )
			
		return client
	}
	
}
