package com.nektan.revolve.api.evolve1

import com.nektan.revolve.api.APIReturnCode
import com.nektan.revolve.api.v1.ApiController
import com.nektan.revolve.api.EvolveConstants
import com.nektan.revolve.coreservices.Session
import com.nektan.revolve.extras.CalendarUtility
import com.nektan.revolve.services.AccountService
import com.nektan.revolve.services.PlayerBonusService
import com.nektan.revolve.services.PlayerService
import com.nektan.revolve.services.SessionService
import com.nektan.revolve.services.TransactionService
import com.nektan.revolve.services.TransactionWHService
import grails.converters.JSON
import grails.plugin.springsecurity.annotation.Secured


@Secured(['permitAll'])
class HistoryController extends ApiController implements EvolveConstants {

	public static namespace = 'evolve1'

	static allowedMethods = [
			initialise: 'GET',
			result    : 'POST'
	]

	SessionService sessionService
	AccountService accountService
	PlayerService playerService
	TransactionService transactionService
	PlayerBonusService playerBonusService
	TransactionWHService transactionWHService

    static int DEFAULT_PAGE_SIZE = 100

	def gameHistory() {
		def payload = request.JSON
		Session session = getEvolvePlayerSession()
		if (session == null || !session.isActive()) {
			createErrorResponse(APIReturnCode.INVALID_SESSION)
			return
		}
		try{
			def results = transactionService.findGameTransactions(session.player, session.site, getPageSize(payload.pageSize))
			def whResults = transactionWHService.getWHGameHistory(session.player)

			try{
                JSON.use('gametransaction') {
                    render( status: 200, contentType: 'application/json') {
                        gamehistoryJSONResponse( results ,whResults)
                    }
                }
            } catch(Exception _exp){
                log.error("gameHistory: Rendering Response for Player Id: " + session?.player?.id + " Exception: " + _exp.getMessage())
                createErrorResponse(APIReturnCode.ERROR)
                return
            }
		} catch(Exception _exp){
			log.error("gameHistory: Player Id: " + session?.player?.id + " Exception: " + _exp.getMessage())
			createErrorResponse(APIReturnCode.ERROR)
			return
		}

	}

	def jackpotWinningHistory() {
		def payload = request.JSON
		Session session = getEvolvePlayerSession()
		if (session == null || !session.isActive()) {
			createErrorResponse(APIReturnCode.INVALID_SESSION)
			return
		}

		def results = transactionService.findJackpotWinningTransactions(session.player, session.site, getPageSize(payload.pageSize))

		JSON.use('jackpotwinningtransactions') {
			render( status: 200, contentType: 'application/json') {
				jackpotWinningHistoryJSONResponse( results )
			}
		}
	}

	def bonusHistory() {
		def payload = request.JSON
		Session session = getEvolvePlayerSession()
		if (session == null || !session.isActive()) {
			createErrorResponse(APIReturnCode.INVALID_SESSION)
			return
		}
        try{
			params.setProperty("isHistory", true)
            def results = playerBonusService.find(session.player, params)
            try{
                render( status: 200, contentType: 'application/json') {
                    bonusJSONResponse( results )
                }
            } catch(Exception _exp){
                log.error("bonusHistory: Rendering Response for Player Id: " + session?.player?.id + " Exception: " + _exp.getMessage())
                createErrorResponse(APIReturnCode.ERROR)
                return
            }
        } catch(Exception _exp){
            log.error("bonusHistory: Player Id: " + session?.player?.id + " Exception: " + _exp.getMessage())
            createErrorResponse(APIReturnCode.ERROR)
            return
        }

	}

	def cashRewardsHistory() {
		def payload = request.JSON
		Session session = getEvolvePlayerSession()
		if (session == null || !session.isActive()) {
			createErrorResponse(APIReturnCode.INVALID_SESSION)
			return
		}
        try{
            def cashRewardResults = transactionService.findCashRewardTransactions(session.player,session.site,getPageSize(payload.pageSize))
            try{
                JSON.use('financialtransaction') {
                    render(status: 200, contentType: 'application/json') {
                        cashRewardJSONResponse( cashRewardResults )
                    }
                }
            } catch(Exception _exp){
                log.error("cashRewardsHistory: Rendering Response for Player Id: " + session?.player?.id + " Exception: " + _exp.getMessage())
                createErrorResponse(APIReturnCode.ERROR)
                return
            }
        } catch(Exception _exp){
            log.error("cashRewardsHistory: Player Id: " + session?.player?.id + " Exception: " + _exp.getMessage())
            createErrorResponse(APIReturnCode.ERROR)
            return
        }

	}

	def financialTransactionHistory() {
		def payload = request.JSON
		Session session = getEvolvePlayerSession()
		if (session == null || !session.isActive()) {
			createErrorResponse(APIReturnCode.INVALID_SESSION)
			return
		}
        try{
            def results = transactionService.findFinancialTransactions(session.player, session.site,getPageSize(payload.pageSize))
			def whResults = transactionWHService.getWHAccountHistory(session.player)
            try{
                JSON.use('financialtransaction') {
                    render(status: 200, contentType: 'application/json') {
                        transactionJSONResponse(results,whResults)
                    }
                }
            } catch(Exception _exp){
                log.error("financialTransactionHistory: Rendering Response for Player Id: " + session?.player?.id + " Exception: " + _exp.getMessage())
                createErrorResponse(APIReturnCode.ERROR)
                return
            }
        } catch(Exception _exp){
            log.error("financialTransactionHistory: Player Id: " + session?.player?.id + " Exception: " + _exp.getMessage())
            createErrorResponse(APIReturnCode.ERROR)
            return
        }

	}

	/**
	 * Fetches players game transactions in specified date range,
	 * date range should be less than 90 days, if not returns error
	 * @return
	 */
	def getHistoricalGameHistory() {
		def payload = request.JSON
		Session session = getEvolvePlayerSession()
		if (session == null || !session.isActive()) {
			createErrorResponse(APIReturnCode.INVALID_SESSION)
			return
		}

		if (null==payload.from || null==payload.to) {
			createErrorResponse(APIReturnCode.INVALID_PARAMS)
			return
		}

		Date from = CalendarUtility.convertStringToDate(payload.from,"yyyy-MM-dd")
		Date to = CalendarUtility.convertStringToDate(payload.to,"yyyy-MM-dd")
		if (!isValidDateRange(from,to)) {
			createErrorResponse(APIReturnCode.HISTORY_DATES_NOT_IN_RANGE)
			return
		}
		try{
			def results = transactionWHService.getHistoricalGameHistory(session.player, from, to)

			try{
					render( status: 200, contentType: 'application/json') {
						gameHistoryInRangeJSONResponse( results )
					}
			} catch(Exception _exp){
				log.error("getHistoricalGameHistory: Rendering Response for Player Id: " + session?.player?.id + " Exception: " + _exp.getMessage())
				createErrorResponse(APIReturnCode.ERROR)
				return
			}
		} catch(Exception _exp){
			log.error("getHistoricalGameHistory: Player Id: " + session?.player?.id + " Exception: " + _exp.getMessage())
			createErrorResponse(APIReturnCode.ERROR)
			return
		}

	}

	/**
	 * Fetches players account transactions in specified date range,
	 * date range should be less than 90 days, if not returns error
	 * @return
	 */
	def getHistoricalAccountHistory() {
		def payload = request.JSON
		Session session = getEvolvePlayerSession()
		if (session == null || !session.isActive()) {
			createErrorResponse(APIReturnCode.INVALID_SESSION)
			return
		}

		if (null==payload.from || null==payload.to) {
			createErrorResponse(APIReturnCode.INVALID_PARAMS)
			return
		}

		Date from = CalendarUtility.convertStringToDate(payload.from,"yyyy-MM-dd")
		Date to = CalendarUtility.convertStringToDate(payload.to,"yyyy-MM-dd")
		if (!isValidDateRange(from,to)) {
			createErrorResponse(APIReturnCode.HISTORY_DATES_NOT_IN_RANGE)
			return
		}
		try{
			def results = transactionWHService.getHistoricalAccountHistory(session.player, from, to)

			try{
				render( status: 200, contentType: 'application/json') {
					accountHistoryInRangeJSONResponse( results )
				}
			} catch(Exception _exp){
				log.error("getHistoricalAccountHistory: Rendering Response for Player Id: " + session?.player?.id + " Exception: " + _exp.getMessage())
				createErrorResponse(APIReturnCode.ERROR)
				return
			}
		} catch(Exception _exp){
			log.error("getHistoricalAccountHistory: Player Id: " + session?.player?.id + " Exception: " + _exp.getMessage())
			createErrorResponse(APIReturnCode.ERROR)
			return
		}

	}



	def bonusJSONResponse(def bonuses) {
		def response = [
				"playerBonus": bonuses.each { it }
		]
		return response
	}

	def cashRewardJSONResponse(def cashRewardResults) {
		def response = [
                "numPages": 0,
				"cashRewardsHistoryList": cashRewardResults.each { it }
		]
		return response
	}


	def transactionJSONResponse(def transactions,def whResults ){
		def response = [
				"numPages": 0,
				"totalDeposits" : whResults?.totalDeposits,
				"totalWithdrawals": whResults?.totalWithdrawals,
				"totalNetAdjustments" : whResults?.totalNetAdjustments,
				"transactionHistoryList": transactions.each { it }
		]
		return response
	}


	def gamehistoryJSONResponse(def games,def whResults ){
		def response = [
				"totalStakes" : whResults?.totalStakes,
				"totalReturns":whResults?.totalReturns,
				"gameHistoryList": games.each { it }
		]
		return response
	}

	def jackpotWinningHistoryJSONResponse(def jackpotWinnings ){
		def response = [
				"jackpotWinningHistoryList": jackpotWinnings.each { it }
		]
		return response
	}

	def gameHistoryInRangeJSONResponse(def results ){
		return results
	}

	def accountHistoryInRangeJSONResponse(def results ){
		return results
	}

	/**
	 * page size verification to restrict to be less than 100
	 * @param requestedPageSize
	 * @return
	 */
	private int getPageSize(int requestedPageSize){
		int pageSize = (requestedPageSize >0 && requestedPageSize <=100) ? requestedPageSize:DEFAULT_PAGE_SIZE
		return pageSize
	}

	/**
	 * 90 days validation
	 * @param fromDate
	 * @param toDate
	 * @return
	 */
	private boolean isValidDateRange(Date fromDate,Date toDate){
			int numberOfDays = CalendarUtility.getDaysDifference(fromDate,toDate)
			if(numberOfDays<=90){
				return true;
			}
			return false;
	}
}
