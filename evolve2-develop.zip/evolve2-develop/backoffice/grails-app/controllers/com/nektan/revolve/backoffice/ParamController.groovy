package com.nektan.revolve.backoffice
import com.nektan.revolve.coreservices.Param
import com.nektan.revolve.services.ParamService
import grails.plugin.springsecurity.annotation.Secured

@Secured(['ROLE_PERMISSION_SYSTEM_EDIT'])
class ParamController {

    def scaffold = Param
    ParamService paramService


    def search(params) {
        List<Param> paramList = paramService.search(params)
        if (paramList == null || paramList.isEmpty()) {
            render(view: 'index', model: [params: params, paramInstanceCount: 0])
        } else {
            render(view: 'index', model: [params: params, paramInstanceList: paramList, paramInstanceCount: paramList.size(), paramCount: paramList.getTotalCount()])
        }
    }
}
