package com.nektan.revolve.api.v1

import com.nektan.revolve.api.ReturnCodes
import com.nektan.revolve.api.geofence.Point
import com.nektan.revolve.coreservices.Site
import grails.converters.JSON
import grails.plugin.springsecurity.annotation.Secured

@Secured(['permitAll'])
class GeoFenceController extends ApiController {

	static namespace = 'v1'

	def geoFenceService
	def siteService

	def siteAtLocation() {
		def payload = request.JSON

		try {

			String[] requiredParams = ["x", "y"]
			String paramError = checkParams(payload, requiredParams)
			if (paramError != null) {
				renderError(ReturnCodes.Code.INVALID_PARAMS, paramError)
				return
			}

			Point location = new Point(Double.parseDouble(payload.x), Double.parseDouble(payload.y))
			Site site = geoFenceService.getSiteAtLocation(location)

			if (site) {
				render(status: 200, contentType: 'application/json') {
					['result': ReturnCodes.Code.OK.value(), 'description': 'Site found', "site": site.shortName, "geocomply": site.geocomply, "minAge": siteService.getInheritedValue(site, "minAge"), "maxIdle": siteService.getInheritedValue(site, "maxIdle")]
				}
			} else {
				render(status: 200, contentType: 'application/json') {
					['result': ReturnCodes.Code.NO_SITE_FOUND_AT_LOCATION.value(), 'description': 'No site found at location']
				}
			}
        } catch (Exception e) {
			renderError(ReturnCodes.Code.ERROR, e.toString())
			log.error("siteAtLocation API Error:" +  e.toString(), e)
		}
	}


	def isInLocation() {
		def payload = request.JSON

		try {

			String[] requiredParams = ["site","x", "y"]
			String paramError = checkParams(payload, requiredParams)
			if (paramError != null) {
				renderError(ReturnCodes.Code.INVALID_PARAMS, paramError)
				return
			}

			def site = siteService.getSite( payload.site )
			Point playerLocation = new Point( Double.parseDouble( payload.x),Double.parseDouble( payload.y) )
			boolean isInLocation = geoFenceService.isInGeoFence( site, playerLocation )

			if ( isInLocation ) {
				render(status: 200, contentType: 'application/json') {
					['result': ReturnCodes.Code.PLAYER_IS_IN_LOCATION.value(), 'description': 'Player is in location', ]
				}
			} else {
				render(status: 200, contentType: 'application/json') {
					['result': ReturnCodes.Code.PLAYER_IS_NOT_IN_LOCATION.value(), 'description': 'Player is not in location']
				}
			}

		} catch (Exception e) {
			renderError(ReturnCodes.Code.ERROR, e.toString())
			log.error("siteAtLocation API Error:" +  e.toString(), e)
		}
	}
}
