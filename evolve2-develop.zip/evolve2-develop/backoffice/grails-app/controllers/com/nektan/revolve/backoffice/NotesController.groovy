package com.nektan.revolve.backoffice

import com.nektan.revolve.coreservices.Note
import com.nektan.revolve.coreservices.NoteType
import com.nektan.revolve.coreservices.Operator
import com.nektan.revolve.coreservices.Player
import com.nektan.revolve.coreservices.Site
import com.nektan.revolve.services.EventLogService
import grails.plugin.springsecurity.annotation.Secured
import com.nektan.revolve.services.EventLogService

@Secured('ROLE_PERMISSION_NOTES_VIEW')
class NotesController {

    def scaffold = Note

    def notesService
    def playerService
    def operatorService
    def springSecurityService

    EventLogService eventLogService
    String ILLEGAL_ACCESS = "Illegal access. Unathorsized attempt to view or edit player"

    /**
     * Render the notes for a given player.
     * @return View to a widget
     */
    def index() {
        Player player = playerService.findById( params.id )
	    if (params.max == null) {
		    params.max = 10
	    }
	    redirect(action: "search", params: params, playerInstance: player)
    }

    def beforeInterceptor = [action: this.&checkAuthorised, only: ['create','filter','search']]

    private checkAuthorised() {

        Operator currentLoggedInUser = springSecurityService.getCurrentUser();

        Player player

        if (params.id) {
            player = playerService.findById(params.id)
        }
        List sites = operatorService.operatingSites(currentLoggedInUser)

        boolean found

        if (player != null) {
            found = sites.find { Site site -> site.id == player.site.id }
            if (!found) {
                flash.message = ILLEGAL_ACCESS + params.id
                redirect(controller: 'player', action:'search')
                return false
            }

        }

    }

	def portalHomeNotes() {
		params.max = 10
		def notes = notesService.getNotesForOperator(null, params)
		render(view:"_portalWidgetResult", model: [notesInstanceList: notes])
	}

	def filter() {
		def notes = notesService.getNotesForOperator(null, params)
		render(view:"_portalWidgetResult", model: [notesInstanceList: notes])
	}

	def search() {
		Player player = playerService.findById( params.id )
		def notes = notesService.getNotesForPlayer( player, params)
		render(view: "tab_notes", model:[notesInstanceList: notes, playerInstance: player, params: params])
	}


    /**
     * Display a selected note
     * @return
     */
    def show() {
        Long bonusID = null
        Note noteInstance = notesService.findById( params.id )
        def thread = notesService.getThreadForNote( noteInstance )
        if(noteInstance.type.shortName.equals(NoteType.SHORT_NAMES.BONUS_CHOICE)) {
            bonusID = notesService.getBonusIDFromText(noteInstance?.text)
        }
        render(view:"reply", model:[originalNote: noteInstance, notesInstanceList: thread, playerInstance: noteInstance.player,bonusId:bonusID])
    }



    /**
     * Get the full thread for this note
     * @return
     */
    def showThread() {
        Note noteInstance = notesService.findById( params.id )
        def notesInstanceList = notesService.getThreadForNote( noteInstance )
        render(view: "tab_notes", model:[notesInstanceList: notesInstanceList, playerInstance: noteInstance.player, params: params])
    }


    def create() {
        Operator currentLoggedInUser = springSecurityService.getCurrentUser();
        Player player = playerService.findById( params.id )
        def noteTypes = NoteType.list()

        render(view:"create", model:[ operator: currentLoggedInUser, noteTypes: noteTypes, playerInstance: player, params: params])
    }


    /**
     * Create a new note for this player
     * @return
     */
    def save() {
        Operator currentLoggedInUser = springSecurityService.getCurrentUser();
        Player player = playerService.findById( params.player )
        NoteType noteType = NoteType.findById(Long.parseLong(params.type))
        params.playerId = player.id

        Note note = notesService.create( player, currentLoggedInUser, noteType, params.text, Integer.parseInt( params.severityLevel ), null, Integer.parseInt(params.contactChannel))

        if ( note.hasErrors() ) {
            render(view:"create", model:[autor: currentLoggedInUser, playerInstance: player, noteInstance: note, params: params])
        } else {
            redirect(view: "index", params:[id:player.id])
        }
    }


    /**
     * Create repply to note
     * @return
     */
    def reply() {
        Operator currentLoggedInUser = springSecurityService.getCurrentUser();
        Note original = notesService.findById( params.parent )
        Note note = notesService.saveReply( original.player, currentLoggedInUser, params.text, original.parent, original.transaction)
        def notesInstanceList = notesService.getThreadForNote( original )

        if ( note.hasErrors() ) {
            render(view:"reply", model:[originalNote: original, notesInstanceList: notesInstanceList, playerInstance: original.player, noteInstance: note, params: params])
        } else {
            render(view:"reply", model:[originalNote: original, notesInstanceList: notesInstanceList, playerInstance: original.player, params: params])
        }
    }

    /**
     * Mark an note as closed
     * @return
     */
    def close() {
        Note noteInstance = notesService.findById( params.noteId )
        def thread = notesService.getThreadForNote( noteInstance )

        thread.each { note ->
            note.open = false
            note.save(flush: true)
        }

        render(view:"reply", model:[originalNote: noteInstance, notesInstanceList: thread, playerInstance: noteInstance.player, params: params])
    }

}
