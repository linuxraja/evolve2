package com.nektan.revolve.backoffice

import com.nektan.revolve.coreservices.OperatorManualAdjAmount
import com.nektan.revolve.services.EventLogService
import grails.plugin.springsecurity.annotation.Secured
import pl.touk.excel.export.WebXlsxExporter

import com.nektan.revolve.coreservices.Account
import com.nektan.revolve.coreservices.Note
import com.nektan.revolve.coreservices.NoteType
import com.nektan.revolve.coreservices.Operator
import com.nektan.revolve.coreservices.OperatorCurrencyLimits
import com.nektan.revolve.coreservices.Player
import com.nektan.revolve.coreservices.Site
import com.nektan.revolve.coreservices.Transaction
import com.nektan.revolve.coreservices.TransactionType
import com.nektan.revolve.coreservices.VoidReason
import com.nektan.revolve.extras.Utils
import java.util.*;


import java.sql.SQLException


@Secured(['ROLE_PERMISSION_TRANSACTIONS_GLOBAL_VIEW'])
class TransactionController {

    def scaffold = Transaction

    def springSecurityService
    def transactionService
    def accountService
    def playerService
    def notesService
    def paramService
    def operatorService
    def exchangeRateService
    def exportService
    def grailsApplication
    def siteService
    EventLogService eventLogService
    String ILLEGAL_ACCESS = "Illegal access. Unauthorized attempt to view transaction"
    static mapExtensionFormat = ['pdf': 'pdf', 'csv': 'csv']

    /**
     * Show transaction search form
     * @return
     */
    @Secured(['ROLE_PERMISSION_TRANSACTIONS_GLOBAL_VIEW', 'ROLE_PERMISSION_TRANSACTIONS_PLAYER_ONLY'])
    def index() {
        String view = "list"
        Player playerInstance

        if (params.view) {
            playerInstance = playerService.findById(params.id)
            view = params.view
            params.playerId = params.id
        }
        render(view: view, model: [playerInstance: playerInstance])
    }

    def beforeInterceptor = [action: this.&checkAuthorised, only: ['edit', 'update', 'save', 'details', 'index', 'search', 'find']]

    private checkAuthorised() {

        Operator currentLoggedInUser = springSecurityService.getCurrentUser();
        Set<Site> sites = new HashSet<Site>()
        if (params.id) {
            Player player = playerService.findById(params.id)
            if (player != null) {
                sites.add(player.site)
            }
        }
        if (params.playerId) {
            Player player = playerService.findById(params.playerId)
            if (player != null) {
                sites.add(player.site)
            }
        }

        if (params.site) {
            sites.addAll(Site.findAllById(params.site))
        }

        Set<Site> operatingSites = new HashSet<Site>()
        List operatorSites = operatorService.operatingSites(currentLoggedInUser)
        operatingSites.addAll(operatorSites)

        if (!operatingSites.containsAll(sites)) {
            flash.message = ILLEGAL_ACCESS + params.id
            redirect(controller:'transaction',action: 'search', model: [params: params, playerInstance: player])
            return false
        }

    }

    /**
     * Search for transactions
     * @return
     */
    @Secured(['ROLE_PERMISSION_TRANSACTIONS_GLOBAL_VIEW', 'ROLE_PERMISSION_TRANSACTIONS_PLAYER_ONLY'])
    def search() {
        String view = "list"
        Player playerInstance
        def results

        if (params.view) {
            playerInstance = playerService.findById(params.playerId)
            view = params.view
        }

        if (params.startAt?.length() == 0 && params.endAt?.length() == 0) {
            flash.message = "Please specify a start date, a end date or a date range!"
            render(view: view, model: [playerInstance: playerInstance])
            return
        }

        if (!params.site) {
            def sites = []
            operatorService.operatingSites().each() { Site site ->
                sites << "${site.id}"
            }
            params.site = sites
        }

        results = transactionService.find(params)
        render(view: view, model: [params: params, playerInstance: playerInstance, transactionCount: results.getTotalCount(), transactionInstanceList: results, transactionInstanceCount: results.size()])
    }

    /**
     * Display selected transaction
     * @return
     */
    @Secured(['ROLE_PERMISSION_TRANSACTIONS_GLOBAL_VIEW', 'ROLE_PERMISSION_TRANSACTIONS_PLAYER_ONLY'])
    def show() {
        Transaction transaction = Transaction.get(params.id)
        render(view: 'show', model: [transactionInstance: transaction])
    }

    /**
     * Void selected transaction
     * @return
     */
    @Secured(['ROLE_PERMISSION_TRANSACTIONS_GLOBAL_VIEW', 'ROLE_PERMISSION_TRANSACTIONS_PLAYER_ONLY'])
    def voidTransaction() {
        def transactionids = params.id.split(",")
        List convId = new ArrayList()
        for (int i = 0; i < transactionids.length; i++) {
            convId.add(Long.parseLong(transactionids[i]))
        }

        List<Transaction> transactionsToBeVoided = Transaction.findAllByIdInList(convId);
        List<Transaction> voidedTransactions = new ArrayList<Transaction>()
        if (transactionsToBeVoided != null && transactionsToBeVoided.size() > 1) {

            VoidReason reason = VoidReason.get(params.reason)
            voidedTransactions = transactionService.voidTransactions(transactionsToBeVoided, reason, params.note)

        } else {
            for (Transaction transaction : transactionsToBeVoided) {
                if (transaction.type.shortName != TransactionType.SHORT_NAME.withdrawal.name()) {
                    VoidReason reason = VoidReason.get(params.reason)
                    transactionService.voidTransaction(transaction, reason, params.note)
                    voidedTransactions.add(transaction)
                }
            }
        }
        if (voidedTransactions.size() > 0) {
            render(view: "_transactionVoided", model: [transactionInstance: params.id])
        } else {
            render(text: "Withdrawl/cancel withdrawl transaction cannot be voided")
        }

    }

    /**
     * Display selected transaction
     * @return
     */
    @Secured(['ROLE_PERMISSION_TRANSACTIONS_GLOBAL_VIEW', 'ROLE_PERMISSION_TRANSACTIONS_PLAYER_ONLY'])
    def details() {
        Transaction transaction = Transaction.get(params.id)
        boolean isVoidable = transactionService.isVoidable(transaction)
        NoteType notetype = NoteType.findByName(NoteType.SHORT_NAMES.VOIDING_TRANSACTION)
        Note note = Note.findByTransactionAndType(transaction, notetype)
        render(view: '_details', model: [transactionInstance: transaction, isvoidable: isVoidable, noteInstance: note])
    }

    /**
     * Display number of transactions
     * @return
     */
    @Secured(['ROLE_PERMISSION_TRANSACTIONS_GLOBAL_VIEW', 'ROLE_PERMISSION_TRANSACTIONS_PLAYER_ONLY'])
    def transactionVoidDetails() {
        def currency = null;
        def transactionids = params.id.split(",")
        List convId = new ArrayList()
        for (int i = 0; i < transactionids.length; i++) {
            convId.add(Long.parseLong(transactionids[i]))
        }
        //transactionids.collect{ Long.parseLong(it)}
        def results = Transaction.findAllByIdInList(convId);
        BigDecimal totcredit = BigDecimal.ZERO
        BigDecimal totdebit = BigDecimal.ZERO
        println results.size()
        for (Transaction tr : results) {
            totcredit = totcredit.add(tr.credit)
            totdebit = totdebit.add(tr.debit)
            if (!currency)
                currency = tr.account.currency.iso
        }

        render(view: '_transactionVoidDetails', model: [totcredit: totcredit, totdebit: totdebit, currency: currency, total: transactionids.length, transactionids: params.id])
    }

    /**
     * Create a manual adjustment to the players cash account
     */
    @Secured(['ROLE_PERMISSION_TRANSACTIONS_GLOBAL_VIEW', 'ROLE_PERMISSION_TRANSACTIONS_PLAYER_ONLY'])
    def createManualAdustment() {
        def playerInstance = playerService.findById(params.playerId)
        Account account = accountService.getAccount(params.long('accountId'))
        render(view: "createManualAdjustment", model: [playerInstance: playerInstance, params: params, accountInstance: account])

    }

    /**
     * Create the manual adjustment for the player
     * @return
     */
    @Secured(['ROLE_PERMISSION_TRANSACTIONS_GLOBAL_VIEW', 'ROLE_PERMISSION_TRANSACTIONS_PLAYER_ONLY'])
    def saveManualAdjustment() {

        Transaction transactionInstance
        Note noteInstance

        Player player = playerService.findById(params.playerId)
        Account account = accountService.getAccount(params.long('accountId'))
        Operator currentLoggedInUser = springSecurityService.getCurrentUser();
        //def manualAdjustments = operatorService.getManualAdjustmentsForToday(currentLoggedInUser, account?.currency)
        OperatorManualAdjAmount operatorManualAdjAmount = operatorService.getManualAdjustmentsForToday(currentLoggedInUser, account?.currency)
        BigDecimal credit = new BigDecimal(0)
        BigDecimal debit = new BigDecimal(0)

        if (params.credit != null) {
            credit = new BigDecimal(params.credit)
        }

        if (params.debit != null) {
            debit = new BigDecimal(params.debit)
        }

        OperatorCurrencyLimits operatorCurrencyLimits
        def currencyId = player.currency.id
        for (OperatorCurrencyLimits os : currentLoggedInUser?.operatorCurrencyLimits) {
            if (os.currency.id == currencyId) {
                operatorCurrencyLimits = os
                break
            }
        }
        if(operatorCurrencyLimits == null ||
                (credit.compareTo(BigDecimal.ZERO) > 0 && null == operatorCurrencyLimits.creditLimit) ||
                (debit.compareTo(BigDecimal.ZERO) > 0 && null == operatorCurrencyLimits.debitLimit)) {
            flash.message = "Operator has no credit or debit limits set for currency "+player.currency.iso
            render(view: "createManualAdjustment", model: [playerInstance: player, transactionInstance: transactionInstance, noteInstance: noteInstance, params: params, accountInstance: account])
            return
        }
        BigDecimal creditLimit = BigDecimal.ZERO
        BigDecimal debitLimit = BigDecimal.ZERO
        BigDecimal creditLimitCapForADay = BigDecimal.ZERO
        BigDecimal debitLimitCapForADay = BigDecimal.ZERO
        if (operatorCurrencyLimits) {
            creditLimit = operatorCurrencyLimits.creditLimit ? operatorCurrencyLimits.creditLimit : BigDecimal.ZERO
            debitLimit = operatorCurrencyLimits.debitLimit ? operatorCurrencyLimits.debitLimit : BigDecimal.ZERO
            creditLimitCapForADay = operatorCurrencyLimits.creditLimitCapForADay ? operatorCurrencyLimits.creditLimitCapForADay : BigDecimal.ZERO
            debitLimitCapForADay = operatorCurrencyLimits.debitLimitCapForADay ? operatorCurrencyLimits.debitLimitCapForADay : BigDecimal.ZERO
        }

        int dp = account.currency.decimalPlaces

        try {
            BigDecimal balance = account.balance

            if (Utils.numberOfDecimalPlaces(credit) > dp || Utils.numberOfDecimalPlaces(debit) > dp) {
                flash.message = "Values for credit or debit cannot have more than $dp decimal places"

            } else if (credit <= 0 && debit <= 0) {
                flash.message = "Values for credit or debit can't be empty or zero or negative values."

            } else if (credit > creditLimit || debit > debitLimit) {
                flash.message = "Values for credit or debit exceed your credit / debit limits for a single adjustment."

            } else if ((operatorCurrencyLimits.creditLimitCapForADay && credit + operatorManualAdjAmount.creditPerDay > creditLimitCapForADay) ||
                    (operatorCurrencyLimits.debitLimitCapForADay && debit + operatorManualAdjAmount.debitPerDay > debitLimitCapForADay)) {
                flash.message = "This transaction exceeds you daily credit / debit limit for today."
            } else if ((balance - debit) < 0) {
                flash.message = "Balance cannot be negative"
            } else {
                if (params.text != null && params.text.length() > 0) {
                    transactionInstance = accountService.createManualAdjustment(account, currentLoggedInUser, Long.parseLong(params.subType.id), credit, debit, params.description, operatorManualAdjAmount)

                    if (!transactionInstance.hasErrors()) {
                        NoteType type = NoteType.findByShortName(NoteType.SHORT_NAMES.MANUAL_TRANSACTION)
                        noteInstance = notesService.create(player, currentLoggedInUser, type, params.text, Note.SEVERITY_HIGH, null)
                        noteInstance.transaction = transactionInstance
                        noteInstance.open = false
                        noteInstance.save(flush: true)

                        if (!noteInstance.hasErrors()) {
                            redirect(controller: "player", action: "details", id: player.id)
                        }
                    }
                } else {
                    flash.message = "Internal note description is missing."
                }
            }
            render(view: "createManualAdjustment", model: [playerInstance: player, transactionInstance: transactionInstance, noteInstance: noteInstance, params: params, accountInstance: account])

        } catch (NumberFormatException e) {
            flash.message = "There's something wrong with either credit or debit value. Please check: only numbers are allowed, no letters or signs!"
            render(view: "createManualAdjustment", model: [playerInstance: player, transactionInstance: transactionInstance, noteInstance: noteInstance, params: params, accountInstance: account])
        } catch (SQLException) {
            flash.message = "SQLException occured:"
            player = playerService.findById(params.playerId)
            render(view: "createManualAdjustment", model: [playerInstance: player, params: params, accountInstance: account])
        }

    }


    @Secured(['ROLE_PERMISSION_TRANSACTIONS_GLOBAL_VIEW', 'ROLE_PERMISSION_TRANSACTIONS_PLAYER_ONLY'])
    def export() {
        //if(!params.max) params.max = 10

        def currentDate = new Date()
        def formattedDate = g.formatDate(date: currentDate, format: 'yyyy-MM-dd hh:mm:ss')

        String formatMap = mapExtensionFormat[params?.extension]

        def transactions = transactionService.find(params)
        if (formatMap && formatMap != "html") {

            if(params?.extension && (params?.extension == 'xls' || params?.extension == 'xlsx')) {
                flash.message="Excel format not supported. Please try CSV or PDF."
                [transactionInstanceList: transactions]
                return
            }
            response.contentType = grailsApplication.config.grails.mime.types[params?.extension]

            if (params.playerId) {
                Player players = playerService.findById(Long.valueOf(params.playerId))
                response.setHeader("Content-disposition", "attachment; filename=Player-${params.playerId}_${formattedDate}.${params?.extension}")
            } else {
                response.setHeader("Content-disposition", "attachment; filename=Transactions-${formattedDate}.${params?.extension}")
            }

            List fields = ["id","createdAt", "site.name","account.player", "game", "account.name", "type", "debit",
                           "credit","feeAmount","externalTransactionId",
                           "externalGameInstanceId", "balanceAfter", "operator", "sessionId", "description"]
            Map labels = ["id":"Id","site.name":"Account System","credit": "Credit", "debit": "Debit", "description":
                    "Description", "createdAt": "Created", "game": "Game", "type": "Type", "externalGameInstanceId":
                    "Game Id", "account.name": "Account", "account.player": "Player", "balanceAfter": "Bal. After",
                          "operator": "operator", "sessionId": "session Id","feeAmount":"Fee",
                          "externalTransactionId":"External Transaction Id"]

            def formatDate = { transaction, value ->
                return value.format('yyyy-MM-dd HH:mm:ss')
            }

            Map formatters = [createdAt: formatDate]
            exportService.export(formatMap, response.outputStream, transactions, fields, labels, formatters, [:])

        }

        [transactionInstanceList: transactions]
        return;

    }

    def edit() {
        redirect(action: 'index')
    }


    def create() {
        redirect(action: 'index')
    }
}

