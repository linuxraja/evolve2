package com.nektan.revolve.backoffice

import com.nektan.revolve.api.BonusRewardType
import com.nektan.revolve.api.RGSName
import com.nektan.revolve.coreservices.FreeRoundsGameConfig
import com.nektan.revolve.coreservices.FreeRoundsRgsConfig
import com.nektan.revolve.coreservices.Game
import com.nektan.revolve.coreservices.Operator
import com.nektan.revolve.coreservices.Player
import com.nektan.revolve.coreservices.PlayerBonus
import com.nektan.revolve.coreservices.PlayerBonusGameRoundMap
import com.nektan.revolve.coreservices.RGS
import com.nektan.revolve.coreservices.Site
import com.nektan.revolve.coreservices.Bonus
import com.nektan.revolve.api.BonusType
import com.nektan.revolve.api.ReturnCodes
import com.nektan.revolve.services.EventLogService
import grails.plugin.springsecurity.annotation.Secured
import org.apache.commons.lang.StringUtils

@Secured(['ROLE_PERMISSION_PLAYER_BONUS_VIEW'])
class PlayerBonusController {

	def scaffold = PlayerBonus

	def playerService
	def playerBonusService
	def netEntFreeSpinsService
	def gameRoundService
	def operatorService
	def bonusService
	def springSecurityService
	EventLogService eventLogService
	String ILLEGAL_ACCESS = "Illegal access. Unauthorized attempt to view or edit player Bonus"



	def beforeInterceptor = [action: this.&checkAuthorised, only: ['creditBonus','search']]

	private checkAuthorised() {

		Operator currentLoggedInUser = springSecurityService.getCurrentUser();

		Player player

		if (params.id) {
			player = playerService.findById(params.id)
		}
		List sites = operatorService.operatingSites(currentLoggedInUser)

		boolean found

		if (player != null) {
			found = sites.find { Site site -> site.id == player.site.id }
			if (!found) {
				flash.message = ILLEGAL_ACCESS + params.id
				redirect(controller:'player',action: 'search')
				return false
			}

		}

	}


	def closeGameRounds () {
		PlayerBonus playerBonus = PlayerBonus.findById(params.id)
		if(playerBonus == null) {
			renderError(ReturnCodes.Code.ERROR, "PLAYER BONUS NOT FOUND")
			return
		}

		List<PlayerBonusGameRoundMap> bonusGameRoundMapList = PlayerBonusGameRoundMap.findAllByPlayerBonusAndStatus(playerBonus, "OPEN")
		if(bonusGameRoundMapList.size() > 0) {
			for (PlayerBonusGameRoundMap playerBonusGameRoundMap : bonusGameRoundMapList) {
				gameRoundService.closeGameRound(playerBonusGameRoundMap.gameRound, 1)
				log.info("Closing game round ${playerBonusGameRoundMap.gameRound}")
				playerBonusService.detachGameRound(playerBonus, playerBonusGameRoundMap.gameRound)
				log.info("Detaching game round ${playerBonusGameRoundMap.gameRound} and player bonus ${playerBonus}")
			}
		}else{
			if(playerBonus.inGame) {
				//ideally this should not occur, this is a special case where a player bonus is stuck and there is no game round attached to it.
				playerBonusService.detachGameRound(playerBonus, null)
			}
		}
		log.info("Closed games rounds if any")
		redirect(action: "search", params: [id: playerBonus?.player?.id], playerInstance: playerBonus?.player)
	}

	/**
	 * Show bonus view
	 * @return
	 */
	def index() {
		Player playerInstance = playerService.findById(params.id)
		if (params.max == null) {
			params.max = 10
		}
		redirect(action: "search", params: params, playerInstance: playerInstance)
	}

	def details() {
		PlayerBonus playerBonus = PlayerBonus.get(params.id)
		List<Game> gamesList = FreeRoundsGameConfig.findAllByBonus(playerBonus.bonus)
		render(view: "_details", model: [playerBonusInstance: playerBonus, gamesList: gamesList])
	}

	/**
	 *
	 * @return
	 */
	@Secured('ROLE_PERMISSION_PLAYER_BONUS_STATE_CHANGE')
	def cancel() {
		try {
			PlayerBonus playerBonus = PlayerBonus.get(params.long('id'))
			playerBonusService.cancelBonus(playerBonus, springSecurityService.getCurrentUser())
			redirect(action: "search", params: [id: playerBonus.player.id], playerInstance: playerBonus.player)
		} catch (Exception e) {
			log.error("Caught Exception in PlayerBonusController.cancel()", e)
			renderError(ReturnCodes.Code.ERROR, e.toString())
			return
		}
	}
	
	
	def search() {
		try {
			Player player = playerService.findById(params.id)
			def results = playerBonusService.find(player, params)
			boolean isPlayerDepToBonRestricted = playerBonusService.isPlayerDepositToBonusRestriction(player)
			render(view: "tab_bonus", model: [params: params, playerBonusInstanceCount: results?.getTotalCount(), playerBonusInstanceList: results, playerInstance: player, isPlayerDepToBonRestricted: isPlayerDepToBonRestricted])
		} catch (Exception e) {
			log.error("Caught Exception in PlayerBonusController.search()", e)
			renderError(ReturnCodes.Code.ERROR, e.toString())
			return
		}
	}
	
	
	@Secured('ROLE_PERMISSION_PLAYER_BONUS_CREDIT')
	def creditBonus(params) {
		try {
			Player playerInstance = playerService.findById(params.playerId ? params.playerId : params.id)
			Bonus manualTemplate = bonusService.findActiveManualTemplateBySite(playerInstance.site);
			if(manualTemplate != null){
				manualTemplate.rewardType = BonusRewardType.BonusFunds.id
			}
			render(view: "tab_createPlayerBonus", model: [bonusInstance: manualTemplate != null ? manualTemplate : new Bonus(), playerInstance: playerInstance])
		} catch (Exception e) {
			log.error("Caught Exception in PlayerBonusController.creditBonus()", e)
			renderError(ReturnCodes.Code.ERROR, e.toString())
			return
		}
	}

	@Secured('ROLE_PERMISSION_PLAYER_BONUS_CREDIT')
	def save(params) {
		
		try {
			Bonus bonusInstance;
            boolean isFailedAtQuickFire = false
            boolean isFailedAtElite = false
			Player playerInstance = playerService.findById(params.playerId ? params.playerId : params.id)
			int rewardType = params.int('rewardType')
			List<RGS> rgsList = new ArrayList<RGS>()
			List<Game> gameList = new ArrayList<Game>()
			if(params.rgs) {
				List<Long> rgsIds = bonusService.fetchRgsIds(params)
				if(rgsIds!=null){
					Long subProviderId = null
					if(params.subRgsProvider && params.subRgsProvider != "null"){
						subProviderId = Long.valueOf(params.subRgsProvider)
					}
					rgsList = RGS.findAllByIdInList(rgsIds)
					if(rgsList!=null && rgsList.size() > 0){
						//gameList = Game.findAllByRgsInListAndAllowFreeRounds(rgsList,true)
						gameList = bonusService.getRgsGameList(rgsList, subProviderId)
					}
				}
			}
			if (params.bonusId) {
				if(rewardType == BonusRewardType.FreeRounds.id){
					params.put('site.id', params.siteId)

					bonusInstance = new Bonus(params)

					if(params.name == null || StringUtils.isEmpty(params.name.trim())){
						bonusInstance.errors.reject('bonusInstance.name', 'Player Description can not be blank.')
					}
					if(params.description == null || StringUtils.isEmpty(params.description.trim())){
						bonusInstance.errors.reject('bonusInstance.description', 'Internal Description can not be blank.')
					}

					if(bonusInstance.hasErrors()){
						bonusInstance.id = params.bonusId !=null ? Long.parseLong(params.bonusId):null
						render(view: "tab_createPlayerBonus", model:[params:params, bonusInstance: bonusInstance, playerInstance: playerInstance,rgsList: rgsList,gameList: gameList])
						return
					}

					// params.name = params.name +"-"+ new Date().getTime().toString()

					bonusInstance = bonusService.createTemplate(params,BonusType.Manual)

					log.info "Interm Bonus:"+bonusInstance
					if(bonusInstance.hasErrors()){
						bonusInstance.id = params.bonusId !=null ? Long.parseLong(params.bonusId):null
						render(view: "tab_createPlayerBonus", model:[params:params, bonusInstance: bonusInstance, playerInstance: playerInstance,rgsList: rgsList,gameList: gameList])
						return
					}
                    if(rgsList.contains(RGS.findByName(RGSName.QUICKFIRE.rgsName())) && bonusInstance.isFaliedAtQuickfire && bonusInstance.quickfireOfferId == null) {
                        isFailedAtQuickFire = true
                    }
                    if(rgsList.contains(RGS.findByName(RGSName.ELITE.rgsName())) && bonusInstance.isFailedAtElite && bonusInstance.eliteCampaignId == null) {
                        isFailedAtElite = true
                    }

				}else{
					bonusInstance = Bonus.read(params.bonusId)
				}

			} else {
				params.put('site.id', params.siteId)
				bonusInstance = new Bonus(params)
                if(params.int('rewardType') == 1) {
                    params.put("freeRoundsValidityDays",7);
                    params.put("bonusMoneyValidityDays",35);
                }
				if(params.name == null || StringUtils.isEmpty(params.name.trim())){
					bonusInstance.errors.reject('bonusInstance.name', 'Player Description can not be blank.')
				}
				if(params.description == null || StringUtils.isEmpty(params.description.trim())){
					bonusInstance.errors.reject('bonusInstance.description', 'Internal Description can not be blank.')
				}

				if(bonusInstance.hasErrors()){
					render(view: "tab_createPlayerBonus", model:[params:params, bonusInstance: bonusInstance, playerInstance: playerInstance,rgsList: rgsList,gameList: gameList])
					return
				}

				bonusInstance = bonusService.createTemplate(params,BonusType.Manual)

				log.info "Interm Bonus:"+bonusInstance
				if(bonusInstance.hasErrors()) {
					render(view: "tab_createPlayerBonus", model:[params:params, bonusInstance: bonusInstance, playerInstance: playerInstance,rgsList: rgsList,gameList: gameList])
					return
				}
                if(rgsList.contains(RGS.findByName(RGSName.QUICKFIRE.rgsName())) && bonusInstance.isFaliedAtQuickfire && bonusInstance.quickfireOfferId == null) {
                    isFailedAtQuickFire = true
                    }
                if(rgsList.contains(RGS.findByName(RGSName.ELITE.rgsName())) && bonusInstance.isFailedAtElite && bonusInstance.eliteCampaignId == null) {
                    isFailedAtElite = true
                }
                }

            if(isFailedAtQuickFire){
                log.info 'Manual Free Spin offer creation failed at quickfire verify all settings/configurations accordingly'
            }
            if(isFailedAtElite){
                log.info 'Manual Free Spin offer creation failed at elite verify all settings/configurations accordingly'
            }
			//check is player DepositToBonus% restricted or not
			if(playerBonusService.isPlayerDepositToBonusRestriction(playerInstance)){
				flash.message = "Player bonus creation failed due to player is restricted to DepositToBonus%"
				log.debug("DepositToBonus ManualBonus PlayerID: "+playerInstance.id+ " bonus creation failed due to player is restricted to DepositToBonus%")
				render(view: "tab_createPlayerBonus", model: [params : params, bonusInstance: bonusInstance, playerInstance: playerInstance,rgsList: rgsList,gameList: gameList])
				return
			}

			def result = playerBonusService.createManualBonus(playerInstance, bonusInstance, springSecurityService.getCurrentUser(), params)
			if(result.bonus && result.bonus.hasErrors()) {
				log.info 'Errors with bonus'
				render(view: "tab_createPlayerBonus", model: [params : params, bonusInstance: result.bonus, playerInstance: playerInstance,rgsList: rgsList,gameList: gameList])
				return
			}
			if (result.playerBonus && result.playerBonus.hasErrors()) {
				flash.message = "Player bonus creation failed."
			} else if(params.int('rewardType') == BonusRewardType.FreeRounds.id){
				if( result.returnCode == ReturnCodes.Code.OK){
					flash.message = "Awarding free rounds is successful."
				}else{
					flash.message = "Awarding free rounds failed."
				}
			}else{
				flash.message = "Player bonus creation successful."
			}
			println 'Result:'+ result
			//log.info 'Result:'+ result
			redirect(controller: "playerBonus", action: "search", params: [id: playerInstance?.id])
		} catch (Exception e) {
			log.error("Caught Exception in PlayerBonusController.save()", e)
			renderError(ReturnCodes.Code.ERROR, e.toString())
			return
		}
	}

	@Secured('ROLE_PERMISSION_PLAYER_BONUS_CREDIT')
	def getDynamicRewardTypeConfigurations() {

		BonusRewardType rewardType = BonusRewardType.getRewardType(params.int('id'))
		Player player = Player.get(params.int('playerId'))
		Bonus manualTemplate = bonusService.findActiveManualTemplateBySite(player.site);
		if(rewardType == null || rewardType == BonusRewardType.BonusFunds) {
			render(template: "formPlayerManualBonusConfiguration" , model: [bonusInstance: manualTemplate != null ? manualTemplate : new Bonus()])
		}
		else if(rewardType == null || rewardType == BonusRewardType.Cash) {
			render(template: "formPlayerManualCashConfiguration" , model: [bonusInstance: manualTemplate != null ? manualTemplate : new Bonus()])
		} else {
			List<RGS> rgsList = new ArrayList<RGS>()
			List<Game> gameList = new ArrayList<Game>()
			if(manualTemplate != null){
				List<FreeRoundsRgsConfig> freeRoundsRgsConfigList = FreeRoundsRgsConfig.findAllByBonus(manualTemplate)
				if(freeRoundsRgsConfigList.size() > 0) {
					List<Integer> rgsIdList = new ArrayList<Integer>()
					freeRoundsRgsConfigList.each { it ->
						rgsIdList.add(it.getRgs().getId())
					}
					rgsList = RGS.findAllByIdInList(rgsIdList);
					if(rgsList.size() > 0){
						gameList = Game.findAllByRgsInListAndAllowFreeRounds(rgsList,true)
					}
				}
			}else{
				manualTemplate = new Bonus()
				manualTemplate.bonusType = BonusType.Manual.id
			}
			render(template: "formPlayerManualFreeRoundsConfiguration" , model: [bonusInstance: manualTemplate,rgsList:rgsList,gameList: gameList])
		}
	}

	private def renderError(ReturnCodes.Code code, String reason) {
		//log.error("renderError(): API ERROR:" + code.toString() + ", reason:" + reason)
		render(status: code.httpCode(), contentType: 'application/json') {
			def result = [:]
			result.put('result', code.value())
			if (code != ReturnCodes.Code.OK) {
				result.put('error', code.description())
			}
			if (reason != null && reason != "null") {
				result.put('reason', reason)
			}
			return result
		}
	}


	private def renderError(ReturnCodes.Code code) {
		renderError(code, null)
	}

//	@Secured('ROLE_PERMISSION_PLAYER_BONUS_CREDIT')
//	def creditEmailValidationBonus(params) {
//		Player playerInstance = playerService.findById( params.playerId?params.playerId: params.id )
//		if(playerInstance.isEmailValidated) {
//			Bonus activeEmailValidationBonus = bonusService.findActiveBonusBySiteAndType(playerInstance.site,BonusType.EmailValidation)
//			
//			//if(activeEmailValidationBonus != null && PlayerBonus.findCountByPlayerAndBonus(player,bonus)>0) {
//			if(activeEmailValidationBonus != null) {
//				playerBonusService.createBonus(playerInstance, activeEmailValidationBonus, null)
//			}
//		}
//		
//		render(view: "tab_createPlayerBonus", model:[bonusInstance: manualTemplate, playerInstance:playerInstance])
//	}
//
	/*@Secured('ROLE_PERMISSION_PLAYER_BONUS_CREDIT')
		def creditDepositBonus(params) {
		Player playerInstance = playerService.findById( params.playerId?params.playerId: params.id )
			playerBonusService.triggerDepositEvent(playerInstance)
			println playerBonusService.getBonusStatusMap()
			redirect(controller: "player", action: "summary", params: [id: playerInstance?.id])
		}*/
	
	
	
}
