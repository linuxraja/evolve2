package com.nektan.revolve.backoffice

import com.nektan.revolve.coreservices.Operator
import grails.plugin.springsecurity.annotation.Secured

@Secured(['IS_AUTHENTICATED_REMEMBERED'])
class PortalController {

    def springSecurityService

    def index() {
        Operator currentLoggedInUser = springSecurityService.getCurrentUser();
        render(view: 'portalhome', model:[params: params, me:currentLoggedInUser])
    }

    @Secured(['ROLE_ADMIN','ROLE_PERMISSION_CONFIG_EDIT','ROLE_PERMISSION_SYSTEM_EDIT'])
    def configure() {
        render(view: 'configure')
    }

	@Secured(['ROLE_ADMIN','ROLE_PERMISSION_SYSTEMHEALTH'])
	def systemhealth() {
		render(view: 'systemhealth')
	}


}
