package com.nektan.revolve.backoffice

import com.nektan.revolve.coreservices.GameCategory
import grails.plugin.springsecurity.annotation.Secured

@Secured(['ROLE_PERMISSION_SYSTEM_EDIT'])
class GameCategoryController {

    def scaffold = GameCategory

}
