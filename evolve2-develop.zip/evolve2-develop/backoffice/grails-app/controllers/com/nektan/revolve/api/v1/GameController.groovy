package com.nektan.revolve.api.v1

import com.nektan.revolve.api.AccountTypes
import com.nektan.revolve.api.Format
import com.nektan.revolve.api.ReturnCodes
import com.nektan.revolve.coreservices.*
import com.nektan.revolve.services.*
import com.nektan.revolve.sightline.W2gRecordService
import grails.converters.JSON
import grails.plugin.springsecurity.annotation.Secured
import groovy.json.JsonBuilder

@Secured(['permitAll'])
class GameController extends ApiController{

    static namespace = 'v1'
    AccountService accountService
    TransactionService transactionService
    SessionService sessionService
    ParamService paramService
    EventLogService eventLogService
    W2gRecordService w2gRecordService

    static allowedMethods = [createGameTransaction: "POST", start: "POST", end: "POST"]

    /**
     * Create a new transaction of type game.
     * Expects:
     *   String     token
     *   BigDecimal credit
     *   BigDecimal debit
     *   String     externalGameId
     *   String     externalGameInstanceId
     *   String     externalTransactionId
     *   String     description // optional, but should be supplied.
     */
    def createGameTransaction() {
        def payload = request.JSON

        try {

            String ip = getIp(request)

            // check the IP is from the allowed whitelist
            Boolean allowed = paramService.isInCSVList("api.source.ips", ip)

            if (!allowed) {
                log.error("createGameTransaction attempted from invalid IP: " + ip)
                eventLogService.logEvent([className: this.getClass().getName(), methodName: "createGameTransaction", IP: ip, eventName:EventLog.EventName.apiAccessDenied, description: "Attempt to insert game data from illegal source - hack attempt", level: EventLog.LEVELS.alert, param1: payload?.token])
                renderError(ReturnCodes.Code.ACCESS_DENIED, "your IP: " + ip + " is not in the list of allowed IPs")
                return
            }

            // check mandetory params.
            // TODO: add externalTransactionId to mandetory params
            String[] params = ["token", "externalGameId", "externalGameInstanceId"]

            String paramError = checkParams(payload, params)
            if (paramError != null) {
                renderError(ReturnCodes.Code.INVALID_PARAMS, paramError)
                return
            }

            String externalGameId = payload.externalGameId
            String externalGameInstanceId = payload.externalGameInstanceId
            String description = payload.description
            String token = payload.token
            BigDecimal credit = new BigDecimal(0)
            BigDecimal debit = new BigDecimal(0)
            String externalTransactionId = payload.externalTransactionId
            Integer numBets = null

            try {
                if (payload.credit != null) {
                    credit = new BigDecimal(payload.credit)
                }

                if (payload.debit != null) {
                    debit = new BigDecimal(payload.debit)
                }
            }  catch (NumberFormatException e) {
                log.error("createGameTransaction API Error: " + e.toString() + " payload: " + payload, e)
                renderError(ReturnCodes.Code.INVALID_PARAMS, "Number format exception in credit or debit")
                return
            }

            if (payload.numBets != null) {
                numBets = new Integer(payload.numBets)
            }

            if ((credit.compareTo(BigDecimal.ZERO) == 0) &&
                    (debit.compareTo(BigDecimal.ZERO) == 0)) {
                renderError(ReturnCodes.Code.TRANSACTION_IGNORED)
                return
            }   // if credit and debit are zero

            Session session = sessionService.getSession(token, getIp(request), this.getClass().getName(), "createGameTransaction" )
            if (session == null || !sessionService.isActiveSession(session)) {
                renderError(ReturnCodes.Code.SESSION_INVALID)
                return
            }

            Player player = session.player

            // stop closed accounts etc from being used
            if (!player.playerStatus.canPlay) {
                renderError(ReturnCodes.Code.PLAYER_NOT_PERMITTED)
                return
            }

            Game game = Game.findByExternalId(externalGameId)
            if (game == null) {
                renderError(ReturnCodes.Code.TRANSACTION_GAME_NOT_FOUND, "Could not find game for externalGameId " + externalGameId)
                return
            }

            BigDecimal playableBal = w2gRecordService.getPlayableBalanceForUS(session.player)
            if (debit > 0 && debit > playableBal) {
                renderError(ReturnCodes.Code.TRANSACTION_INSUFFICIENT_FUNDS, "playable balance of " + playableBal + " is not enough for wager of " + debit)
                return
            }

            def result = transactionService.createGameTransaction(session, game, externalGameInstanceId, debit, credit, description, externalTransactionId, null, null, false, numBets)

            if (result == null) {
                renderError(ReturnCodes.Code.ERROR, "Uncaught Error in CreateGameTransaction")
                return
            } else if (result.returnCode == ReturnCodes.Code.OK) {

                /*            // If the transaction was created ok, now go and create or update the game round.
                  GameRoundService.createOrUpdate(session, game, externalGameInstanceId, debit, credit)
                */

                // for US only: check W2G requirements & lock account if necessary
                if (credit  > 0 ) {
                    // This will be done in its own transaction
                    boolean W2GTriggered = w2gRecordService.checkW2gForGame(player, externalGameInstanceId, credit, game);
                }

                player.accounts.each { Account a ->
                    a.refresh()
                }
                BigDecimal balance = w2gRecordService.getPlayableBalanceForUS(session.player)

                Map map = ["result": ReturnCodes.Code.OK.value(), transactionId: result.transaction.id, accounts: player.accounts, description: "Transaction created", "playableBalance": balance]
                String json = new JSON(map).toString(true)

                render(status: 200, contentType: 'application/json', text: json)
                return
            } else {
                renderError(result.returnCode, result.errors)
                return
            }

        } catch (Exception e) {
            renderError(ReturnCodes.Code.ERROR, e.toString())
            log.error("createGameTransaction API Error:" +  e.toString(), e)
        }
    } // createGameTransaction()

    /***
     * NOT CURRENTLY USED - for future use.
     * mandetory params:
     *     token, externalGameId, externalGameInstanceId
     * optional param:
     *     description, numTickets, totalSake
     * @return
     */
    def startGame() {
        def payload = request.JSON

        // check mandetory params.
        String[] params = ["token", "externalGameId", "externalGameInstanceId"]

        String paramError = checkParams(payload, params)
        if (paramError != null) {
            renderError(ReturnCodes.Code.INVALID_PARAMS, paramError)
            return
        }

        // mandetory
        String externalGameId = payload.externalGameId
        String externalGameInstanceId = payload.externalGameInstanceId
        String token = payload.token

        // optional
        String description = payload.description
        String numTickets = payload.numTickets
        String totalStake = payload.totalStake

        // check for existing game round - should use RGS too!
        GameRound found = GameRound.findByExternalRoundId(externalGameInstanceId)

        if (found != null) {
            renderError(ReturnCodes.Code.GAME_ROUND_EXISTS)
            return
        }

        // create new game round.
   //     GameRound = new GameRound()



    } // startGame()

    /**
     * end a game.
     * This doesnt care if the session has expired.
     * It does allow W2G records to be completed.
     * Doesnt do anything else.
     *
     * @return
     */
    def endGame() {

        try {
            def payload = request.JSON

            String[] params = ["token", "externalGameInstanceId"]

            String paramError = checkParams(payload, params)
            if (paramError != null) {
                renderError(ReturnCodes.Code.INVALID_PARAMS, paramError)
                return
            }

            // mandetory
            String externalGameInstanceId = payload.externalGameInstanceId
            String token = payload.token

            Session session = sessionService.getSession(token)

            if (session == null) {
                renderError(ReturnCodes.Code.SESSION_INVALID)
                return
            }



            // this just marks the w2g record, if it exists, as game ended (so can be completed)
            w2gRecordService.endGame(session.player, externalGameInstanceId)


            BigDecimal balance = w2gRecordService.getPlayableBalanceForUS(session.player)
            int w2gCount = w2gRecordService.getOpenRecordCount(session.player)

//            Map map = ["result": ReturnCodes.Code.OK.value(), accounts: session.player.accounts]
            Map map = ["result": ReturnCodes.Code.OK.value(), "playableBalance": balance, w2gCount: w2gCount]
            String json = new JSON(map).toString(true)
            render(status: 200, contentType: 'application/json', text: json)

        } catch (Exception e) {
            renderError(ReturnCodes.Code.ERROR, e.toString())
            log.error("endGame API Error:" + e.toString(), e)
        }

    }  // endGame()

    // This is to return just the gamesRecords, for future Implemenation
    def listGames() {

    }

}



