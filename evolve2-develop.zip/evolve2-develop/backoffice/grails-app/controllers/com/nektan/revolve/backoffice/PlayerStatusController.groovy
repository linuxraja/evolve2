package com.nektan.revolve.backoffice

import static org.springframework.http.HttpStatus.*
import grails.transaction.Transactional
import org.springframework.security.access.annotation.Secured
import com.nektan.revolve.coreservices.PlayerStatus

@Transactional(readOnly = true)
@Secured('ROLE_PERMISSION_PLAYER_STATUS_VIEW')
class PlayerStatusController {

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]
	
   
    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond PlayerStatus.list(params), model:[playerStatusInstanceCount: PlayerStatus.count()]
    }

    def show(PlayerStatus playerStatusInstance) {
        respond playerStatusInstance
    }

	@Secured('ROLE_PERMISSION_PLAYER_STATUS_CREATE')
    def create() {
        respond new PlayerStatus(params)
    }

    @Transactional
	@Secured(['ROLE_PERMISSION_PLAYER_STATUS_CREATE','ROLE_PERMISSION_PLAYER_STATUS_EDIT'])
    def save(PlayerStatus playerStatusInstance) {
        if (playerStatusInstance == null) {
            notFound()
            return
        }

        if (playerStatusInstance.hasErrors()) {
            respond playerStatusInstance.errors, view:'create'
            return
        }

        playerStatusInstance.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.created.message', args: [message(code: 'playerStatus.label', default: 'PlayerStatus'), playerStatusInstance.id])
                redirect playerStatusInstance
            }
            '*' { respond playerStatusInstance, [status: CREATED] }
        }
    }
	
	
	
	@Secured('ROLE_PERMISSION_PLAYER_STATUS_EDIT')
    def edit(PlayerStatus playerStatusInstance) {
        respond playerStatusInstance
    }

    @Transactional
    def update(PlayerStatus playerStatusInstance) {
        if (playerStatusInstance == null) {
            notFound()
            return
        }

        if (playerStatusInstance.hasErrors()) {
            respond playerStatusInstance.errors, view:'edit'
            return
        }

        playerStatusInstance.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'PlayerStatus.label', default: 'PlayerStatus'), playerStatusInstance.id])
                redirect playerStatusInstance
            }
            '*'{ respond playerStatusInstance, [status: OK] }
        }
    }

    @Transactional
    def delete(PlayerStatus playerStatusInstance) {

        if (playerStatusInstance == null) {
            notFound()
            return
        }

        playerStatusInstance.delete flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'PlayerStatus.label', default: 'PlayerStatus'), playerStatusInstance.id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }
    }

    protected void notFound() {
        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'playerStatus.label', default: 'PlayerStatus'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }
}
