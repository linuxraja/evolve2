package com.nektan.revolve.backoffice

import com.nektan.revolve.coreservices.SecurityQuestion
import grails.plugin.springsecurity.annotation.Secured

@Secured(['ROLE_PERMISSION_CONFIG_EDIT','ROLE_PERMISSION_SYSTEM_EDIT'])
class SecurityQuestionController {

    def scaffold = SecurityQuestion

    def show() {
        redirect(action: "index")
    }

}
