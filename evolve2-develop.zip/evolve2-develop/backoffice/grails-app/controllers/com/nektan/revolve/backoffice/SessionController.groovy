package com.nektan.revolve.backoffice

import com.nektan.revolve.coreservices.Operator
import com.nektan.revolve.coreservices.Session
import grails.plugin.springsecurity.annotation.Secured

@Secured(['IS_AUTHENTICATED_FULLY'])
class SessionController {

    def scaffold = Session
    def sessionService
    def springSecurityService

	def details() {
		Session session = Session.get(params.id)
		render(view:"_sessionDetails", model:[sessionInstance: session])
	}


    def close() {
        Operator currentLoggedInUser = springSecurityService.getCurrentUser();
        Session result = sessionService.closeSession( params.long('id'), Session.BOOTED, "Closed by operator: " + currentLoggedInUser )

// SWH: working on this.
//        sessionService.setChanged()
//        sessionService.notifyObservers(result)

	    render(view: "_sessionClosed", model:[sessionInstance: result])
    }

}
