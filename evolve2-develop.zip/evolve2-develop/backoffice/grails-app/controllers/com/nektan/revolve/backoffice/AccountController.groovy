package com.nektan.revolve.backoffice

import com.nektan.revolve.coreservices.Account
import grails.plugin.springsecurity.annotation.Secured

@Secured(['IS_AUTHENTICATED_FULLY'])
class AccountController {

    def scaffold = Account


    def edit() {
        redirect(action: 'index')
    }


    def create() {
        redirect(action: 'index')
    }

}
