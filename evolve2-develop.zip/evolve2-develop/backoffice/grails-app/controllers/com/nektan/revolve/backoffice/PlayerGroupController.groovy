package com.nektan.revolve.backoffice

import com.nektan.revolve.api.PlayerGroupStatus
import com.nektan.revolve.api.ReturnCodes
import com.nektan.revolve.coreservices.Player
import com.nektan.revolve.coreservices.PlayerGroup
import com.nektan.revolve.coreservices.PlayerGroupPlayer
import com.nektan.revolve.coreservices.PlayerGroupSite
import com.nektan.revolve.coreservices.Site
import grails.plugin.springsecurity.annotation.Secured

import java.text.SimpleDateFormat

import static org.springframework.http.HttpStatus.*
import grails.transaction.Transactional

@Secured('ROLE_PERMISSION_PLAYER_GROUP_VIEW')
class PlayerGroupController {

    def springSecurityService
    def operatorService
    def playerGroupService

    static SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm")

    static allowedMethods = [save: "POST", update: "POST", delete: "DELETE"]

    def index() {
//        params.max = Math.min(max ?: 10, 100)
  //      respond PlayerGroup.list(params), model: [playerGroupInstanceCount: PlayerGroup.count()]
           render(view:'search', model:[entityName:"PlayerGroup", params:params])
    }

    def show(PlayerGroup playerGroupInstance) {
        render(view: 'show', model: [playerGroupInstance: playerGroupInstance])
    }

    def showPlayers() {
        PlayerGroup playerGroupInstance = PlayerGroup.findById(params.long('id'))
        params.max = Math.min(params.int('max') ?: 50, 100)
        params.offset = params.offset != null ? params.int('offset') : 0
        params.sort = params.sort != null ? params.sort : 'id'
        params.order = params.order != null ? params.order : 'asc'
        List<Player> playerGroupPlayers = PlayerGroupPlayer.findAllByPlayerGroup(playerGroupInstance, [max: params.max, offset: params.offset, sort: 'player.' + params.sort, order: params.order])?.collect {
            it.player
        }
        long totalPlayersCount = PlayerGroupPlayer.countByPlayerGroup(playerGroupInstance)
        render(template: 'list', model: [playerGroupInstance: playerGroupInstance, players: playerGroupPlayers, playersCount: totalPlayersCount, params: params])
    }

	@Secured('ROLE_PERMISSION_PLAYER_GROUP_CREATE')
    def create() {
        respond new PlayerGroup(params)
    }

	@Secured('ROLE_PERMISSION_PLAYER_GROUP_CREATE')
    def save() {

        try {
            PlayerGroup playerGroupInstance = new PlayerGroup()
            playerGroupInstance.name = params.name
            playerGroupInstance.description = params.description

            Set playerIds = [:] as HashSet
            if (null == params.sites || params.sites?.size() == 0) {
                flash.message = "Account Systems cannot be empty"
                render(view: "create", model: [params: params, playerGroupInstance: playerGroupInstance])
                return
            }
            // No action required, as we allow player group creation without uploading players.
            /*if (params.file == null) {
                flash.message = "File cannot be empty"
                render(view: "create", model: [params: params, playerGroupInstance: playerGroupInstance])
                return
            }*/
            def csvFile = request.getFile('file')
            if (csvFile.empty) {
                // No action required, as we allow player group creation without uploading players.
                // flash.message = "File cannot be empty"
                // render(view: "create", model: [params: params, playerGroupInstance: playerGroupInstance])
                // return
            } else {
                long startTime = System.currentTimeMillis()
                csvFile.inputStream?.toCsvReader()?.eachLine { line ->
                    line?.each { value ->
                        try {
                            playerIds.add(Long.parseLong(value))
                        } catch (NumberFormatException e) {
                            log.error 'Invalid player id processing file with name : ' + csvFile.name + '; player id : ' + value
                        }
                    }
                }
                log.info("Time Taken for reading from csv file in playergroups.." + (System.currentTimeMillis() - startTime) + " Milliseconds")

                if (playerIds.size() == 0) {
                    flash.message = "No valid player ids to create player group."
                    render(view: "create", model: [params: params, playerGroupInstance: new PlayerGroup(params)])
                    return
                }
            }

            def result = playerGroupService.save(params, playerIds, playerGroupInstance)
            if(null != result.errors && null != result.errorType){
                switch (result.errorType){
                    case  "OTHER-PLAYERS" :  flash.message = result.errors
                                             render(view: "create", model: [params: result.params, playerGroupInstance: result.playerGroupInstance])
                                             return
                    case     "VALIDATION" :  render(view: "create", model: [params: result.params, playerGroupInstance: result.playerGroupInstance])
                                             return
                }
            }

            redirect(action: "show", id: result?.playerGroupInstance?.id)
            return
        } catch (Exception e) {
            log.error("Caught Exception in PlayerGroupController.save()", e)
            flash.message = "Exception when creating player group"
            render(view: "create", model: [params: params, playerGroupInstance: new PlayerGroup(params)])
            return
        }
    }

	@Secured('ROLE_PERMISSION_PLAYER_GROUP_CREATE')
    def edit(PlayerGroup playerGroupInstance) {
        params.max = Math.min(params.int('max') ?: 50, 100)
        int offset = params.offset != null ? params.int('offset') : 0
        List<Player> playerGroupPlayers = PlayerGroupPlayer.findAllByPlayerGroup(playerGroupInstance, [max: params.max, offset: offset])?.collect {
            it.player
        }
        render(view: 'edit', model: [playerGroupInstance: playerGroupInstance, players: playerGroupPlayers])
    }

    @Transactional
	@Secured('ROLE_PERMISSION_PLAYER_GROUP_CREATE')
    def update() {
        try {
            Set<Player> players = new HashSet<Player>()
            Set playerIds = [:] as HashSet
            PlayerGroup playerGroupInstance = PlayerGroup.findById(params.long('id'))
            if (playerGroupInstance == null) {
                flash.message = "Invalid player group"
                render(view: "edit", model: [params: params, playerGroupInstance: playerGroupInstance])
                return
            }

            // No action required, as we allow player group creation without uploading players.
            /*if (params.file == null) {
                flash.message = "File cannot be empty"
                redirect(action: "edit", id: playerGroupInstance.id)
                return
            }*/
            def csvFile = request.getFile('file')
            if (csvFile.empty) {
                // No action required, as we allow player group creation without uploading players.
                // flash.message = "File cannot be empty"
                // redirect(action: "edit", id: playerGroupInstance.id)
                // return
            } else {
                csvFile.inputStream?.toCsvReader()?.eachLine { line ->
                    line?.each { value ->
                        try {
                            playerIds.add(Long.parseLong(value))
                        } catch (NumberFormatException e) {
                            log.error 'Invalid player id processing file with name : ' + csvFile.name + '; player id : ' + value
                        }
                    }
                }
                if (playerIds.size() == 0) {
                    flash.message = "No valid player ids to create player group."
                    redirect(action: "edit", id: playerGroupInstance.id)
                    return
                }
            }
            if(playerIds.size() > 0){
                def result = playerGroupService.update(params, playerIds, playerGroupInstance)
                if(null != result.errors && null != result.errorType){
                    switch (result.errorType){
                        case  "OTHER-PLAYERS" :  flash.message = result.errors
                            redirect(action: "edit", id: result.playerGroupInstance?.id)
                            return
                        case     "DUPLICATES" :  redirect(action: "show", id: result.playerGroupInstance?.id)
                            return
                        case     "VALIDATION" :  redirect(action: "edit", id: playerGroupInstance.id)
                            return
                    }
                }
                redirect(action: "show", id: result.playerGroupInstance?.id)
                return
            } else {
                redirect(action: "show", id: playerGroupInstance?.id)
                return
            }

        } catch (Exception e) {
            log.error("Caught Exception in PlayerGroupController.edit()", e)
            flash.message = "Exception when editing player group"
            redirect(action: "edit", id: params.id)
            return
        }
    }

    @Transactional
	@Secured('ROLE_PERMISSION_PLAYER_GROUP_CREATE')
    def delete(PlayerGroup playerGroupInstance) {

        if (playerGroupInstance == null) {
            notFound()
            return
        }

        if(playerGroupInstance.isLinkedToBonus) {
            //flash.message = "Can not delete player group linked to active/pending/suspended bonus."
            //redirect action: "search", method: "GET"
			flash.message = "Can not delete player group linked to active/pending/suspended bonus."
			redirect(action: "search", method: "GET", model: [params: params])
            //'*' { render status: NOT_ACCEPTABLE }
            return
        }
        playerGroupInstance.status = PlayerGroupStatus.Cancelled.id
        playerGroupInstance.save(flush: true)

        request.withFormat {
            form multipartForm {
                //flash.message = message(code: 'default.deleted.message', args: [message(code: 'PlayerGroup.label', default: 'PlayerGroup'), playerGroupInstance.id])
                redirect(action: "search", method: "GET", model: [params: params])
				return
            }
           // '*' { render status: NO_CONTENT }
			
        }
    }

    /**
     * Initate the editing of given rewards
     * @return
     */
    @Secured('ROLE_PERMISSION_PLAYER_GROUP_CREATE')
    def copy() {
        try {

            PlayerGroup playerGroupInstance = PlayerGroup.findById(Long.parseLong(params.id))

            PlayerGroup copiedPlayerGroup = new PlayerGroup()
            copiedPlayerGroup.properties = playerGroupInstance.properties
            if (copiedPlayerGroup?.id) {
                copiedPlayerGroup.id = null
            }
            render(view: 'create', model: [playerGroupInstance: copiedPlayerGroup])
        } catch (NumberFormatException e) {
            log.error("Caught Exception in PlayerGroupController.copy()", e)
            renderError(ReturnCodes.Code.ERROR, e.toString())
            return
        }
    }

    protected void notFound() {
        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'playerGroup.label', default: 'PlayerGroup'), params.id])
                redirect action: "index", method: "GET"
            }
            '*' { render status: NOT_FOUND }
        }
    }

    private def renderError(ReturnCodes.Code code, String reason) {
        //log.error("renderError(): API ERROR:" + code.toString() + ", reason:" + reason)
        render(status: code.httpCode(), contentType: 'application/json') {
            def result = [:]
            result.put('result', code.value())
            if (code != ReturnCodes.Code.OK) {
                result.put('error', code.description())
            }
            if (reason != null && reason != "null") {
                result.put('reason', reason)
            }
            return result
        }
    }


    private def renderError(ReturnCodes.Code code) {
        renderError(code, null)
    }
	
	/**
	 * Executes a search
	 * @return
	 */
	def search() {
		try {

				if(!params.max) {
					params.max = 50
				}
				//def results = bonusService.find(params)
				
				List sitesList
                List sitesLst
				List statuses
				Date dateCreated
				
				if ( params.site) {
					if(!params.site.class.isArray()){
						sitesList = params.site.replaceAll("\\[","").replaceAll("]","").split(",")
					}else {
						sitesList = params.list('site')
					}
                    sitesLst = Site.findAllByIdInList(sitesList)
				}else {
                    sitesList = operatorService.operatingSites()*.id
                    sitesLst = operatorService.operatingSites()
                }
		
				if (params.status) {
		
					if(!params.status.class.isArray()){
						statuses = params.status.replaceAll("\\[","").replaceAll("]","").split(",")
					}else {
						statuses = params.list('status')
					}
				}
		
				if (params.createdFrom) {
					dateCreated = formatter.parse(params.createdFrom)
				}
		        List<PlayerGroupSite> playerGroupLst = PlayerGroupSite.findAllBySiteInList(sitesLst)
				def c = PlayerGroup.createCriteria()
            def results = c.list(max:params?.max, offset: params?.offset, sort:  params?.sort == null?'id':params?.sort, order: params?.order == null ? 'desc' : params?.order) {
					if ( params.id?.length() > 0) sqlRestriction "cast( id AS char ) like '%${params.id}%'"
					if ( params.'name'?.length() > 0) like("name","%${params.'name'}%")
					if ( params.'description'?.length() > 0) like("description","%${params.'description'}%")
					if ( statuses ) {
						 'in'("status", statuses.collect {Integer.parseInt(it.trim()) })
					}
                    if ( playerGroupLst ) {
                        'in'("id", playerGroupLst.collect{it.playerGroup.id})
                    }
				/*	if ( sitesList ) {
                        sites{
                            'in'("id", sitesList.collect { Long.parseLong(it.toString().trim()) })
                        }
                    }*/
					if ( dateCreated ) ge("dateCreated", dateCreated )

				}
//            log.info(results)
				if (results == null ) {
					flash.message = message(code: "revolve.search.error.noplayergroupsfound", args: [params.bonusId])
					render(template: "searchList", model: [params: params])
				} else {
					render(template:"searchList", model:[ params:params, playerGroupsFound:results.getTotalCount(), playerGroupInstanceList:results, playerGroupCount:results.size() ])
				}
		}catch(Exception e) {
				log.error("Caught Exception in PlayerGroupController.search()", e)
				renderError(ReturnCodes.Code.ERROR, e.toString())
				return
		}
	}
}
