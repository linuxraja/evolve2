package com.nektan.revolve.backoffice

import com.nektan.revolve.coreservices.DocumentType
import grails.plugin.springsecurity.annotation.Secured

@Secured(['ROLE_PERMISSION_CONFIG_EDIT','ROLE_PERMISSION_SYSTEM_EDIT'])
class DocumentTypeController {
	def scaffold = DocumentType

	def show() {
		redirect(action: "index")
	}

}
