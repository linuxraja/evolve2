package com.nektan.revolve.backoffice

import com.nektan.revolve.extras.Utils

import javax.servlet.http.HttpServletRequest

class BackofficeController {

    private static String getIp (HttpServletRequest request) {
        String ip = Utils.getIP(request)
        return ip
    } // getIp

}
