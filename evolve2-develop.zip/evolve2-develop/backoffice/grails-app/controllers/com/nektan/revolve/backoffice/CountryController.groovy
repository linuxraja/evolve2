package com.nektan.revolve.backoffice

import com.nektan.revolve.coreservices.Country
import com.nektan.revolve.coreservices.Currency
import com.nektan.revolve.services.CountryService
import grails.plugin.springsecurity.annotation.Secured
import grails.transaction.Transactional

@Secured(['ROLE_PERMISSION_SYSTEM_EDIT'])
class CountryController {

    def scaffold = Country

    CountryService countryService

    def index(){
        List countryInstanceList = countryService.listAll(params)
        render(view: 'index', model:[countryInstanceList : countryInstanceList, params : params])
    }
    /**
     * defined update() method to handle currency values properly
     * @param countryInstance
     * @return
     */
    def update(Country countryInstance){
        if(countryInstance?.getCurrency()?.size() >= 0){
            countryInstance.getCurrency().clear()
            countryInstance.properties['currency'] = params['currency']
        }
        if (!countryInstance.save(flush: true)) {
            render(view: "edit", model: [countryInstance: countryInstance])
            return
        }
        redirect(action: "show", id: countryInstance.id)
    }
}
