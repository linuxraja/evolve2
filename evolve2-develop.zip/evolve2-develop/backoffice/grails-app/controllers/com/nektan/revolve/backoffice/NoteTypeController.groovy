package com.nektan.revolve.backoffice

import com.nektan.revolve.coreservices.NoteType
import grails.plugin.springsecurity.annotation.Secured

@Secured(['ROLE_PERMISSION_CONFIG_EDIT','ROLE_PERMISSION_SYSTEM_EDIT'])
class NoteTypeController {

    def scaffold = NoteType


    def show() {
        redirect(action: "index")
    }
}
