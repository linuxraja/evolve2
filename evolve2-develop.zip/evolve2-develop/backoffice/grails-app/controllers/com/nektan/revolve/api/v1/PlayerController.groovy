package com.nektan.revolve.api.v1

import com.maxmind.geoip2.WebServiceClient
import com.maxmind.geoip2.exception.AddressNotFoundException
import com.maxmind.geoip2.exception.AuthenticationException
import com.maxmind.geoip2.exception.GeoIp2Exception
import com.maxmind.geoip2.exception.HttpException
import com.maxmind.geoip2.exception.InvalidRequestException
import com.maxmind.geoip2.exception.OutOfQueriesException
import com.maxmind.geoip2.model.CountryResponse
import com.nektan.revolve.api.APIReturnCode
import com.nektan.revolve.api.AccountTypes
import com.nektan.revolve.api.ReturnCodes
import com.nektan.revolve.coreservices.Account
import com.nektan.revolve.coreservices.Country
import com.nektan.revolve.coreservices.Currency
import com.nektan.revolve.coreservices.EventLog
import com.nektan.revolve.coreservices.Player
import com.nektan.revolve.coreservices.QuickAmount
import com.nektan.revolve.coreservices.SecurityQuestion
import com.nektan.revolve.coreservices.Session
import com.nektan.revolve.coreservices.Site
import com.nektan.revolve.coreservices.SiteGameConfig
import com.nektan.revolve.extras.Utils
import com.nektan.revolve.services.EventLogService
import com.nektan.revolve.services.ParamService
import com.nektan.revolve.services.PlayerService
import com.nektan.revolve.services.SessionService
import com.nektan.revolve.services.SiteService
import grails.plugin.springsecurity.annotation.Secured
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper
import org.codehaus.groovy.grails.web.json.JSONObject
import org.hibernate.collection.internal.PersistentSet
import org.springframework.util.StringUtils
import org.apache.http.client.HttpClient
import org.apache.http.client.methods.HttpGet
import org.apache.http.impl.client.DefaultHttpClient
import org.apache.http.HttpResponse

@Secured(['permitAll'])
class PlayerController extends ApiController {

    static namespace = 'v1'
    static allowedMethods = [getDetails: "POST", createPlayer: "POST", changePassword: "POST", resendUsername: "POST", resetPassword: "POST"]

    SessionService sessionService
    PlayerService playerService
    EventLogService eventLogService
    SiteService siteService
    ParamService paramService

    /**
     * { email:"resend@me.com" }
     * @return
     * returns status 0 = (success) even if the email did not exist.
     */
    def resendUsername() {
        try {
            def payload = request.JSON

            // Check params are all there.
            String[] requiredParams = ["email"]
            String paramError = checkParams(payload, requiredParams)
            if (paramError != null) {
                renderError(ReturnCodes.Code.INVALID_PARAMS, paramError)
                return
            }

            String email = payload.email

            Player player = Player.findByEmail(email)

            // if we found one
            if (player) {
                if (player.playerStatus.canResendPassword) {
                    playerService.resendUsername( player )
                    eventLogService.logEvent([className: this.getClass().getName(), methodName: "resendUsername", player: player, IP: getIp(request), eventName:EventLog.EventName.resendUsername,description: "Request resend of username", level: EventLog.LEVELS.info])
                } else {
                    eventLogService.logEvent([className: this.getClass().getName(),  player: player, methodName: "resendUsername", IP: getIp(request), eventName:EventLog.EventName.resendUsernameError,description: "Request resend of username not allowed, status:" + player.playerStatus.toString(), level: EventLog.LEVELS.alert, param1:player.playerStatus.toString()])
                    renderError(ReturnCodes.Code.PLAYER_NOT_PERMITTED, "Status does not allow this")
                    return
                }
            } else {
                eventLogService.logEvent([className: this.getClass().getName(), methodName: "resendUsername", param1: email, IP: getIp(request), eventName:EventLog.EventName.resendUsernameError,description: "Request resend of username with bad email: " + email, level:  EventLog.LEVELS.alert])
            }  // player not found

            // return ok even if player was not found!
            render(status: 200, contentType: 'application/json') {
                ['result': ReturnCodes.Code.OK.value()]
            }

        } catch (Exception e) {
            log.error("Caught Exception in PlayerController.getDetails()", e)
            renderError(ReturnCodes.Code.ERROR, e.toString())
        }
    } // resendUsername


    /***
     * { username:"bigboy", security_answer:"yak", new_password:"asdf" }
     * @return
     */
    def resetPasswordNow() {
        try {
            def payload = request.JSON

            // Check params are all there.
            String[] requiredParams = ["username", "security_answer", "new_password"]
            String paramError = checkParams(payload, requiredParams)
            if (paramError != null) {
                renderError(ReturnCodes.Code.INVALID_PARAMS, paramError)
                return
            }

            String securityAnswer = payload.security_answer.trim()
            String username = payload.username
            String newPass = payload.new_password

            Player player = Player.findByUserName(username)

            if (!player) {
                eventLogService.logEvent([className: this.getClass().getName(), methodName: "resetPasswordNow", param1: username, param2: securityAnswer, IP: getIp(request), eventName:EventLog.EventName.resetPasswordError,description: "Request reset of password with bad username: " + username, level:  EventLog.LEVELS.alert])
                // return ok even if player was not found!
                renderError(ReturnCodes.Code.PLAYER_NOT_FOUND)
                return
            }

            // if username and security answer were corect, but status doesnt allow:
            if (!player.playerStatus.canResendPassword) {
                eventLogService.logEvent([className: this.getClass().getName(), methodName: "resetPasswordNow", player: player, IP: getIp(request), eventName:EventLog.EventName.resetPasswordError,description: "Request reset of password not allowed, status:" + player.playerStatus.toString(), level: EventLog.LEVELS.alert, param1:player.playerStatus.toString()])
                renderError(ReturnCodes.Code.PLAYER_NOT_PERMITTED, "Status does not allow this")
                return
            }

            eventLogService.logEvent([className: this.getClass().getName(), methodName: "resetPasswordNow", player: player, IP: getIp(request), eventName:EventLog.EventName.resetPassword,description: "Request reset of password", level: EventLog.LEVELS.info])

            def result = playerService.changePasswordWithAnswer(player, securityAnswer, newPass)

            if (result.returnCode == ReturnCodes.Code.OK) {
                render(status: 200, contentType: 'application/json') {
                    ['result': ReturnCodes.Code.OK.value()]
                }
            }  else {
                if (result.errors != null) {
                    renderError(result.returnCode, result.errors.toString())
                }  else {
                    renderError(result.returnCode)
                }
            }

        } catch (Exception e) {
            log.error("Caught Exception in PlayerController.getDetails()", e)
            renderError(ReturnCodes.Code.ERROR, e.toString())
        }
    }  // resetPassword


    /***
     * { username:"bigboy", secuirty_answer:"yak" }
     * @return
     */
    def resetPassword() {
        try {
            def payload = request.JSON

            // Check params are all there.
            String[] requiredParams = ["username", "security_answer"]
            String paramError = checkParams(payload, requiredParams)
            if (paramError != null) {
                renderError(ReturnCodes.Code.INVALID_PARAMS, paramError)
                return
            }

            String securityAnswer = payload.security_answer.trim()
            String username = payload.username

            Player player = Player.findByUserName(username)

            if (!player) {
                eventLogService.logEvent(className: this.getClass().getName(), methodName: "resetPassword", param1: username, param2: securityAnswer, IP: getIp(request), eventName:EventLog.EventName.resetPasswordError,description: "Request reset of password with bad username: " + username, level:  EventLog.LEVELS.alert)
                // return ok even if player was not found!
                render(status: 200, contentType: 'application/json') {
                    ['result': ReturnCodes.Code.OK.value()]
                }
                return
            }

            // dont tell them if the answer was wrong...
            if (!playerService.checkSecurityAnswer(player, securityAnswer)) {
                eventLogService.logEvent(className: this.getClass().getName(), methodName: "resetPassword", player: player, IP: getIp(request), eventName:EventLog.EventName.resetPasswordError,description: "Request reset of password incorrect security answer:" + securityAnswer, level: EventLog.LEVELS.alert, param1:securityAnswer)
                render(status: 200, contentType: 'application/json') {
                    ['result': ReturnCodes.Code.OK.value()]
                }
                return
            }

            // if username and security answer were corect, but status doesnt allow:
            if (!player.playerStatus.canResendPassword) {
                eventLogService.logEvent(className: this.getClass().getName(), methodName: "resetPassword", player: player, IP: getIp(request), eventName:EventLog.EventName.resetPasswordError,description: "Request reset of password not allowed, status:" + player.playerStatus.toString(), level: EventLog.LEVELS.alert, param1:player.playerStatus.toString())
                renderError(ReturnCodes.Code.PLAYER_NOT_PERMITTED, "Status does not allow this")
                return
            }

            eventLogService.logEvent(className: this.getClass().getName(), methodName: "resetPassword", param1:securityAnswer, player: player, IP: getIp(request), eventName:EventLog.EventName.resetPassword,description: "Request reset of password", level: EventLog.LEVELS.info)

            playerService.resetPassword(player)

            render(status: 200, contentType: 'application/json') {
                ['result': ReturnCodes.Code.OK.value()]
            }

        } catch (Exception e) {
            log.error("Caught Exception in PlayerController.getDetails()", e)
            renderError(ReturnCodes.Code.ERROR, e.toString())
        }
    }  // resetPassword

	/**
	 * Get the players details
	 * @return
	 */
	def getDetails() {
		try {
			def payload = request.JSON

			if (payload.token == null ) {
				renderError(ReturnCodes.Code.INVALID_PARAMS, "Token not present")
				return
			}

			Session session = sessionService.getSession(payload.token)

			if (session == null) {
				renderError(ReturnCodes.Code.SESSION_INVALID)
				return
			}

			if (!sessionService.isActiveSession(session)) {
				renderError(ReturnCodes.Code.SESSION_EXPIRED)
				return
			}

			Player player = sessionService.getSession(payload.token).player

			if (player != null) {
				def builder = new JsonBuilder()
				def root = builder {
					result ReturnCodes.OK
                    id "${player.id}"
					if (player.userName) username "${player.userName}"
					if (player.firstName) firstName "${player.firstName}"
					if (player.lastName) lastName "${player.lastName}"
					if (player.email) email "${player.email}"
					if (player.mobileNumber) mobileNumber "${player.mobileNumber}"
					if (player.landlineNumber) landlineNumber "${player.landlineNumber}"
					if (player.address_1) address_1 "${player.address_1}"
					if (player.address_2) address_2 "${player.address_2}"
					if (player.houseNumber) houseNumber "${player.houseNumber}"
					if (player.postcode) postcode "${player.postcode}"
					if (player.city) city "${player.city}"
					if (player.state) state "${player.state}"
					if (player.county) county "${player.county}"
					if (player.country) country "${player.country}"
					if (player.dateOfBirth) dateOfBirth "${player.dateOfBirth}"
					if (player.createdAt) createdAt "${player.createdAt.format("yyyy-MM-dd'T'HH:mm:ss.SSSZ")}"
					if (player.vipLevel) vipLevel "${player.vipLevel}"
					if (player.gender) gender "${player.gender}"
                    if (player.salutation) salutation "${player.salutation}"
                    if (player.securityQuestion) securityQuestionId "${player.securityQuestion.id}"
                    isAutoCashout "${player.isAutoCashout}"

					if (player.accounts.collect().size() > 0) {
						accounts(
								player.accounts.collect { Account a ->
									[
											id      : "${a.id}",
											type    : "${AccountTypes.DESCRIPTIONS[a.type]}",
											balance : "${g.formatNumber(number:a.balance, formatName:"global.number.format", groupingUsed:"false")}",
											currency: "${a.currency}"
									]
								}
						)
					}
				}
				render(status: 200, text: builder.toPrettyString(), contentType: "application/json", encoding: "UTF-8")
				return
			} else {
				// THIS IS REALLY A SERIOUS INTERNAL ERROR
				log.error("playerController.getDetails found a session without a player" + payload.token)
				renderError(ReturnCodes.Code.PLAYER_NOT_FOUND)
				return
			} // player not foundd
		} catch (Exception e) {
			log.error("Caught Exception in PlayerController.getDetails()", e)
			renderError(ReturnCodes.Code.ERROR, e.toString())
		}
	} // getDetails()


	/**
	 * Create a player and a withdrawable account by default
	 * @return
	 */
	def createPlayer() {
		try {
			JSONObject payload = request.JSON
			String ip;

			// Check params are all there.
			String[] requiredParams = ["username", "password", "site", "gender", "firstname", "lastname", "email", "dateofbirth","address_1","postcode","country"]
			String paramError = checkParams(payload, requiredParams)
			if (paramError != null) {
				renderError(ReturnCodes.Code.INVALID_PARAMS, paramError)
				return
			}

			ip = getIp(request)

			def result = playerService.create(payload, ip)

			if (result.returnCode == ReturnCodes.Code.OK) {
                playerService.triggerRegistrationEvent(result.player, payload.bonusCode)
				render(status: 200, contentType: 'application/json') {
					['result': ReturnCodes.Code.OK.value(), 'description': 'Player created', "playerId":result.player.id]
				}
			} else {
				renderError(result.returnCode, result.errors.toString())
				return
			}

		} catch (Exception e) {
			log.error("Caught Exception in PlayerController.createPlayer()", e)
			renderError(ReturnCodes.Code.ERROR, e.toString())
		}
	}  // createPlayer()

	/**
     * method used to change player password.
	 * @param token
	 * @param password_old
	 * @param password_new
	 * @return
	 */
	def changePassword() {
		try {
			def payload = request.JSON

			String[] requiredParams = ["token", "password_old", "password_new"]
			String paramError = checkParams(payload, requiredParams)
			if (paramError != null) {
				renderError(ReturnCodes.Code.INVALID_PARAMS, paramError)
				return
			}

			Session session = sessionService.getSession(payload.token)

			if (session == null) {
				renderError(ReturnCodes.Code.SESSION_INVALID)
				return
			}

			if (!sessionService.isActiveSession(session)) {
				renderError(ReturnCodes.Code.SESSION_EXPIRED)
				return
			}


			if (payload.password_old == payload.password_new) {
				renderError(ReturnCodes.Code.INVALID_PARAMS, "New and old passwords must be different")
			}

			def result = playerService.changePassword(session.player, payload.password_old, payload.password_new)
				if (result.returnCode == APIReturnCode.OK) {
					render(status: 200, contentType: 'application/json') {
						['result': ReturnCodes.Code.OK.value(), 'description': "Password changed"]
					}
				} else {
                    if(result.returnCode == APIReturnCode.PLAYER_PASSWORD_MISMATCH) {
                        renderError(ReturnCodes.Code.PLAYER_PASSWORD_MISMATCH, result?.errors?.toString())
                    }else {
                        renderError(ReturnCodes.Code.ERROR, result.errors.toString())
                    }

					return
				}

		} catch (Exception e) {
			log.error("Caught Exception in PlayerController.changePassword()", e)
			renderError(ReturnCodes.Code.ERROR, e.toString())
		}
	} // changePassword()

    /****
     *      @param username = players username
     *      @return the qustion ID and the question.
     *      If the ID was invalid, it returns a random question, so that phishing is not possible.
     */

    def getSecurityQuestion() {
        try {
            def payload = request.JSON

            String[] requiredParams = ["username"]
            String paramError = checkParams(payload, requiredParams)
            if (paramError != null) {
                renderError(ReturnCodes.Code.INVALID_PARAMS, paramError)
                return
            }

            String username = payload.username

            Player player = playerService.findByUsername(username)

            SecurityQuestion securityQuestion

            if (player == null) {
                def questions = SecurityQuestion.findAll()
                def random = new Random()
                def randInt = random.nextInt(questions.size())
                securityQuestion = questions[randInt]
                log.warn("getSecurityQuestion API called with invalid username: " + username + " returning security question " + securityQuestion.id)
                eventLogService.logEvent(className: this.getClass().getName(), methodName: "getSecurityQuestion",IP: getIp(request), param1: username, eventName:EventLog.EventName.getSecurityQuestionError,description: "Request security question for invalid username: " + username, level: EventLog.LEVELS.alert)
            } else {
                securityQuestion = player.securityQuestion
            }

            if (securityQuestion == null) {
                log.error("getSecurityQuestion API called with player who has no question: " + username )
                eventLogService.logEvent([className: this.getClass().getName(), methodName: "getSecurityQuestion",IP: getIp(request), player: player, eventName:EventLog.EventName.getSecurityQuestionError,description: "Request security question - player had no question: " + username, level: EventLog.LEVELS.alert])
                renderError(ReturnCodes.Code.PLAYER_NO_QUESTION)
            } else {
                // dont log if there is no player - this is already handled.
                if (player != null) {
                    eventLogService.logEvent([className: this.getClass().getName(), methodName: "getSecurityQuestion",IP: getIp(request), player: player, eventName:EventLog.EventName.getSecurityQuestion,description: "Request security question username: " + username, level: EventLog.LEVELS.info])
                }
                render(status: 200, contentType: 'application/json') {
                    ['result': ReturnCodes.Code.OK.value(), securityQuestion: securityQuestion]
                }
            }
        } catch (Exception e) {
            log.error("Caught Exception in PlayerController.changePassword()", e)
            renderError(ReturnCodes.Code.ERROR, e.toString())
        }
    } // getSecurityQuestion()

    /**
     * method to update player's password.
     * @return
     */
	def updatePassword() {
		try {
			def payload = request.JSON

			String[] requiredParams = ["hp", "password_new"]
			String paramError = checkParams(payload, requiredParams)
			if (paramError != null) {
				renderError(ReturnCodes.Code.INVALID_PARAMS, paramError)
				return
			}



			def result = playerService.changePassword(session.player, payload.password_old, payload.password_new)

			if (result.returnCode == APIReturnCode.OK) {
				render(status: 200, contentType: 'application/json') {
					['result': ReturnCodes.Code.OK.value(), 'description': "Password changed"]
				}
			} else {
                if(result.returnCode == APIReturnCode.PLAYER_PASSWORD_MISMATCH) {
                    renderError(ReturnCodes.Code.PLAYER_PASSWORD_MISMATCH, result?.errors?.toString())
                }else {
                    renderError(ReturnCodes.Code.ERROR, result.errors.toString())
                }
				return
			}

		} catch (Exception e) {
			log.error("Caught Exception in PlayerController.changePassword()", e)
			renderError(ReturnCodes.Code.ERROR, e.toString())
		}
	} // changePassword()

    /**
     * To fetch the configuration details of an accountsystem.
     * As per the present implementation, it returns list of contries mapped to the site and list of currencies mapped to each country.
     * @return JSON contains countries mapped to the given site and currencies mapped to each country.
     * @author
     */
    def getSiteConfiguration() {
        log.info "Fetching site info for $params.accountSystemTag"
        Site site = Site.findByShortName(params.accountSystemTag)
        if(null == site){
            log.fatal("NO PROPER SITE CONFIGURED FOR ${params.accountSystemTag}")
            createErrorResponse(APIReturnCode.INVALID_SITE_ID)
            return
        }
        Country defaultCountry
        Currency defaultCurrency
        //String ip = Utils.getIP(request)

//        String respPayload = getLocationInfoForIPWebService(ip)
//        if(!StringUtils.isEmpty(respPayload)){
//            defaultCountry = Country.findByIso2(respPayload)
//        }

        // String respPayload = getLocationInfoForIPWebService(ip)

        String switchGeoIP = paramService.getString("geoip.switch")
        if(!StringUtils.isEmpty(switchGeoIP) && switchGeoIP.toBoolean()){
            String iso2CountryCode = request.getHeader("X-Country-ISO2")
            log.info "$site.id ISO2 Country Code from Request Header::: $iso2CountryCode"
            if(!StringUtils.isEmpty(iso2CountryCode)){
                defaultCountry = Country.findByIso2(iso2CountryCode)
            }
        }

        defaultCountry = (defaultCountry) ?: siteService.getInheritedValue(site, "country")
        defaultCurrency = (null != defaultCountry && null != defaultCountry.defaultCurrency) ? defaultCountry?.defaultCurrency : siteService.getInheritedValue(site, "currency")

        def builder = new JsonBuilder()

        def root = builder {
            name "$site.name"
            short_name "$site.shortName"
            "default_country"(null != defaultCountry ? "${defaultCountry.iso3}" : "")
            "default_country_dialCode"(null != defaultCountry ? "${defaultCountry.dialcode}" : "")
            "default_currency"(null != defaultCurrency ? "${defaultCurrency.iso}" : "")
            "default_min_deposit" site.minDeposit
            "default_max_deposit" site.maxDeposit
            "default_max_withdrawal_amount" site.maxWithdrawal
            "default_min_withdrawal_amount" site.minWithdrawal
            "boku_fee" siteService.getInheritedValue(site, "paymentSolutionFee")
            "use_withdraw_mappings" site.useWithdrawMappings
            "use_deposit_mappings" site.useDepositMappings
            "default_payment_method_change_threshold" site.paymentMethodChangeThresholds.collect { pmct ->
                ["currency"                       : "${pmct?.currency?.iso}",
                 "amount"                         : pmct?.amount
                ]
            }
            "multi_currency" site.multiCurrency
            "product_id"  "$site.epgProductId"
            "quickfire_game_rc_url_desktop" paramService.getString("quickfire.game.rc.url.desktop")
            if (site?.multiCurrency) {
                PersistentSet<Country> selCountries = siteService.getInheritedValue(site, "countries")
                if (null != selCountries) {
                    List<Country> countryLst = selCountries.toList()
                    if (null != countryLst && countryLst.size() > 0) {
                        Collections.sort(countryLst, new Comparator<Country>() {
                            public int compare(Country c1, Country c2) {
                                return (c1.iso3 > c2.iso3 ? 1 : (c1.iso3 == c2.iso3 ? 0 : -1));
                            }
                        })
                        if (countryLst.size() > 1) {
                            Country ukCountry
                            countryLst.collect { ctry ->
                                if (ctry.iso3 == "GBR") {
                                    ukCountry = ctry
                                }
                            }
                            if (null != ukCountry) {
                                countryLst.remove(ukCountry)
                                countryLst.add(0, ukCountry)
                            }
                        }
                        countries(
                                countryLst.collect { ctry ->
                                    List<Currency> currencyLst = ctry?.currency?.toList()
                                    Collections.sort(currencyLst, new Comparator<Currency>() {
                                        public int compare(Currency c1, Currency c2) {
                                            return (c1.iso > c2.iso ? 1 : (c1.iso == c2.iso ? 0 : -1));
                                        }
                                    })
                                    Currency defCurrency = ctry.defaultCurrency
                                    if(null != defCurrency){
                                        if(currencyLst.contains(defCurrency)){
                                            currencyLst.remove(defCurrency)
                                            currencyLst.add(0, defCurrency)
                                        } else{
                                            currencyLst.add(0, defCurrency)
                                        }
                                    }
                                    ["iso2"      : "$ctry.iso2",
                                     "iso3"      : "$ctry.iso3",
                                     "name"      : "$ctry.name",
                                     "dialCode" : "$ctry.dialcode",
                                     "currencies":
                                             currencyLst.collect { cur ->
                                                 ["iso"                            : "$cur.iso",
                                                  "name"                           : "$cur.name",
                                                  "min_deposit"                    : cur.minDeposit,
                                                  "max_deposit"                    : cur.maxDeposit,
                                                  "payment_method_change_threshold": cur.paymentMethodChangeThreshold,
                                                  "max_withdrawal_amount"          : cur.maxWithdrawal,
                                                  "min_withdrawal_amount"          : cur.minWithdrawal]
                                             }
                                    ]
                                }
                        )
                    }

                }

            }
            Iterator iter = site.quickAmount.iterator()
            while (iter.hasNext()){
                if (iter.next().amount == null)
                    iter.remove();
            }
            quick_deposit_amounts(
                    site.quickAmount.collect { quickAmounts ->
                        quickAmounts.amount
                    }

            )
            List<SiteGameConfig> siteGameConfigList = SiteGameConfig.findAllBySite(site)
            Iterator siteGameConfigIterator = siteGameConfigList.iterator()
            while(siteGameConfigIterator.hasNext()){
                if(siteGameConfigIterator.next().game.supportsBonusPlay){
                    siteGameConfigIterator.remove()
                }
            }
            bonus_not_supported_games(
                    siteGameConfigList.collect{ siteGameConfig ->
                        siteGameConfig.shortName
                    }
            )

        }
        render(status: 200, text: builder.toPrettyString(), contentType: "application/json", encoding: "UTF-8")
        return
    }

    /**
     * Method to fetch country location information for the given IP Address
     */
    public JSONObject getLocationInfoForIP(String ip){
        JSONObject respPayload
        String url = paramService.getString("player.country.ip.url")
        if(!StringUtils.isEmpty(ip) && !StringUtils.isEmpty(url)){
            url += ip
            HttpClient client = new DefaultHttpClient()
            HttpGet getRequest = new HttpGet(url)
            getRequest.addHeader("User-Agent", request.getHeader("User-Agent"))
            HttpResponse response = client.execute(getRequest)
            if(response.getStatusLine().getStatusCode() == 200){
                def jsonSlurper = new JsonSlurper()
                respPayload = jsonSlurper.parse(response.getEntity().getContent())
            }
        } else{
            return null
        }
        return respPayload
    }
    /**
     * Method to fetch country location information for the given IP Address
     */
    public String getLocationInfoForIPWthLicense(String ip){
        String switchGeoIP = paramService.getString("geoip.switch")
        String url = paramService.getString("player.country.ip.url")
        String licenseKey = paramService.getString("player.country.url.lkey")
        if(!StringUtils.isEmpty(switchGeoIP) && switchGeoIP.toBoolean() && !StringUtils.isEmpty(ip) && !StringUtils.isEmpty(url) && !StringUtils.isEmpty(licenseKey)){
            StringBuffer respPayload = new StringBuffer()
            url += "l=" + licenseKey + "&i=" + ip
            HttpClient client = new DefaultHttpClient()
            HttpGet getRequest = new HttpGet(url)
            getRequest.addHeader("User-Agent", request.getHeader("User-Agent"))
            HttpResponse response = client.execute(getRequest)
            if(response.getStatusLine().getStatusCode() == 200){
                BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()))
                String line
                while ((line = rd.readLine()) != null) {
                    respPayload.append(line);
                }
            }
            return respPayload.toString()
        } else{
            return null
        }

    }
    /**
     * Method to fetch country location information for the given IP Address
     */
    public String getLocationInfoForIPWebService(String ip){
        String switchGeoIP = paramService.getString("geoip.switch")
        String userID = paramService.getString("geoip.url.userid")
        String licenseKey = paramService.getString("geoip.url.lkey")
        if(!StringUtils.isEmpty(switchGeoIP) && switchGeoIP.toBoolean() && !StringUtils.isEmpty(ip) && !StringUtils.isEmpty(userID) && !StringUtils.isEmpty(licenseKey)){
            try{
            com.maxmind.geoip2.WebServiceClient client = new com.maxmind.geoip2.WebServiceClient.Builder(Integer.parseInt(userID), licenseKey).build()
            InetAddress ipAddress = InetAddress.getByName(ip)
            CountryResponse response = client.country(ipAddress)
            com.maxmind.geoip2.record.Country country = response.getCountry()
            return (null != country) ? country.getIsoCode() : null
            } catch (AddressNotFoundException _addrNotFoundEx) {
                log.error("Caught Exception while invoking geoip2 web service", _addrNotFoundEx)
            } catch (AuthenticationException _authEx) {
                log.error("Caught Exception while invoking geoip2 web service", _authEx)
            } catch (InvalidRequestException _invReqEx) {
                log.error("Caught Exception while invoking geoip2 web service", _invReqEx)
            } catch (OutOfQueriesException _oQEx) {
                log.error("Caught Exception while invoking geoip2 web service", _oQEx)
            } catch (HttpException _httpEx) {
                log.error("Caught Exception while invoking geoip2 web service", _httpEx)
            } catch (GeoIp2Exception _gIpEx) {
                log.error("Caught Exception while invoking geoip2 web service", _gIpEx)
            } catch (Exception _ex) {
                log.error("Caught Exception while invoking geoip2 web service", _ex)
            }
        } else{
            return null
        }
    }
} // controller