package com.nektan.revolve.backoffice

import com.nektan.revolve.coreservices.SubProvider
import grails.plugin.springsecurity.annotation.Secured

@Secured(['ROLE_SUPERUSER'])
class SubProviderController {

    def scaffold = SubProvider
}
