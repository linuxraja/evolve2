package com.nektan.revolve.api.evolve1

import com.fasterxml.jackson.annotation.JsonInclude
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.SerializationFeature
import com.nektan.revolve.api.APIReturnCode
import com.nektan.revolve.api.EvolveConstants
import com.nektan.revolve.api.GameClientType
import com.nektan.revolve.api.RGSName
import com.nektan.revolve.api.ReturnCodes
import com.nektan.revolve.api.RewardStatus
import com.nektan.revolve.api.SiteStatus
import com.nektan.revolve.api.gameserver.GameErrorPageModel
import com.nektan.revolve.api.gameserver.GameServerResponse
import com.nektan.revolve.api.v1.ApiController
import com.nektan.revolve.services.I18NService
import com.nektan.revolve.coreservices.Account
import com.nektan.revolve.coreservices.Country
import com.nektan.revolve.coreservices.Currency
import com.nektan.revolve.coreservices.Game
import com.nektan.revolve.coreservices.GameMinBets
import com.nektan.revolve.coreservices.GameDenomAmounts
import com.nektan.revolve.coreservices.GameSession
import com.nektan.revolve.coreservices.Language
import com.nektan.revolve.coreservices.Param
import com.nektan.revolve.coreservices.Player
import com.nektan.revolve.coreservices.PlayerFreeRounds
import com.nektan.revolve.coreservices.PlayerFreeRoundsGameConfig
import com.nektan.revolve.coreservices.Session
import com.nektan.revolve.coreservices.Site
import com.nektan.revolve.coreservices.SiteGameConfig
import com.nektan.revolve.coreservices.RGS
import com.nektan.revolve.dto.evolution.ChannelDetails
import com.nektan.revolve.dto.evolution.EvolutionPlayer
import com.nektan.revolve.dto.evolution.EvolutionSession
import com.nektan.revolve.dto.evolution.EvolutionSessionError
import com.nektan.revolve.dto.evolution.EvolutionSessionRequest
import com.nektan.revolve.dto.evolution.EvolutionSessionResponse
import com.nektan.revolve.dto.evolution.GameDetails
import com.nektan.revolve.dto.evolution.PlayerBrand
import com.nektan.revolve.dto.evolution.SessionConfig
import com.nektan.revolve.dto.evolution.TableDetails
import com.nektan.revolve.dto.evolution.Urls
import com.nektan.revolve.services.AccountService
import com.nektan.revolve.services.GameSessionService
import com.nektan.revolve.services.ParamService
import com.nektan.revolve.services.PlayerService
import com.nektan.revolve.services.SessionService
import com.nektan.revolve.services.SiteService
import grails.converters.JSON
import grails.plugin.springsecurity.annotation.Secured
import grails.plugins.rest.client.RestBuilder
import grails.plugins.rest.client.RestResponse
import grails.transaction.NotTransactional
import org.apache.commons.lang.LocaleUtils
import org.apache.commons.lang.StringUtils
import org.apache.http.HttpResponse
import org.apache.http.client.HttpClient
import org.apache.http.client.config.RequestConfig
import org.apache.http.client.methods.HttpGet
import org.apache.http.impl.client.HttpClientBuilder
import org.apache.http.util.EntityUtils
import org.codehaus.groovy.grails.web.json.JSONObject
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import wslite.soap.SOAPClient

import javax.net.ssl.HostnameVerifier
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLSession
import java.util.regex.Matcher
import java.util.regex.Pattern


/**
 * Created by heikokanzler on 14.07.15.
 *
 */

@Secured(['permitAll'])
class GameServerController extends ApiController implements EvolveConstants {

    static namespace = 'evolve1'


    static {
        HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {
            @Override
            boolean verify(String hostname, SSLSession sslSession) {
                try{
                    //Test log should be deleted after testing
                    System.out.println("SSL host name : "+hostname);
                    String url = Param.findByParamKey("evolution.gameserver.hostname")?.val;
                    if(null != url){
                        Pattern pattern = Pattern.compile("(https?://)([^:^/]*)(:\\d*)?(.*)?");
                        Matcher matcher = pattern.matcher(url);
                        matcher.find();
                        if (StringUtils.equals(hostname,matcher.group(2))){
                            return true;
                        }
                    }
                }catch(Exception e){
                    //Suppressing exception
                }
                return false;
            }
        });
    }

    SessionService sessionService
    PlayerService playerService
    SiteService siteService
    GameSessionService gameSessionService
    ParamService paramService
    AccountService accountService
    I18NService i18NService

    /**
     * Will be called by the Lobby to launch a game via
     * http://<domain>/revolve/api/account/<ACOUNTSYSTEM-TAG>/game/GAME-TAG
     * Creates the game session and then redirects the lobby browser to the game server
     * GAME-TAG will be used to lookup the game server and then to create the corresponding
     * game server url (i.e. Nektan Game Server, NYX, IGT or Roc
     * @return
     */
    def launch() {
        try {
        boolean isDemoGame = (params.game == "demogame");
        String accountSystemTag = params.accountSystemTag;
        Site site = Site.findByShortNameAndStatus(accountSystemTag, SiteStatus.Active.id);
        if (null == site) {
            log.info("GAME LAUNCH: Site null");
//            createErrorResponse(APIReturnCode.INVALID_SITE_ID)
                renderGameErrorPage(site?.url, "Account System Not Found.")
            return
        }
        String gameTag = (params.gameTag - (site.shortName - "-CASINO")).substring(1)
        Game game = Game.findByShortName(gameTag);
        if (null == game || null == game.rgs) {
            log.info("GAME LAUNCH: Game null");
           // createErrorResponse(APIReturnCode.INVALID_GAME_CONFIG)
                renderGameErrorPage(site?.url, "Game not available.")
            return
        }
        Session session = null;
        if (!isDemoGame) {
            log.info("GAME LAUNCH: Non Demo Game");
            session = getEvolvePlayerSession()
            //session = initialiseEvolveSession()
            if (null == session || !session.isActive()) {
                log.info("GAME LAUNCH: Session null");
//                if (isMobile()) {
//                 redirect(url: site.url)
//                    return
//                }
               //createErrorResponse(APIReturnCode.INVALID_SESSION)
                    renderGameErrorPage(site?.url, "Invalid session or session has expired.")
                return
            }

            if (null != session && !session.player?.playerStatus.canPlay) {
                log.info("GAME LAUNCH: Can play false");
//                if (isMobile()) {
//                    redirect(url: session.site.url)
//                    return
//                }
                //createErrorResponse(APIReturnCode.UNAUTHORIZED_GAME_PLAY_ERROR)
                    renderGameErrorPage(site?.url, "Unauthorized to play.")
                return
            }

            if (session.site.id != site.id) {
                log.info("GAME LAUNCH: Invalid account system");
//                if (isMobile()) {
//                    redirect(url: session.site.url)
//                    return
//                }
//              createErrorResponse(APIReturnCode.INVALID_SITE_ID)
                    renderGameErrorPage(site?.url, "Account system not found.")
                return
            }
            SiteGameConfig siteGameConfig = SiteGameConfig.findByGameAndSite(game, session.site)
            if (null == siteGameConfig) {
                log.info("GAME LAUNCH: Game not available");
//                if (isMobile()) {
//                    redirect(url: session.site.url)
//                    return
//                }
//              createErrorResponse(APIReturnCode.INVALID_GAME_CONFIG)
                    renderGameErrorPage(site?.url, "Game not available.")
                return
            }

            String iso2CountryCode = request.getHeader("X-Country-ISO2")
            log.info("Game Launch: ISO2 Country Code from Request Header: " + iso2CountryCode + " game: " + game.shortName + " playerId: " + session.player.id)
            Country playingCountry
            if(StringUtils.isNotEmpty(iso2CountryCode)){
                playingCountry = Country.findByIso2(iso2CountryCode)
            }

            if (game.rgs.countries != null && !game.rgs.countries.isEmpty() &&
                    (!game.rgs.countries.contains(session.player.country) || (null != playingCountry && !game.rgs.countries.contains(playingCountry)))) {
                log.info("GAME LAUNCH: Country miss match");
//                if (isMobile()) {
//                    redirect(url: session.site.url)
//                    return
//                }
//              createErrorResponse(APIReturnCode.INVALID_PLAYER_COUNTRY)
                    renderGameErrorPage(site?.url, "Game play not allowed for player country.")
                return
            }

            if(game.isVipGame && null == session.player.vipLevel){
                log.info("GAME LAUNCH: VIP Game is not available for Non-VIP Player.");
                renderGameErrorPage(site?.url, "Game not available.")
                return
            }
        }

        Account cashAccount = null;
        Currency currency = isDemoGame ? siteService.getInheritedValue(site, 'currency') : null;
        if (session != null && session.player != null) {
            cashAccount = accountService.getCashAccount(session.player)
            currency = cashAccount.getCurrency();
        }

        RGSName rgsName = RGSName.findByRGSName(game.rgs.name);
        if (null == rgsName) {
            log.info("GAME LAUNCH: RGS null");
//            createErrorResponse(APIReturnCode.INVALID_GAME_CONFIG)
                renderGameErrorPage(site?.url, "Game not available.")
            return
        }

        //String gameLaunchURL = null;
        GameServerResponse response = null
        switch (rgsName) {

            case RGSName.NEKTAN:
                    response = buildNektanLaunchURL(isDemoGame, site, game, session);
                break;
            case RGSName.NYX:
                    response = buildNYXLaunchURL(isDemoGame, site, game, session, currency, params.lang);
                break;
            case RGSName.NETENT:
                    response = buildNetEntLaunchURL(isDemoGame, site, game, session, currency,params.lang);
                break;
            case RGSName.IGT:
                    response = buildIGTLaunchURL(isDemoGame, site, game, session, currency, isMobile());
                break;
            case RGSName.IWG:
                    response = buildIWGLaunchURL(isDemoGame, site, game, session, currency);
                break;
            case RGSName.QUICKFIRE:
                    response = buildQuickFireLaunchURL(isDemoGame, site, game, session, isMobile());
                break;
            case RGSName.ROC:
                    response = buildROCLaunchURL(isDemoGame, site, game, session, currency);
                break;
            case RGSName.EVOLUTION:
                    response = buildEvolutionLaunchURL(isDemoGame, site, game, session, currency, isMobile());
                break;
            case RGSName.REDTIGER:
                    response = buildRedTigerLaunchURL(isDemoGame, site, game, session);
                break;
            case RGSName.ELITE:
                    response = buildEliteGameLaunchURL(isDemoGame, site, game, session, isMobile(), params.lang);
            break;
            default:
                    response = null;
                break;
        }
        if (null == response) {
            log.info("GAME LAUNCH: response null");
                renderGameErrorPage(site?.url, "Oops something went wrong.")
                return
            }

            //render response
        if (response.isRender) {
                log.info("GAME LAUNCH RESPONSE RENDER VIEW " + response.getRenderView() + " MODEL " + response.getRenderModel());
                GameErrorPageModel model = (GameErrorPageModel) response.getRenderModel();
                renderGameErrorPage(model.getLobbyUrl(), model.getErrorMessage())
            return
        }
         //redirect response
       if (response.isRedirect) {
            log.info("GAME LAUNCH RESPONSE REDIRECT : " + response.getRedirectURL());
            redirect(url: response.getRedirectURL());
            return;
       }

            return;
        }catch(Exception exp){
            log.error("Exception occurred in game launch "+exp.getMessage());
            // exp.printStackTrace()
            renderGameErrorPage(null, "Oops something went wrong.")
            return
        }
    }

    /**
     * method will be used to build nektan game launch URL.
     * @param isDemoGame
     * @param site
     * @param game
     * @param session
     * @return
     */
    private GameServerResponse buildNektanLaunchURL(boolean isDemoGame, Site site, Game game, Session session) {

        String gameLaunchURL = siteService.getInheritedValue(site, 'nektanGameServerUrl');
        if (StringUtils.isBlank(gameLaunchURL)) {
            log.fatal("Invalid game launch URL configured for Nektan RGS");
            return prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,"Oops Something went Wrong!"))
        }

        gameLaunchURL += (isDemoGame ? "/slotsGameDemo" : "/slotsGame") +
                "?gameTag=${params.gameTag}" +
                "&externalAccountSystemTag=${params.accountSystemTag}";


        def gameSessionResult = gameSessionService.authenticatePlayerWithToken(session?.token, null, "desk", false, true, game)

        if (!isDemoGame && (gameSessionResult == null || gameSessionResult.gameSession == null || gameSessionResult.returnCode != APIReturnCode.OK)) {
            return  prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,"Oops Something went Wrong!"));
        }

        if (!isDemoGame) {
            gameLaunchURL += "&externalAccountSystemSessionId=${gameSessionResult?.gameSession?.token}"
        }

        if (!isDemoGame && game.rgs.isRealitycheckEnabled && session?.player?.realityCheckLimit != null) {
            gameLaunchURL += "&jurisdiction=uk"
            gameLaunchURL += "&realitycheck_uk_elapsed=0"
            gameLaunchURL += "&realitycheck_uk_limit=${session?.player?.realityCheckLimit}"
            gameLaunchURL += "&realitycheck_uk_history=${site?.historyUrl?.encodeURL()}"
            gameLaunchURL += "&realitycheck_uk_exit=${site?.url?.encodeURL()}"
            gameLaunchURL += "&realitycheck_uk_proceed="
        }


        return prepareRedirectResponse(gameLaunchURL);
    }

    /**
     * method will be used to build NYX game launch URL.
     * @param isDemoGame
     * @param site
     * @param game
     * @param session
     * @param currency
     * @return
     */
    private GameServerResponse buildNYXLaunchURL(boolean isDemoGame, Site site, Game game, Session session, Currency currency, String lang) {

        String gameClientType = site?.nyxClientType
        if (isMobile()) {
            gameClientType = game.mobileClientType != null ? com.nektan.revolve.api.GameClientType.getGameClientType(game.mobileClientType).name : null
        } else {
            gameClientType = game.clientType != null ? com.nektan.revolve.api.GameClientType.getGameClientType(game.clientType).name : null
        }

        String gameLaunchURL = site.nyxGameServerUrl
        if (StringUtils.isBlank(gameLaunchURL)) {
            log.fatal("Invalid game launch URL configured for NYX RGS");
            return prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,"Oops Something went Wrong!"));
        }

        String locale = site.defaultLocale;
        if(StringUtils.isNotEmpty(lang) ) {
            Language language = Language.findByIso(lang)
            locale = (null != language && StringUtils.isNotEmpty(language.nyxLocale)) ? language.nyxLocale : locale
        }
        gameLaunchURL += "?nogsgameid=${game.externalId}" +
                "&nogsoperatorid=${site.nyxOperatorId}" +
                "&nogscurrency=${currency.iso}" +
                "&nogslang=${locale}" +
                "&clienttype=${gameClientType}" +
                "&lobbyurl=${site.url?.encodeURL()}" +
                "&depositurl=${site.depositUrl?.encodeURL()}"

        if (!isDemoGame && game.rgs.isRealitycheckEnabled && session?.player?.realityCheckLimit != null) {
            gameLaunchURL += "&jurisdiction=uk"
            gameLaunchURL += "&realitycheck_uk_elapsed=0"
            gameLaunchURL += "&realitycheck_uk_limit=${session?.player?.realityCheckLimit * 60}"
            gameLaunchURL += "&realitycheck_uk_history=${site.historyUrl?.encodeURL()}"
            gameLaunchURL += "&realitycheck_uk_exit=${site.url?.encodeURL()}"
            gameLaunchURL += "&realitycheck_uk_proceed="
        }
        if (!isDemoGame) {
            gameLaunchURL += "&sessionid=${session.token}"
            gameLaunchURL += "&accountid=${session.player?.id}"
            gameLaunchURL += "&nogsmode=${site.nyxGameMode}"
        } else {
            gameLaunchURL += "&nogsmode=demo"
        }

        if (game.params != null) {
            def paramsMap = grails.converters.JSON.parse(game.params)
            if (paramsMap.variantId != null) {
                gameLaunchURL += "&variant=${paramsMap.variantId}"
            }
        }
        return  prepareRedirectResponse(gameLaunchURL);
    }

    /**
     * method will be used to build IGT game launch URL.
     * @param isDemoGame
     * @param site
     * @param game
     * @param session
     * @param currency
     * @param isMobilePlatform
     * @return
     */
    private GameServerResponse buildIGTLaunchURL(boolean isDemoGame, Site site, Game game, Session session, Currency currency, boolean isMobilePlatform) {

        String gameLaunchURL = paramService.getString("igt.gameServer.url")
        if (StringUtils.isBlank(gameLaunchURL)) {
            log.fatal("Invalid game launch URL configured for IGT RGS");
            return  prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,"Oops Something went Wrong!"));
        }

        String presentType = "FLSH"
        String channelType = "INT"

        if (isMobilePlatform) {
            gameLaunchURL = paramService.getString("igt.mobile.gameServer.url")
            if (game.mobileClientType != null && (game.mobileClientType == GameClientType.HTML.id || game.mobileClientType == GameClientType.HTML5.id)) {
                presentType = "HTML"
                channelType = "MOB"
            }
        } else {
            if (game.clientType != null && (game.clientType == GameClientType.HTML.id || game.clientType == GameClientType.HTML5.id)) {
                presentType = "HTML"
                channelType = "MOB"
            }
        }
        if (isDemoGame) {
            gameLaunchURL += "?nscode=${site?.igtNsCode}" +
                    "&softwareid=${game.externalId}" +
                    "&countrycode=GB" +
                    "&skincode=${site?.igtSkinCode}" +
                    "&technology=${presentType}" +
                    "&currencycode=FPY" +
                    "&language=en" +
                    "&channel=${channelType}" +
                    "&presenttype=STD"
            if (isMobilePlatform) {
                gameLaunchURL += "&minbet=1.0&denomamount=1.0"
                String lobbyURLKey = "&" + site?.igtSkinCode + "_lobbyURL"
                gameLaunchURL += lobbyURLKey + "=" + site?.url

            }
        } else {
            def gameSessionResult = gameSessionService.authenticatePlayerWithToken(session.token, null, "desk", false, false)
            if (gameSessionResult == null || gameSessionResult.returnCode != APIReturnCode.OK || gameSessionResult.gameSession == null) {
                return  prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,"Oops Something went Wrong!"));
            }
            String skinCode = (game.isVipGame && null != session.player.vipLevel) ? gameSessionResult.gameSession.session.site?.igtVipSkinCode : gameSessionResult.gameSession.session.site?.igtSkinCode;

            gameLaunchURL += "?nscode=${session.site?.igtNsCode}" +
                    "&softwareid=${game.externalId}" +
                    "&uniqueid=${gameSessionResult.gameSession.player?.id}" +
                    "&countrycode=${gameSessionResult.gameSession.session.player?.country.iso2}" +
                    "&skincode=${skinCode}" +
                    "&technology=${presentType}" +
                    "&securetoken=${gameSessionResult.gameSession.token}" +
                    "&currencycode=${currency?.iso}" +
                    "&language=en" +
                    "&channel=${channelType}" +
                    "&dateofbirth=${gameSessionResult.gameSession.player?.dateOfBirth}" +
                    "&gender=${gameSessionResult.gameSession.player?.gender}"+
                    "&presenttype=STD"



            if (game.allowFreeRounds) {
                PlayerFreeRounds playerFreeRounds = PlayerFreeRounds.findByPlayerAndStatus(session.player, RewardStatus.Active.id);
                if (playerFreeRounds != null && playerFreeRounds.getFreeRoundsBalance() > 0
                        && PlayerFreeRoundsGameConfig.countByPlayerFreeRoundsAndGame(playerFreeRounds, game) > 0) {
                    BigDecimal stakePerLine =playerFreeRounds.getBonus().getBetLevel();
                    if(playerFreeRounds.getBonus().isBetLevelFromGame()) {
                        GameMinBets gameMinBets = GameMinBets.findByGameAndCurrency(game, gameSessionResult.gameSession.player.getCurrency());
                        if(gameMinBets != null && gameMinBets.minBet != null) {
                                stakePerLine = gameMinBets.getScaledMinBet()
                        }
                    }
                    gameSessionService.startFreeSpinsGameSession(gameSessionResult.gameSession, playerFreeRounds)
                    gameLaunchURL += "&playMode=freespin"
                    gameLaunchURL += "&freespin_bet=" + stakePerLine.toPlainString()
                    gameLaunchURL += "&freespin_lines=" + game.getNoOfLines()
                    gameLaunchURL += "&freespin_num=" + playerFreeRounds.getFreeRoundsBalance()
                    gameLaunchURL += "&freespin_tokenID=" + gameSessionResult.gameSession.freespinToken
                    String fsBalanceKey = "&"+skinCode +"_fsWin=";
                    gameLaunchURL += fsBalanceKey + (playerFreeRounds.getScaledTotalWinning() == null ? BigDecimal.ZERO : playerFreeRounds.getScaledTotalWinning())
                    String fsHistoryURL = "&" +skinCode +"_historyURL=";
                    gameLaunchURL += fsHistoryURL + gameSessionResult.gameSession.site?.historyUrl

                }
            }
            if (isMobilePlatform) {
                BigDecimal minBetAmt = BigDecimal.ZERO;
                BigDecimal denomAmt = BigDecimal.ZERO;
                GameMinBets gameMinBets = com.nektan.revolve.coreservices.GameMinBets.findByGameAndCurrency(game, gameSessionResult.gameSession.player.getCurrency());
                if(gameMinBets != null && gameMinBets.minBet != null) {
                    minBetAmt = gameMinBets.getScaledMinBet()
                }
                GameDenomAmounts  gameDenomAmounts = com.nektan.revolve.coreservices.GameDenomAmounts.findByGameAndCurrency(game, gameSessionResult.gameSession.player.getCurrency());
                if(gameDenomAmounts != null && gameDenomAmounts.amount != null) {
                    denomAmt = gameDenomAmounts.getScaledAmount()
                }
                gameLaunchURL += "&minbet=${minBetAmt}&denomamount=${denomAmt}"
//                String lobbyURLKey = "&" + gameSessionResult.gameSession.site?.igtSkinCode + "_lobbyURL"
//                gameLaunchURL += lobbyURLKey + "=" + gameSessionResult.gameSession.site?.url
            }

            String lobbyURLKey = "&" + skinCode + "_lobbyURL"
            gameLaunchURL += lobbyURLKey + "=" + gameSessionResult.gameSession.site?.url

        }

        return  prepareRedirectResponse(gameLaunchURL);
    }

    /**
     * method will be used to build ROC game launch URL.
     * @param isDemoGame
     * @param site
     * @param game
     * @param session
     * @param currency
     * @return
     */
    private GameServerResponse buildROCLaunchURL(boolean isDemoGame, Site site, Game game, Session session, Currency currency) {

        String gameLaunchURL = paramService.getString("roc.gameServer.url")
        if (StringUtils.isBlank(gameLaunchURL)) {
            log.fatal("Invalid game launch URL configured for ROC RGS");
            return  prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,"Oops Something went Wrong!"));
        }

        if (isDemoGame) {
            gameLaunchURL += "?gameid=${game.externalId}&sessionToken=guest&currency=${currency.iso}&lobbyurl=${site?.url}"
        } else {
            def gameSessionResult = gameSessionService.authenticatePlayerWithToken(session?.token, null, "desk", false, true)
            if (gameSessionResult == null || gameSessionResult.returnCode != APIReturnCode.OK || gameSessionResult.gameSession == null) {
                return prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,"Oops Something went Wrong!"));;
            }
            gameLaunchURL += "?gameid=${game.externalId}&sessionToken=${gameSessionResult?.gameSession?.token}&currency=${currency.iso}&lobbyurl=${session.site.url}"

            if (game.rgs.isRealitycheckEnabled && session?.player?.realityCheckLimit != null) {
                gameLaunchURL += "&jurisdiction=uk"
                gameLaunchURL += "&realitycheck_uk_elapsed=0"
                gameLaunchURL += "&realitycheck_uk_limit=${session?.player?.realityCheckLimit * 60}"
                gameLaunchURL += "&realitycheck_uk_history=${session?.site.historyUrl?.encodeURL()}"
                gameLaunchURL += "&realitycheck_uk_exit=${session?.site.url?.encodeURL()}"
                gameLaunchURL += "&realitycheck_uk_proceed="
            }
        }
        return  prepareRedirectResponse(gameLaunchURL);
    }

    /**
     * method will be used to build QUICKFIRE game launch URL.
     * @param isDemoGame
     * @param site
     * @param game
     * @param session
     * @param isMobilePlatform
     * @return
     */
    private GameServerResponse buildQuickFireLaunchURL(boolean isDemoGame, Site site, Game game, Session session, boolean isMobilePlatform) {

        String gameLaunchURL = "";
        String csId = "";
        String variant = "";
        String applicationid = paramService.getString('quickfire.game.applicationid');
        String serverid = "";
        String theme = "";
        String gameName = ""
        if (game.params != null) {
            def paramsMap = grails.converters.JSON.parse(game.params)
            if (paramsMap.gameName != null) {
                gameName = paramsMap.gameName
            }
        }
        if (!isMobilePlatform) {
            gameLaunchURL = paramService.getString("quickfire.game.server.url.desktop")
            if (StringUtils.isBlank(gameLaunchURL)) {
                log.fatal("Invalid desktop game launch URL configured for QuickFire RGS");
                return  prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,"Oops Something went Wrong!"));
            }
            if (!isDemoGame) {
                variant = paramService.getString('quickfire.game.real.variant');
                csId = paramService.getString('quickfire.game.real.csid');
                theme = paramService.getString('quickfire.game.real.theme');
                serverid = paramService.getString('quickfire.game.real.serverid');
                def gameSessionToken = gameSessionService.authenticatePlayerWithToken(session.token, null, "desk", false, false)

                if (gameSessionToken.returnCode != APIReturnCode.OK || gameSessionToken.gameSession == null) {
                    return prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,"Oops Something went Wrong!"));
                }
                gameLaunchURL += "?AuthToken=${gameSessionToken.gameSession.token}" +
                        "&sext1=genauth&sext2=genauth" +
                        "&gameid=${gameName}" +
                        "&csid=${csId}" +
                        "&ul=${session.site?.lang}" +
                        "&variant=${variant}" +
                        "&theme=${theme}" +
                        "&applicationid=${applicationid}" +
                        "&serverid=${serverid}" +
                        "&usertype=0"
            } else {
                variant = paramService.getString('quickfire.game.demo.variant');
                csId = paramService.getInt('quickfire.game.demo.csid');
                theme = paramService.getString('quickfire.game.demo.theme');
                serverid = paramService.getString('quickfire.game.demo.serverid');
                gameLaunchURL += "?gameid=${gameName}" +
                        "&sext1=demo&sext2=demo" +
                        "&csid=${csId}" +
                        "&ul=${site?.lang}" +
                        "&variant=${variant}" +
                        "&theme=${theme}" +
                        "&applicationid=${applicationid}" +
                        "&serverid=${serverid}" +
                        "&usertype=5"
            }
        } else { // mobile
            gameLaunchURL = paramService.getString("quickfire.game.server.url.mobile")
            if (StringUtils.isBlank(gameLaunchURL)) {
                log.fatal("Invalid mobile game launch URL configured for QuickFire RGS");
                return  prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,"Oops Something went Wrong!"));;
            }
            if (!isDemoGame) {
                def gameSessionToken = gameSessionService.authenticatePlayerWithToken(session.token, null, "mob", false, false)
                if (gameSessionToken == null || gameSessionToken.returnCode != APIReturnCode.OK || gameSessionToken.gameSession == null) {
                    return  prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,"Oops Something went Wrong!"));;
                }
                csId = paramService.getString('quickfire.game.real.csid');

                gameLaunchURL += "${gameName}" +
                        "/${session.site?.lang}" +
                        "?casinoID=${csId}" +
                        "&lobbyURL=${session.site?.url}" +
                        "&loginType=vanguardSessionToken" +
                        "&bankingURL=${session.site.depositUrl?.encodeURL()}" +
                        "&isRGI=true" +
                        "&authToken=${gameSessionToken.gameSession.token}"
                if (game.rgs.isRealitycheckEnabled && null != session.player.realityCheckLimit) {
                    gameLaunchURL += "&interfaceURL=${session.site?.url}/revolve/api/accountsystem/quickfire/realityCheck"
                }
            } else {
                int demoCsid = paramService.getInt('quickfire.game.demo.csid').intValue()
                gameLaunchURL += "${gameName}" +
                        "/${site?.lang}" +
                        "?casinoID=${demoCsid}" +
                        "&lobbyURL=${site?.url}" +
                        "&loginType=vanguardSessionToken" +
                        "&bankingURL=${site?.depositUrl?.encodeURL()}" +
                        "&isRGI=true" +
                        "&authToken=" +
                        "&isPracticePlay=true"
            }
        }
        return  prepareRedirectResponse(gameLaunchURL);
    }

    /**
     * method will be used to build NETENT game launch URL.
     * @param isDemoGame
     * @param site
     * @param game
     * @param session
     * @param currency
     * @return
     */
    private GameServerResponse buildNetEntLaunchURL(boolean isDemoGame, Site site, Game game, Session session, Currency currency ,String lang) {

        String gameSessionToken = null;
        String gameLaunchURL = null;
        String gameLanguage = isValidLanguage(lang) ? lang : site?.lang
        if (isDemoGame) {
            gameSessionToken = "DEMO-" + Math.floor(Math.random() * 10000000) + "-" + site.currency.iso;
        } else {
            if (sessionService.isActiveSession(session.token)) {
                def result = createNetEntSession(session.player.id, currency.iso, game.externalId.contains("html"))
                if(null != result && StringUtils.isEmpty(result.data)){
                    return  prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.oops", null)));
                }
                GameSession gameSession = GameSession.findByToken(result.data)
                if (gameSession == null) {
                    def gameSessionResult = gameSessionService.authenticatePlayerWithToken(session.token, null, "mob")
                    if (gameSessionResult.returnCode == APIReturnCode.OK) {
                        gameSession = gameSessionResult.gameSession
                        gameSession.token = result.data
                        gameSession.save(failOnError: true, flush: true)
                    }
                } else {
                    gameSessionService.reactivateGameSession(gameSession.token)
                }
                gameSessionToken = gameSession.token
            }
        }
        if (null == gameSessionToken) {
            return  prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.oops", null)));
        }
        //TODO
        Map paramsMap = grails.converters.JSON.parse(game.params)
        String tableId = paramsMap.containsKey("tableId") ? paramsMap.get("tableId") : ""

        String gameCategory = game?.category?.shortName
        String categoryURL = gameCategory?.equalsIgnoreCase("live") ? "/revolve/api/accountsystem/launch/netentDealer?" : "/revolve/api/accountsystem/launch/netent?"
        gameLaunchURL = site.url + categoryURL + "token=" +gameSessionToken + "&site=" + site.id + "&game=" + game?.externalId  + "&tableId=" + tableId + "&timestamp=" + System.currentTimeMillis() + "&lang=" +lang
        if (!isDemoGame) {
            gameLaunchURL = gameLaunchURL + "&isDemoGame=false"
        }
        return prepareRedirectResponse(gameLaunchURL);
    }

    /**
     * method will be used to launch netent game in iframe.
     * @param
     * @return
     */
    def netentLaunch() {
        log.info("Launching netent game using redirect..site.." + params.site + " game.." + params.game + " token.." + params.token + " isDemoGame.." + params.isDemoGame + " lang.." + params.lang)
        Site site = Site.findById(Long.valueOf(params.site))
        boolean isRealityCheckEnabled = false;
        String aspectRatio = "16/9";
        String gameLanguage = isValidLanguage(params.lang) ? params.lang : site?.lang
        if (params.game != null) {
            Game game = Game.findByExternalId(params.game)
            if(game == null){
                this.renderGameErrorPage(site?.url, i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.game.not.available", null))
                return
            }
            RGS rgs = game.rgs
            isRealityCheckEnabled = rgs?.isRealitycheckEnabled
            Map paramsMap = grails.converters.JSON.parse(game.params)
            aspectRatio = paramsMap.containsKey("aspectRatio") ? paramsMap.get("aspectRatio") : "16/9"
        }
        GameSession gameSession = gameSessionService.getSession(params.token)
        Player player = gameSession?.player

        render(view: "netentGame", model: [
                gameSessionToken     : params?.token,
                staticGameServerUrl  : site?.netentStaticContentUrl,
                gameServerUrl        : site?.netentGameServerUrl,
                gameId               : params?.game,
                siteId               : params?.site,
                lobbyUrl             : site?.url,
                realityCheckLimit    : player?.realityCheckLimit,
                isRealityCheckEnabled: isRealityCheckEnabled,
                historyUrl           : site?.historyUrl,
                isMobile             : isMobile(),
                isRealGame           : "false".equals(params.isDemoGame),
                aspectRatio          : aspectRatio,
                gameLanguage         : gameLanguage,
                realitycheckmessage  : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.message", ['%1', '%2'] as Object[]),
                continueButtonText       : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.continue", null),
                accountHistoryButtonText : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.account.history",null),
                closeButtonText          : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.close", null)
        ])
        return
    }

    /**
     * method will be used to launch netent table game in iframe.
     * @param
     * @return
     */
    def netentTableGamesLaunch() {
        log.info("netentTableGamesLaunch - Launching netent table game using redirect..site.." + params.site + " game.." + params.game + " token.." + params.token +
                " isDemoGame.." + params.isDemoGame + " lang.." + params.lang+ " tableId.." + params.tableId)
        Site site = Site.findById(Long.valueOf(params.site))
        boolean isRealityCheckEnabled = false;
        String aspectRatio = "16/9";
        String gameLanguage = isValidLanguage(params.lang) ? params.lang : site?.lang
        String casinoHost = paramService.getString("netent.table.game.live.casino.host")
        String casinoBrand = paramService.getString("netent.table.game.live.casino.brand")
        String liveDealerUrl = paramService.getString("netent.live.dealer.server.url");
        if (StringUtils.isBlank(casinoHost) || StringUtils.isBlank(casinoHost) || StringUtils.isBlank(liveDealerUrl)) {
            log.fatal("netentTableGamesLaunch - Please configure param for live casino host/brand/dealerUrl for Netent RGS");
            return  prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,"Oops Something went Wrong!"));
        }
        if (params.game != null) {
            Game game = Game.findByExternalId(params.game)
            if(game == null){
                this.renderGameErrorPage(site?.url, i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.game.not.available", null))
                return
            }
            RGS rgs = game.rgs
            isRealityCheckEnabled = rgs?.isRealitycheckEnabled
            Map paramsMap = grails.converters.JSON.parse(game.params)
            aspectRatio = paramsMap.containsKey("aspectRatio") ? paramsMap.get("aspectRatio") : "16/9"
        }
        GameSession gameSession = gameSessionService.getSession(params.token)
        Player player = gameSession?.player

        render(view: "netentTableGame", model: [
                gameSessionToken     : params?.token,
                staticGameServerUrl  : site?.netentStaticContentUrl,
                gameServerUrl        : site?.netentGameServerUrl,
                liveDealerUrl        : liveDealerUrl,
                gameId               : params?.game,
                siteId               : params?.site,
                lobbyUrl             : site?.url,
                realityCheckLimit    : player?.realityCheckLimit,
                isRealityCheckEnabled: isRealityCheckEnabled,
                historyUrl           : site?.historyUrl,
                isMobile             : isMobile(),
                isRealGame           : "false".equals(params.isDemoGame),
                aspectRatio          : aspectRatio,
                gameLanguage         : gameLanguage,
                realitycheckmessage  : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.message", ['%1', '%2'] as Object[]),
                continueButtonText       : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.continue", null),
                accountHistoryButtonText : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.account.history",null),
                closeButtonText          : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.close", null),
                tableId:  params?.tableId,
                liveCasinoHost: casinoHost,
                casinoBrand : casinoBrand
        ])
        return
    }

    /**
     * method will be used to launch EVOLUTION game in iframe.
     * @param
     * @return
     */
    def evolutionLaunch() {
        log.info("Launching evolution game using redirect..site..")
        /*Site site = Site.findById(Long.valueOf(params.site))
        boolean isRealityCheckEnabled = false;
        String aspectRatio = "16/9";
        if (params.game != null) {
            Game game = Game.findByExternalId(params.game)
            if(game == null){
                createErrorResponse(APIReturnCode.INVALID_GAME_CONFIG)
                return
            }
            RGS rgs = game.rgs
            isRealityCheckEnabled = rgs?.isRealitycheckEnabled
            Map paramsMap = grails.converters.JSON.parse(game.params)
            aspectRatio = paramsMap.containsKey("aspectRatio") ? paramsMap.get("aspectRatio") : "16/9"
        }
        GameSession gameSession = gameSessionService.getSession(params.token)
        Player player = gameSession?.player*/
        String evolutionStaticUrl = paramService.getString("evolution.gameserver.hostname");
        if(StringUtils.isEmpty(evolutionStaticUrl)){
            this.renderGameErrorPage(null, "Oops! something went wrong.")
            return
        }

        log.info("Evolution static URL to load in iframe : "+evolutionStaticUrl + params?.entry);
        render(view: "evolutionGame", model: [
                evolutionUrl : evolutionStaticUrl + params?.entry
        ])
        return
    }

    /**
     * method will be used to build IWG game launch URL.
     * @param isDemoGame
     * @param site
     * @param game
     * @param session
     * @param currency
     * @return
     */
    private GameServerResponse buildIWGLaunchURL(boolean isDemoGame, Site site, Game game, Session session, Currency currency) {

        String gameLaunchURL = paramService.getString("iwg.gameServer.url")
        String platform = isMobile() ? 'M' : 'W';
        if (isDemoGame) {
            gameLaunchURL = gameLaunchURL +
                    "${game.externalId}/" +
                    "&gameId=${game.externalId}" +
                    "&language=en" +
                    "&currency=${currency?.iso}" +
                    "&platform=${platform}" +
                    "&playMode=D" +
                    "&moneyModeUrl=${site?.url?.encodeURL()}" +
                    "&depositUrl=${site?.depositUrl?.encodeURL()}" +
                    "&lobbyUrl=${site?.url?.encodeURL()}"

        } else {
            boolean isRealityCheckEnabled = false;
            RGS rgs = game?.rgs
            if (rgs != null) {
                isRealityCheckEnabled = rgs?.isRealitycheckEnabled
            }
            def gameSessionResult = gameSessionService.authenticatePlayerWithToken(session.token, null, "desk", false, false)
            if (gameSessionResult == null || gameSessionResult.returnCode != APIReturnCode.OK || gameSessionResult.gameSession == null) {
                return  prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,"Oops Something went Wrong!"));
            }
            gameLaunchURL = gameLaunchURL +
                    "${game.externalId}/" +
                    "&gameId=${game.externalId}" +
                    "&language=en" +
                    "&currency=${currency?.iso}" +
                    "&platform=${platform}" +
                    "&playMode=M" +
                    "&playerId=${session.player.id}" +
                    "&sessionToken=${gameSessionResult.gameSession.token}" +
                    "&lobbyUrl=${site?.url?.encodeURL()}" +
                    "&moneyModeUrl=${site?.url?.encodeURL()}" +
                    "&depositUrl=${site?.depositUrl?.encodeURL()}" +
                    "&claimUrl=${site?.url?.encodeURL()}"

            if (isRealityCheckEnabled && session?.player?.realityCheckLimit != null) {
                gameLaunchURL += "&realityJurisdiction=uk"
                gameLaunchURL += "&realityRemainingSecs=${session?.player?.realityCheckLimit * 60}"
                gameLaunchURL += "&realityIntervalSecs=${session?.player?.realityCheckLimit * 60}"
                gameLaunchURL += "&realityUrl=${site.historyUrl?.encodeURL()}"
            }
        }
        return  prepareRedirectResponse(gameLaunchURL);
    }

    /**
     * method will be used to launch NETENT game in iframe.
     * @param
     * @return
     */
    def netentMobileLaunch() {
        log.info("Launching netent mobile game using redirect" + params.gameSessionToken)
        Site site = Site.findById(Long.valueOf(params.site))
        boolean isRealityCheckEnabled = false;
        if (params.game != null) {
            Game game = Game.findByExternalId(params.game)
            RGS rgs = game.rgs
            isRealityCheckEnabled = rgs?.isRealitycheckEnabled
        }
        GameSession gameSession = gameSessionService.getSession(params.gameSessionToken)
        Player player = gameSession?.player
        log.info("RC Limit for player with id :" + player?.id + " is : " + player?.realityCheckLimit)
        String gameLanguage = isValidLanguage(params.lang) ? params.lang : site?.lang
        render(view: "netentGame_mobile", model: [
                gameSessionToken     : params?.gameSessionToken,
                staticGameServerUrl  : site?.netentStaticContentUrl,
                gameServerUrl        : site?.netentGameServerUrl,
                gameId               : params?.game,
                lobbyUrl             : site?.url,
                realityCheckLimit    : player?.realityCheckLimit,
                isRealityCheckEnabled: isRealityCheckEnabled,
                historyUrl           : site?.historyUrl,
                realitycheckmessage1  : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.message1", ['%1', '%2'] as Object[]),
                realitycheckmessage2       : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.message2", null),
                continueButtonText       : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.continue", null),
                leaveButtonText : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.leave",null),
                timeText          : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.time", null),
                durationText  : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.duration", ['%1', '%2'] as Object[]),
                minutesText       : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.duration.minutes", null),
                gameHistoryButtonText : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.game.history",null),
                lobbyText          : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.lobby", null),
                realitycheckText  : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck",null)
        ])
        return
    }

    /**
     * method will be used to launch NETENT table game in iframe mobile.
     * @param
     * @return
     */
    def netentTableGameMobileLaunch() {
        log.info("netentTableGameMobileLaunch - Launching netent mobile game using redirect" + params.gameSessionToken)
        Site site = Site.findById(Long.valueOf(params.site))
        boolean isRealityCheckEnabled = false;
        if (params.game != null) {
            Game game = Game.findByExternalId(params.game)
            RGS rgs = game.rgs
            isRealityCheckEnabled = rgs?.isRealitycheckEnabled
        }
        GameSession gameSession = gameSessionService.getSession(params.gameSessionToken)
        Player player = gameSession?.player
        log.info("netentTableGameMobileLaunch - RC Limit for player with id :" + player?.id + " is : " + player?.realityCheckLimit)
        String gameLanguage = isValidLanguage(params.lang) ? params.lang : site?.lang
        render(view: "netentTableGame_mobile", model: [
                gameSessionToken     : params?.gameSessionToken,
                staticGameServerUrl  : site?.netentStaticContentUrl,
                gameServerUrl        : site?.netentGameServerUrl,
                gameId               : params?.game,
                lobbyUrl             : site?.url,
                realityCheckLimit    : player?.realityCheckLimit,
                isRealityCheckEnabled: isRealityCheckEnabled,
                historyUrl           : site?.historyUrl,
                realitycheckmessage1  : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.message1", ['%1', '%2'] as Object[]),
                realitycheckmessage2       : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.message2", null),
                continueButtonText       : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.continue", null),
                leaveButtonText : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.leave",null),
                timeText          : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.time", null),
                durationText  : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.duration", ['%1', '%2'] as Object[]),
                minutesText       : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.duration.minutes", null),
                gameHistoryButtonText : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.game.history",null),
                lobbyText          : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck.lobby", null),
                realitycheckText  : i18NService.getI18nMessage(gameLanguage,"netent.realitycheck",null)
        ])
        return
    }

    /**
     * method will be used to show reality check for QUICKFIRE games.
     * @param
     * @return
     */
    def quickfireRealityCheck() {
        log.info("RealityCheck in quickfire using redirect")
        String token = g.cookie(name: 'SessionCorrelationId')
        Session session = sessionService.getSession(token)
        if (session == null || !sessionService.isActiveSession(session)) {
            renderGameErrorPage((session != null ? session?.player?.site?.url : null), "Invalid session or session has expired.")
            return
        }
        RGS rgs = RGS.findByName("QUICKFIRE_RGS")
        boolean isRealityCheckEnabled = (null != rgs) ? rgs.isRealitycheckEnabled : false
        //String mobileInterfaceUrl = paramService.getString("quickfire.mobileinterface.api")
        //String mobileInterfaceUrl = "https://webserver9-efe1.installprogram.eu/MobileWebGames/js/InterfaceApi/InterfaceApi.js"
        render(view: "quickfireRealityCheck", model: [
                realityCheckLimit    : session?.player?.realityCheckLimit,
                isRealityCheckEnabled: isRealityCheckEnabled,
                historyUrl           : session?.player?.site.historyUrl,
                mobileInterfaceUrl   : paramService.getString("quickfire.mobileinterface.api"),
                gameRcUrlDesktop     : paramService.getString("quickfire.game.rc.url.desktop")
        ])
        return
    }

    /**
     * method will be used to launch netent table game.
     * @param
     * @return
     */
    def nektanRGSSession() {
        log.debug "Launch NEKTAN TABLE GAME"
        String gameServerUrl = ""

        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            renderGameErrorPage((session != null ? session?.player?.site?.url : null), "Invalid session or session has expired.")
            return
        }

        def payload = (JSONObject) request.JSON

        if (payload != null && payload.gameTag != null) {
            def gameTagWithoutAccountSystem = (payload.gameTag - (session.site.shortName - "-CASINO")).substring(1)
            log.info("gameTagWithoutAccountSystem in nektanRGSSession: ${gameTagWithoutAccountSystem}")
            RGS nektanRGS = RGS.findByName("NEKTAN_RGS");
            if (null == nektanRGS) {
                renderGameErrorPage(site?.url, "Game not available.")
                return
            }
            Game game = Game.findByShortNameAndRgs(gameTagWithoutAccountSystem, nektanRGS)
            if (null == game || null == game.rgs || game.rgs != nektanRGS) {
                renderGameErrorPage(session.player.site?.url, "Game not available.")
                return
            }
            if (game.rgs.countries != null && !game.rgs.countries.isEmpty() && !game.rgs.countries.contains(session.player.country)) {
                renderGameErrorPage(session.player.site?.url, "Invalid player country.")
                return
            }
        }

       // if (session) {
            def gameSessionResult = gameSessionService.authenticatePlayerWithToken(session?.token, null, "desk", false, true)
            gameServerUrl =
                    request.scheme + "://" + request.serverName + ":" + request.serverPort +
                            "/gameserver/games/session?" +
                            "&externalAccountSystemTag=${session.site.shortName}" +
                            "&externalAccountSystemSessionId=${gameSessionResult?.gameSession?.token}" +
                            "&" + (request.getQueryString() != null ? request.getQueryString() : "")


            if (session?.player?.realityCheckLimit != null) {
                gameServerUrl += "&jurisdiction=uk"
                gameServerUrl += "&realitycheck_uk_elapsed=0"
                gameServerUrl += "&realitycheck_uk_limit=${session?.player?.realityCheckLimit}"
                gameServerUrl += "&realitycheck_uk_history=${session?.player?.site?.historyUrl?.encodeURL()}"
                gameServerUrl += "&realitycheck_uk_exit=${session?.player?.site?.url?.encodeURL()}"
                gameServerUrl += "&realitycheck_uk_proceed="
            }

            log.debug("Redirect to: ${gameServerUrl}")

            redirect(url: gameServerUrl)
            return
        /*} else {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }*/

        // Old code from Evolve 1 Nektan Game Controller:
//		UriComponentsBuilder redirectUrl = UriComponentsBuilder
//				.fromHttpUrl(httpServletRequest.getRequestURL().toString())
//				.replacePath("/gameserver/games/session")
//				.query(httpServletRequest.getQueryString())
//				.queryParam("externalAccountSystemTag", accountSystemTag)
//				.queryParam("externalAccountSystemSessionId", shortLivedSessionId);
//		return "redirect:" + redirectUrl.build().toString();

    }

    /**
     * method will be used create netent game session.
     * @param playerId
     * @param currencyIso3
     * @param isMobile
     * @return
     */
    def createNetEntSession(Long playerId, String currencyIso3, boolean isMobile) {

        def client = getSoapClient()

        try {
            def result
            if (isMobile) {
                log.info("creating netent session for mobile")
                result = client.send(SOAPAction: '') {
                    envelopeAttributes('xmlns:api': 'http://casinomodule.com/api')
                    body {
                        'api:loginUserDetailed' {
                            'merchantId'(paramService.getString("netent.api.merchant.id"))
                            'merchantPassword'(paramService.getPassword("netent.api.merchant.password"))
                            'currencyISOCode'(currencyIso3)
                            'userName'(playerId)
                            'extra'('Channel')
                            'extra'('mobg')
                        }
                    }
                }
            } else {
                log.info("creating netent session for desktop")
                result = client.send(SOAPAction: '') {
                    envelopeAttributes('xmlns:api': 'http://casinomodule.com/api')
                    body {
                        'api:loginUserDetailed' {
                            'merchantId'(paramService.getString("netent.api.merchant.id"))
                            'merchantPassword'(paramService.getPassword("netent.api.merchant.password"))
                            'currencyISOCode'(currencyIso3)
                            'userName'(playerId)
                        }
                    }
                }
            }

            log.info("Successfully received netent session: " + result.body)
            return [
                    returnCode: APIReturnCode.OK,
                    data      : result.body
            ]

        } catch (Exception e) {
            log.error "Error creating netent session [ ERROR: " + e.getMessage() + "]"
            return [
                    returnCode: APIReturnCode.ERROR,
                    data      : null
            ]
        }
    }

    /**
     * method will be used to build evolution launch url.
     * @param isDemoGame
     * @param site
     * @param game
     * @param session
     * @param currency
     * @param isMobile
     * @return
     */
    private GameServerResponse buildEvolutionLaunchURL(boolean isDemoGame, Site site, Game game, Session session, Currency currency, boolean isMobile) {

        String gameSessionToken = null;
        String gameLaunchURL = null;
        EvolutionSessionResponse evolutionSessionResponse = null;
        String hostName = null;
        String evolutionToken = null;
        if (sessionService.isActiveSession(session.token)) {
            def gameSessionResult = gameSessionService.authenticatePlayerWithToken(session.token, null, "desk", false, false)
            if (gameSessionResult == null || gameSessionResult.returnCode != APIReturnCode.OK || gameSessionResult.gameSession == null) {
                return  prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,"Oops Something went Wrong!"));
            }
            GameSession gameSession = gameSessionResult.gameSession;
            //hostName = paramService.getString("evolution.gameserver.hostname");
            //As evolution host domain is different for each site, this should be configured at site level. Casino key and API token can be taken from parameters
            hostName = paramService.getString("evolution.gameserver.hostname");
            if(StringUtils.isEmpty(hostName)){
                return  prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,"Game not available."));
            }
            if(StringUtils.isEmpty(hostName)){
                log.info("Evolution game server URL not configured for site: "+site.shortName);
                return prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,"Oops Something went Wrong!"));
            }
            evolutionSessionResponse = createEvolutionSession(session, currency.iso, isMobile, game, hostName, gameSession?.token)
            log.info("evolution session response : "+evolutionSessionResponse);
            if(evolutionSessionResponse.getErrors() == null){
                evolutionToken = StringUtils.substringBetween(evolutionSessionResponse.getEntry(),"/entry?params=", "&JSESSIONID=");
                gameSession = gameSessionResult.gameSession
                gameSession.externalSessionId = evolutionToken
                gameSession.save(failOnError: true, flush: true)
            }else {
                return prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,"Oops Something went Wrong!"));
            }
            if (null == evolutionToken) {
                return prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,"Oops Something went Wrong!"));
            }
            //gameLaunchURL = hostName + evolutionSessionResponse.getEntry();
        }
        /*if (null == gameLaunchURL) {
            return gameLaunchURL;
        }*/
        String redirectForEvolution = null;
        String evolutionRedirectUrl = null;
        if(!isMobile){
            evolutionRedirectUrl = paramService.getString("evolution.redirect.url");
            if(StringUtils.isEmpty(evolutionRedirectUrl)){
                return prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,"Oops Something went Wrong!"));
            }
            redirectForEvolution = evolutionRedirectUrl+"/revolve/api/accountsystem/launch/evolution?entry="+URLEncoder.encode(evolutionSessionResponse?.getEntry());
        }else{
            evolutionRedirectUrl = Param.findByParamKey("evolution.gameserver.hostname")?.val;
            if(StringUtils.isEmpty(evolutionRedirectUrl)){
                return prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,"Oops Something went Wrong!"));
            }
            redirectForEvolution = evolutionRedirectUrl + evolutionSessionResponse.getEntry()
        }
        log.info("redirect url: " + redirectForEvolution);
        /*redirect(url: redirectForEvolution);
        return;*/
        return  prepareRedirectResponse(redirectForEvolution);
    }

    /**
     * method will be used to create evolution session.
     * @param session
     * @param currencyIso3
     * @param isMobile
     * @param game
     * @param evolutionGSURL
     * @param gameSessionToken
     * @return
     */
    def createEvolutionSession(Session session, String currencyIso3, boolean isMobile, Game game, String evolutionGSURL, String gameSessionToken) {
        try {
            Player player = session?.player
                    EvolutionSessionRequest evolutionSessionRequest = prepareEvolutionRequest(player, session, currencyIso3, isMobile, game, gameSessionToken);
            EvolutionSessionResponse evolutionSessionResponse = evolutionSessionRequest.validate();
            if(evolutionSessionResponse!=null && evolutionSessionResponse.getErrors() !=null){
                return evolutionSessionResponse
            }else {
                ObjectMapper mapper = new ObjectMapper();
                //Enabling the indent out put
                mapper.enable(SerializationFeature.INDENT_OUTPUT);
                //Enabling null check to avoid the null parameters in the json string
                mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
                String jsonStr = mapper.writeValueAsString(evolutionSessionRequest);
                log.info("Evolution session JSON Request : " + jsonStr)
                String casinoKey = paramService.getString('evolution.casino.key');
                String apiToken = paramService.getString('evolution.api.tken');
                evolutionGSURL = evolutionGSURL + '/ua/v1/' + casinoKey + '/' + apiToken;
                //Getting the configured external system connection time out value
                Integer connectionTimeout = paramService.getInt('evolution.sessioncreate.connectiontimeout');
                //Getting the configured external system read time out value
                Integer readTimeout = paramService.getInt('evolution.sessioncreate.readtimeout');
                RestBuilder restBuilder = new RestBuilder(connectTimeout: connectionTimeout != null ? connectionTimeout.intValue() : 3000, readTimeout: readTimeout != null ? readTimeout.intValue() : 3000, proxy: null)
                RestResponse restResponse = restBuilder.post(evolutionGSURL) {
                    accept JSONObject, 'application/json'
                    json(jsonStr)
                }

                log.info("Response from evolution system for create session : "+restResponse?.body);
                if (restResponse != null) {
                    //converting the json response to ebo response object
                    return convertJsonToObject(restResponse.json)
                } else {
                    //Returns ebo system error when response has not come
                    log.info("Error response from Evolution System :" + restResponse);
                    return prepareErrorResponse(ReturnCodes.Code.ERROR);
                }
            }
        } catch (Exception e) {
            log.error "Error creating evolution session [ ERROR: " + e.getMessage() + "]"
            return prepareErrorResponse(ReturnCodes.Code.ERROR);
        }
    }

    /**
     * method will be used to get SOAPClient for netent.
     * @param
     * @return
     */
    @NotTransactional
    SOAPClient getSoapClient() {
        String SOAPEndpoint = paramService.getString("netent.api.casinomodule.endpoint") + "/ws-jaxws/services/casino"
        //String SOAPEndpoint = "https://nektan-api-test.casinomodule.com/ws-jaxws/services/casino"
        SOAPClient client = new SOAPClient(SOAPEndpoint)
        return client
    }

    /**
     * method will be used to identify the game launch done by mobile or not.
     * @param
     * @return
     */
    private boolean isMobile() {
        String reqAgent = request.getHeader("User-Agent")
        String patternString = "/Mobile|iP(hone|od|ad)|Android|BlackBerry|IEMobile|Kindle|NetFront|Silk-Accelerated|(hpw|web)OS|Fennec|Minimo|Opera M(obi|ini)|Blazer|Dolfin|Dolphin|Skyfire|Zune/"

        Pattern pattern = Pattern.compile(patternString);

        Matcher matcher = pattern.matcher(reqAgent);

        if (matcher.find())
            return true
        else
            return false

    }

    /**
     * uuid to preparing the ebo request based on the gaming transaction type
     * @param gamingRequest
     * @param gameSession
     * @param wagerTxnDetailsDTO
     * @param winTxnDetailsDTO
     * @param methodType
     * @return
     */
    private EvolutionSessionRequest prepareEvolutionRequest(Player player, Session session, String currencyIso3, boolean isMobile, Game game, String gameSessionToken) {
        EvolutionSessionRequest evolutionSessionRequest = new EvolutionSessionRequest(UUID.randomUUID().toString());
        EvolutionPlayer evolutionPlayer = new EvolutionPlayer();
        EvolutionSession playerSession = new EvolutionSession();

        ChannelDetails channelDetails = new ChannelDetails();
        SessionConfig config = new SessionConfig();
        PlayerBrand playerBrand = new PlayerBrand();
        Urls urls = new Urls();
        //Setting url's
        Site site = player.getSite();
        urls.setCashier(site.getDepositUrl());
        urls.setLobby(site.getUrl());
        //urls.setSessionTimeout(site.getUrl());
        /*urls.setSessionTimeout();
        urls.setGameHistory();
        urls.setResponsibleGaming();*/
        // Setting channel details
        channelDetails.setWrapped(false);
        channelDetails.setMobile(isMobile);

        //Commenting this for now, as these are non mandatory in game launch
        /*

        // Setting game details
        gameDetails.setCategory(game.getCategory().getShortName());
        // Using view2 for classic view, but needs to be changed as it may have different values based on the game table config.
        gameDetails.setGameInterface("view2");
        */
        GameDetails gameDetails = new GameDetails();
        TableDetails tableDetails = new TableDetails();
        // Setting table details, for now getting it from the game params
        /*if (game.params != null) {
            def paramsMap = grails.converters.JSON.parse(game.params)
            if (paramsMap.tableId != null) {
                tableDetails.setId(paramsMap.tableId)
            }
        }*/
        // Setting table details, for now getting it from the game params
        if (game.params != null) {
            def paramsMap = grails.converters.JSON.parse(game.params)
            if (paramsMap.gameCategory != null) {
                gameDetails.setCategory(paramsMap.gameCategory);
            }

            if (paramsMap.virtualtableId != null) {
                tableDetails.setId(paramsMap.virtualtableId)
                gameDetails.setTable(tableDetails);
            }
        }
        // Setting player session details
        playerSession.setId(gameSessionToken); // Using game session token, as we are getting same token as sid in wallet API's
        //playerSession.setIp(session.getIpAddress());
        playerSession.setIp("1.1.1.1");
        //Getting the brand details from param table - id and skin.
        playerBrand.setId(paramService.getString("evolution.integration.brand.id"));
        playerBrand.setSkin(paramService.getString("evolution.integration.skin.code"));

        evolutionPlayer.setId(player.getId().toString());
        evolutionPlayer.setUpdate(true);
        evolutionPlayer.setFirstName(player.getFirstName());
        evolutionPlayer.setLastName(player.getLastName());
        evolutionPlayer.setCountry(player.getCountry().getIso2());
        evolutionPlayer.setLanguage(session.getSite().getLang());
        evolutionPlayer.setCurrency(currencyIso3);
        evolutionPlayer.setSession(playerSession);

        config.setBrand(playerBrand);
        config.setChannel(channelDetails);
        config.setGame(gameDetails);
        config.setUrls(urls);
        evolutionSessionRequest.setPlayer(evolutionPlayer);
        evolutionSessionRequest.setConfig(config);
        return evolutionSessionRequest;

    }

    /**
     * method to convert ebo json response to ebo response object
     * @param jsonObject
     * @return
     */
    private EvolutionSessionResponse convertJsonToObject(JSONObject jsonObject){

        EvolutionSessionResponse evolutionSessionResponse = null
        try {
            //Initializing the object mapper class
            ObjectMapper mapper = new ObjectMapper();
            //checking the success response contains or not in the json response
            if (jsonObject!=null) {
                if (jsonObject.has("errors")){
                   if (jsonObject.get("errors") instanceof String) {
                        log.info("Error response from Evolution System :" + jsonObject)
                        evolutionSessionResponse = prepareErrorResponse(ReturnCodes.Code.EVOLUTION_URL_INVALID)
                    } else {
                        evolutionSessionResponse = mapper.readValue(jsonObject.toString(), EvolutionSessionResponse.class);
                    }
                }else{
                    evolutionSessionResponse = mapper.readValue(jsonObject.toString(), EvolutionSessionResponse.class);
                }
            }else{
                log.info("Error response from evolution System :"+jsonObject)
                evolutionSessionResponse = prepareErrorResponse(ReturnCodes.Code.ERROR)
            }
        }catch (Exception e){
            // e.printStackTrace()
            log.error("Exception occurred while converting session create-json response - EvolutionSessionResponse: "+jsonObject + " Exception: " + e.getMessage())
            return prepareErrorResponse(ReturnCodes.Code.ERROR)
        }
        return evolutionSessionResponse;
    }

    /**
     * method to prepare error response for evolution game launch
     * @param jsonObject
     * @return
     */
    private EvolutionSessionResponse prepareErrorResponse(ReturnCodes.Code errorCode) {
        EvolutionSessionResponse evolutionSessionResponse = new EvolutionSessionResponse()
        List<EvolutionSessionError> errorLst = new ArrayList<EvolutionSessionError>();
        errorLst.add(new EvolutionSessionError(errorCode.value()?.toString(),errorCode.description()));
        evolutionSessionResponse.setErrors(errorLst)
        return evolutionSessionResponse;
    }

    /**
     * method will be used to build red tiger launch url.
     * @param isDemoGame
     * @param site
     * @param game
     * @param session
     * @return
     */
    private GameServerResponse buildRedTigerLaunchURL(boolean isDemoGame, Site site, Game game, Session session) {

        String gameLaunchURL = paramService.getString("redtiger.gameServer.url")
        if(StringUtils.isEmpty(gameLaunchURL)){
            log.info("Redtiger game server URL not configured.");
            return prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,"Oops Something went Wrong!"));
        }
        if (isDemoGame) {
            gameLaunchURL = gameLaunchURL +
                    "${game.externalId}" +
                    "?playMode=demo" +
                    "&language=en"
        } else {
            boolean isRealityCheckEnabled = false;
            RGS rgs = game?.rgs
            if (rgs != null) {
                isRealityCheckEnabled = rgs?.isRealitycheckEnabled
            }
            def gameSessionResult = gameSessionService.authenticatePlayerWithToken(session.token, null, "desk", false, false, game)
            if (gameSessionResult == null || gameSessionResult.returnCode != APIReturnCode.OK || gameSessionResult.gameSession == null) {
                return prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,"Oops Something went Wrong!"));
            }
            gameLaunchURL = gameLaunchURL +
                    "${game.externalId}" +
                    "?token=${gameSessionResult.gameSession.token}" +
                    "&playMode=real" +
                    "&language=en"

            if (isRealityCheckEnabled && session?.player?.realityCheckLimit != null) {
                gameLaunchURL += "&realityCheckMinutes=${session?.player?.realityCheckLimit}"
                gameLaunchURL += "&realityCheckLobbyUrl=${site?.url?.encodeURL()}"
                gameLaunchURL += "&realityCheckHistoryUrl=${site?.historyUrl?.encodeURL()}"
            }
        }
        gameLaunchURL += "&lobbyURL=${site?.url?.encodeURL()}"
        return  prepareRedirectResponse(gameLaunchURL)
    }

    /**
     *
     * @param isDemoGame
     * @param site
     * @param game
     * @param session
     * @return
     */
    private GameServerResponse buildEliteGameLaunchURL(boolean isDemoGame, Site site, Game game, Session session, boolean isMobile, String language){

        String eliteGameLaunchURL = siteService.getInheritedValue(site,"eliteGameLaunchUrl")
        String eliteAuthKey = siteService.getInheritedValue(site,"eliteAuthorizationKey")
        String eliteSiteId= paramService.getString("elite.site.id");
        if (StringUtils.isBlank(eliteGameLaunchURL) || StringUtils.isBlank(eliteAuthKey) || StringUtils.isBlank
                (eliteSiteId)) {
            log.info("Invalid elite game launch URL or Authorization Key configured");
            return prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,"Invalid elite game launch URL or Authorization key configured"))
        }

        Player player = session?.player;
        String gameSessionToken = null;
        eliteGameLaunchURL += "?"  + "playMode=${isDemoGame == true ? "D" : "R"}" +
                "&gameId=${game?.externalId}" +
                "&platform=${isMobile ? "M" : "W"}" +
                "&skinCode=${eliteSiteId}" +
                "&subSkinCode=${site?.shortName}" +
                "&language=${StringUtils.isEmpty(language)? site.lang != null ? site.lang : "en" : language}"+
                "&lobbyUrl=${site?.url?.encodeURL()}" +
                "&depositUrl=${site?.depositUrl?.encodeURL()}" +
                "&historyUrl=${site?.historyUrl?.encodeURL()}";
        if(!isDemoGame){
            String platform = isMobile ? "mob" : "desk"
            def gameSessionResult = gameSessionService.authenticatePlayerWithToken(session.token, null, platform, false, false, game)
            if (gameSessionResult == null || gameSessionResult.returnCode != APIReturnCode.OK || gameSessionResult.gameSession == null) {
                log.info("Game Session creation failed in evolve")
                return prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,"Oops Something went Wrong!"))
            }
            gameSessionToken = gameSessionResult.gameSession.token
            eliteGameLaunchURL += "&username=${"NK-"+ player?.id}" +
                    "&sessionToken=${gameSessionToken}" +
                    "&country=${player?.country?.iso3}" +
                    "&currency=${player?.currency?.iso}";


            boolean isRealityCheckEnabled = false;
            RGS rgs = game?.rgs
            if (rgs != null) {
                isRealityCheckEnabled = rgs?.isRealitycheckEnabled
            }
            if(isRealityCheckEnabled && session?.player?.realityCheckLimit != null) {
            eliteGameLaunchURL += "&jurisdiction=${"uk"}" +
                        "&sessionElapsed=${0}" +
                        "&sessionLimit=${session?.player?.realityCheckLimit}" +
                        "&realitycheck_uk_proceed=${true}";
            }
        }

        try{
            log.info("Calling elite system with url  " +eliteGameLaunchURL);
            //Call Elite system to get actual game launch url
            Integer eliteConnectionTimeout = paramService.getInt('elite.connectiontimeout') !=null ? paramService.getInt('elite.connectiontimeout') : 3000;
            Integer eliteReadTimeout = paramService.getInt('elite.readtimeout')!=null ? paramService.getInt('elite.readtimeout'): 3000 ;
            RequestConfig requestConfig = RequestConfig.custom()
                    .setConnectTimeout(eliteConnectionTimeout.intValue())
                    .setConnectionRequestTimeout(eliteConnectionTimeout.intValue())
                    .setSocketTimeout(eliteReadTimeout.intValue()).build();
            HttpClient httpClient = HttpClientBuilder.create().disableRedirectHandling().setDefaultRequestConfig(requestConfig).build();
            HttpGet getMethod = new HttpGet(eliteGameLaunchURL)
            getMethod.setHeader(HttpHeaders.USER_AGENT, request.getHeader(HttpHeaders.USER_AGENT));
            HttpResponse response = httpClient.execute(getMethod)

            if(response.getStatusLine().statusCode == HttpStatus.FOUND.value()){
                log.info("Response 302 redirect response from elite system is " + response);
                String redirectUrl = response?.getFirstHeader("Location")?.getValue();
                return prepareRedirectResponse(redirectUrl);
            }else{
                switch(response.getStatusLine().statusCode){
                    default :
                        String content = EntityUtils.toString(response.getEntity());
                        log.info("ELITE GAME LAUNCH FAILED "+content);
                        return prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,content))
                }
            }
            //Apart from 302 and 400
            log.info("Response received from elite system is " + response);
        }catch(IOException _ioExp){
            log.error("IO Exception occurred while connecting to elite, could not connect to elite " + _ioExp.getMessage());
            gameSessionService.reactivateGameSession(gameSessionToken)
            return prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,"Oops Something went Wrong!"))
        }catch(Exception exp){
            log.error("Exception occurred while connecting to elite, could not connect to elite " +exp.getMessage());
            gameSessionService.reactivateGameSession(gameSessionToken)
            return prepareRenderResponse("gameErrorPage", prepareGameErrorPageModel(site?.url,"Oops Something went Wrong!"))
        }
    }

    private GameServerResponse prepareRedirectResponse(String redirectUrl){
        GameServerResponse gameServerResponse = new GameServerResponse(true,redirectUrl);
        return gameServerResponse
    }

    private GameServerResponse prepareRenderResponse(String renderView, Object renderModel){

        if(renderModel instanceof GameErrorPageModel){
            return prepareGameErrorPageResponse(renderView,renderModel);
        }

        return null;
    }

    private GameServerResponse prepareGameErrorPageResponse(String renderView, GameErrorPageModel gameErrorPageModel){
        GameServerResponse gameServerResponse = new GameServerResponse(true,renderView,gameErrorPageModel);
        return gameServerResponse
    }

    private GameErrorPageModel prepareGameErrorPageModel(String lobbyUrl, String errorMessage){
        GameErrorPageModel gameErrorPageModel = new GameErrorPageModel(lobbyUrl,errorMessage);
        return gameErrorPageModel
    }

    private renderGameErrorPage(String lobbyUrl,String errorMessage){
        GameServerResponse response = prepareRenderResponse("gameErrorPage",new GameErrorPageModel(lobbyUrl,errorMessage))
        render(view:response.getRenderView(), model:[gameErrorPageInstance:response.getRenderModel()])
        return
    }

    /**
     * validates language is not empty and consists of only 2 characters.
     * @param language
     * @return
     */
    private boolean isValidLanguage(String language){
        boolean isValid=false;
        if((!StringUtils.isEmpty(language)) && language.length()==2){
            isValid =true
        }
        return isValid;
    }
}
