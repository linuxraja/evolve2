package com.nektan.revolve.backoffice

import com.nektan.revolve.coreservices.Game
import grails.plugin.springsecurity.annotation.Secured

@Secured(['ROLE_PERMISSION_SYSTEM_EDIT'])
class GameController {

    def scaffold = Game
}
