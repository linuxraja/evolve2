package com.nektan.revolve.backoffice

import com.nektan.revolve.coreservices.PlayerPropertyWeightageConfig
import org.springframework.security.access.annotation.Secured

/**
 * Created by Veerendranath on 9/9/2016.
 */

@Secured('ROLE_PERMISSION_PLAYER_PROPERTY_WEIGHTAGE_CONFIG_VIEW')
class PlayerPropertyWeightageConfigController {
    //def scaffold = PlayerPropertyWeightageConfig
    // static allowedMethods = [edit: "POST", update: "PUT"]
    def playerPropertyWeightageConfigService
    def springSecurityService

    def index() {
        render(view: "index", model: [playerPropertyWeightageConfigLst: playerPropertyWeightageConfigService.search(params)])
    }


    /*@Secured('ROLE_PERMISSION_PLAYER_PROPERTY_WEIGHTAGE_CONFIG_EDIT')
    def edit(){
        render(view: "edit", model: [playerPropertyWeightageConfigLst: PlayerPropertyWeightageConfig.list()])
    }*/


    /*@Secured('ROLE_PERMISSION_PLAYER_PROPERTY_WEIGHTAGE_CONFIG_EDIT')
    def update(){
        *//**
         * Commented below code for, Not to update the Property Weightages by the User. And we will redirect to the view screen.
        Map result = playerPropertyWeightageConfigService.update(params)
        if (result.containsKey("errorMsg")){
            flash.message = message(code: result.get("errorMsg"), args: [])
            render(view:'edit', model:[playerPropertyWeightageConfigLst: PlayerPropertyWeightageConfig.list()])
            return
        } else {
            flash.message="Player Property Weightage updated."
            redirect(action: 'index')
        }*//*
        render(view: "index", model: [playerPropertyWeightageConfigLst: playerPropertyWeightageConfigService.search(params)])
    }*/



}
