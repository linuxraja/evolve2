package com.nektan.revolve.api.v1

import com.nektan.revolve.api.ReturnCodes
import com.nektan.revolve.coreservices.Player
import com.nektan.revolve.coreservices.Session
import com.nektan.revolve.services.AccountService
import com.nektan.revolve.services.GameSessionService
import com.nektan.revolve.services.SessionService
import com.nektan.revolve.sightline.W2gRecord
import com.nektan.revolve.sightline.W2gRecordService
import grails.converters.JSON
import grails.plugin.springsecurity.annotation.Secured

@Secured(['permitAll'])
class SessionController extends ApiController{

    static namespace = 'v1'

    SessionService sessionService
    AccountService accountService
    W2gRecordService w2gRecordService


    static allowedMethods = [
            authenticatePlayer: "POST",
            createSession:"POST",
            closeSession: "POST"]



    /**
     * Authenticate the player and create a session.
     * Params:
     * username:"Testuser"
     * password:"test"
     * site:"root"
     * platform:"mob"
     *
     */
    def authenticatePlayer()  {
        try {
            def payload = request.JSON
            def tsandcsAccepted

            // Check params are all there.
            String[] requiredParams = ["username", "password", "site", "platform"]
            String paramError = checkParams(payload, requiredParams)
            if (paramError != null) {
                renderError(ReturnCodes.Code.INVALID_PARAMS, paramError)
                return
            }

            tsandcsAccepted = (payload.tsandcsAccepted !=null ? payload.tsandcsAccepted : false)

//            def result = sessionService.authenticatePlayerWithGameSession(
            def result = sessionService.authenticatePlayer(
                    payload.username,
                    payload.password,
                    getIp(request),
                    payload.platform,
                    payload.site,
                    payload?.deviceId,
                    payload?.appVersion,
                    tsandcsAccepted
            )



            if (result.returnCode == ReturnCodes.Code.OK) {

                BigDecimal playableBalance = w2gRecordService.getPlayableBalanceForUS(result.player)

                render(status: 200, contentType: 'application/json') {
                    [
                            'result'     : result.returnCode.value(),
                            'description': "Player ${payload.username} successfully authenticated and session created.",
                            'username'   : result.player.userName,
                            'id'         : result.player.id,
                            'token'      : result.token,
                            'isPasswordOneShot' : result.player.isPasswordOneshot,
                            'accounts'   : result.player.accounts,
                            'playableBalance' : playableBalance
                    ]
                }
                return
            } else {
                renderError(result.returnCode, result?.errors?.toString())
                return
            }
        } catch (Exception e) {
            log.error("Caught Exception in SessionController.authenticatePlayer()", e)
            renderError(ReturnCodes.Code.ERROR, e.toString())
        }
    }

    /**
     * @param token
     * @param reason "Closed" "Killed"
     * Kill the session identified by the token
     */
    def closeSession() {
        try {
            def payload = request.JSON

            if (payload.token == null || payload.reason == null ) {
                renderError(ReturnCodes.Code.INVALID_PARAMS, "Token or reason missing")
                return
            }
			int reason = Session.STATUS_DESCRIPTION.find { key, value -> value == payload.reason }.key

            def result = sessionService.closeSession(payload.token, reason, payload.description)

            if (result.returnCode == ReturnCodes.Code.OK ) {

                Session session = Session.findByToken(payload.token)
                Player player = session.player

                response.contentType = "application/json"
//                java.util.List accounts = []
//                player.accounts.each {item->
//                    accounts.push(item.toMap() )
//                }

                BigDecimal balance = w2gRecordService.getPlayableBalanceForUS(session.player)

               def returnMap = [result:0, accounts:player.accounts, playableBalance: balance]
               render returnMap as JSON
               return

            }  else {
                renderError(result.returnCode, result.errors)
                return
            }

        } catch (Exception e) {
            log.error("Caught Exception in SessionController.closeSession()", e)
            renderError(ReturnCodes.Code.ERROR, e.toString())
        }
    }
}
