package com.nektan.revolve.api.evolve1

import com.nektan.revolve.api.APIReturnCode
import com.nektan.revolve.api.v1.ApiController
import com.nektan.revolve.services.ParamService
import wslite.soap.SOAPClient
import com.nektan.revolve.services.SessionService
import com.nektan.revolve.coreservices.Session
import grails.plugin.springsecurity.annotation.Secured

@Secured(['permitAll'])
class NetEntBonusController extends ApiController {
	
	ParamService paramService
	SessionService sessionService
	static namespace = 'evolve1'
	def client
	static allowedMethods = [
			netentEndpoint: 'GET'
	]

	def netentEndpoint() {
		String sessionId = params.sessionid
		Session session = getEvolvePlayerSession()
		log.info("NetEntController : netentEndpoint : sessionId : ${session?.playerId}")
		if (session == null || !session.isActive()) {
			createErrorResponse(APIReturnCode.INVALID_SESSION)
			return
		}

		//Session session = sessionService.getSession(sessionId)
		Long playerId = session?.player?.id
		if(playerId == null || playerId.equals("")){
			createErrorResponse(APIReturnCode.INVALID_PLAYER)
			return
		}
		
		String SOAPclient = paramService.getString("netent.admin.wsdl.url")
		if(SOAPclient == null || SOAPclient.equals("")){
			createErrorResponse(APIReturnCode.INVALID_ENDPOINT_URL)
			return
		}
		client = new SOAPClient(SOAPclient)
		try{
			def response = client.send(SOAPAction: ''){
				envelopeAttributes ('xmlns:api' : 'http://casinomodule.com/api')
				body {
					'api:getUserBonusInfoDetailV5'{
						'userName'(playerId)
						'accountType'("SEAMLESS_WALLET")
						'merchantId'(paramService.getString("netent.api.merchant.id"))
						'merchantPassword'(paramService.getPassword("netent.api.merchant.password"))
					}
				}
			}
			log.info 'Response for Netent getNetentBonusInfo:'+response.httpResponse.statusCode
            if(response.httpResponse.statusCode != 200) {
				createErrorResponse(APIReturnCode.INVALID_RESPONSE_FOUND)
                return
            }
            def v5Response = new XmlSlurper().parseText(response.text)
			//log.info 'v5Response'+v5Response.Body.getUserBonusInfoDetailV5Response.getUserBonusInfoDetailV5Return.accountBalance
            def v5ResponseReturn = v5Response.Body.getUserBonusInfoDetailV5Response.getUserBonusInfoDetailV5Return

			def responseTemp = [
                    "accountBalance":[
                            "amount": "${v5ResponseReturn.accountBalance.amount}",
                            "amountCurrencyISOCode": "${v5ResponseReturn.accountBalance.amountCurrencyISOCode}"
                    ],
                    "bonusAvailable": "${v5ResponseReturn.bonusAvailable}",
                    "cashinWageredAmount":[
                            "amount": "${v5ResponseReturn.cashinWageredAmount.amount}",
                            "amountCurrencyISOCode": "${v5ResponseReturn.cashinWageredAmount.amountCurrencyISOCode}"
                    ],
                    "creditWageredAmount":[
                            "amount": "${v5ResponseReturn.creditWageredAmount.amount}",
                            "amountCurrencyISOCode": "${v5ResponseReturn.creditWageredAmount.amountCurrencyISOCode}"
                    ],
                    "creditWageredGameRounds": "${v5ResponseReturn.creditWageredGameRounds}",
                    "remainingCashinWageringAmount":[
                            "amount": "${v5ResponseReturn.remainingCashinWageringAmount.amount}",
                            "amountCurrencyISOCode": "${v5ResponseReturn.remainingCashinWageringAmount.amountCurrencyISOCode}"
                    ],
                    "remainingCreditWageringAmount":[
                            "amount": "${v5ResponseReturn.remainingCreditWageringAmount.amount}",
                            "amountCurrencyISOCode": "${v5ResponseReturn.remainingCreditWageringAmount.amountCurrencyISOCode}"
                    ],
                    "remainingCreditWageringGameRounds": "${v5ResponseReturn.remainingCreditWageringGameRounds}",
                    "reservationBalance":[
                            "amount": "${v5ResponseReturn.reservationBalance.amount}",
                            "amountCurrencyISOCode": "${v5ResponseReturn.reservationBalance.amountCurrencyISOCode}"
                    ],
                    "totalBonus":[
                            "amount": "${v5ResponseReturn.totalBonus.amount}",
                            "amountCurrencyISOCode": "${v5ResponseReturn.totalBonus.amountCurrencyISOCode}"
                    ],
                    "totalCash":[
                            "amount": "${v5ResponseReturn.totalCash.amount}",
                            "amountCurrencyISOCode": "${v5ResponseReturn.totalCash.amountCurrencyISOCode}"
                    ],
                    "totalSecurity":[
                            "amount": "${v5ResponseReturn.totalSecurity.amount}",
                            "amountCurrencyISOCode": "${v5ResponseReturn.totalSecurity.amountCurrencyISOCode}"
                    ]
            ]
			log.info responseTemp
            render(status: 200, contentType: 'application/json') {
                responseTemp
            }
			return
		} catch (Exception e) {
			log.error "Unable to get user bonus info [ Cause: " + e.getMessage() + "]"
			createErrorResponse(APIReturnCode.ERROR)
			return
		}
	}
}
