package com.nektan.revolve.backoffice

import grails.plugin.springsecurity.annotation.Secured

@Secured('ROLE_PERMISSION_DASHBOARD_VIEW')
class DashboardController {

	def statisticsService
	int defaultNumberOfEntries = 6

    def index() {

	    int numberOfEntries = 0

	    if ( params.max ) {
		    numberOfEntries = params.int('max')
	    } else {
		    numberOfEntries = defaultNumberOfEntries
	    }

	    def loggedinusers = statisticsService.data.loggedinusers
	    def activeusers = statisticsService.data.activeusers
	    def gamesplayed = statisticsService.data.gamesplayed
	    def cashgames = statisticsService.data.cashgames
	    def deposits = statisticsService.data.deposits
	    def accountcreations = statisticsService.data.accountcreations

	    render ( view: "index", model: [
			    loggedinusers: unwrap( top( statisticsService.data.loggedinusers, numberOfEntries ) ),
			    activeusers: unwrap( top( statisticsService.data.activeusers, numberOfEntries ) ),
			    gamesplayed: unwrap( top( statisticsService.data.gamesplayed, numberOfEntries ) ),
			    cashgames: unwrap( top( statisticsService.data.cashgames, numberOfEntries) ),
			    deposits: unwrap( top( statisticsService.data.deposits, numberOfEntries) ),
			    accountcreations: unwrap( top( statisticsService.data.accountcreations, numberOfEntries) )
	    ])
    }


	private List unwrap(List listToUnwrap) {
		List<String> labels = []
		def data = []
		listToUnwrap.each { item ->
			labels << "'${item[0]}'"
			data << "'${item[1]}'"
		}
		return [ aggregate( labels ), aggregate( data ) ]
	}


	private List aggregate(List aListToFlatten) {
		List<String> values =[]

		if ( aListToFlatten.size() > 30 ) {

			values << aListToFlatten[0]

			int every = 0
			if ( aListToFlatten.size() >= 120 ) {
				every = 40
			} else if ( aListToFlatten.size() >= 60 ) {
				every = 20
			} else if ( aListToFlatten.size() >= 36 ) {
				every = 10
			}

			int idx = 0

			for ( int i = 0; i < aListToFlatten.size(); i++ ) {
				idx++
				if ( idx == every ) {
					values << "${aListToFlatten[ i ]}"
					idx = 0
				}
			}

			values << aListToFlatten[ aListToFlatten.size()-1 ]
			return values
		}
		return aListToFlatten
	}


	private List top(List aList, int numberOfEntries) {
		int start, end
		if ( numberOfEntries == null || numberOfEntries == 0) {
			numberOfEntries = defaultNumberOfEntries
		}

		if ( aList ) {
			if ( aList.size() <= numberOfEntries ) {
				start = 0
				end = aList.size()
			} else {
				start = aList.size() - numberOfEntries
				end = aList.size()
			}
			return aList.subList( start, end )
		}
		return aList
	}
}
