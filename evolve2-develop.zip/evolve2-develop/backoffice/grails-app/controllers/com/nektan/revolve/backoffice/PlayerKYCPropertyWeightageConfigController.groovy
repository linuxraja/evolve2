package com.nektan.revolve.backoffice

import com.nektan.revolve.coreservices.PlayerKYCPropertyWeightageConfig
import org.springframework.security.access.annotation.Secured

/**
 * Created by Khaja.Hussain on 07/30/2018.
 */

@Secured('ROLE_PERMISSION_PLAYER_KYC_PROPERTY_WEIGHTAGE_CONFIG_VIEW')
class PlayerKYCPropertyWeightageConfigController {
    //def scaffold = PlayerPropertyWeightageConfig
    // static allowedMethods = [edit: "POST", update: "PUT"]
    def playerKYCPropertyWeightageConfigService
    def springSecurityService

    def index() {
        render(view: "index", model: [playerKYCPropertyWeightageConfigLst: playerKYCPropertyWeightageConfigService.search(params)])
    }

}
