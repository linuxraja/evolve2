package com.nektan.revolve.api.v1

import com.nektan.revolve.api.ReturnCodes
import com.nektan.revolve.coreservices.SecurityQuestion
import com.nektan.revolve.services.ParamService
import grails.converters.JSON
import grails.plugin.springsecurity.annotation.Secured

@Secured(['permitAll'])
class SettingsController extends ApiController{

    static namespace = 'v1'

    ParamService paramService

    static allowedMethods = [
            getSecurityQuestions: 'POST',
            getSettings: 'POST'
    ]

    def getSettings() {

        try {
 //           def settings = paramService.getList('respin.settings')
            def settings = paramService.getList('rapid.setting')

            def returnMap = [result:0, settings:settings]
            render returnMap as JSON
            return
        } catch (Exception e) {
            log.error("Caught Exception in SettingsController.getSettings()", e)
            renderError(ReturnCodes.Code.ERROR, e.toString())
        }
    }

    def getSecurityQuestions() {

        try {
            def questions = SecurityQuestion.findAllByHidden(false)
            def returnMap = [result:0, questions:questions]
            render returnMap as JSON
            return
        } catch (Exception e) {
            log.error("Caught Exception in SettingsController.getSecurityQuestions()", e)
            renderError(ReturnCodes.Code.ERROR, e.toString())
        }

    } // getSecurityQuestions
} // class
