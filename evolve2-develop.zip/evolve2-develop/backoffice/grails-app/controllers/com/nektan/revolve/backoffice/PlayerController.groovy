/*
    Last change by $Author: Heiko Kanzler $
    Change date: $LastChangedDate: 2014-12-10 13:15:02 +0100 (Wed, 10 Dec 2014) $
    Version: $Rev: 36 $
*/
package com.nektan.revolve.backoffice

import com.nektan.evolve2.payments.epg.DepositPaymentMethodCountryCurrencyMapping
import com.nektan.revolve.api.DurationType
import com.nektan.revolve.coreservices.CardDetail
import com.nektan.revolve.coreservices.Country
import com.nektan.revolve.coreservices.Currency
import com.nektan.revolve.api.ReturnCodes
import com.nektan.revolve.coreservices.Document
import com.nektan.revolve.coreservices.MaxAmountDayMonth

import com.nektan.revolve.coreservices.Note
import com.nektan.revolve.coreservices.NoteType
import com.nektan.revolve.coreservices.Operator
import com.nektan.revolve.coreservices.PaymentMethod
import com.nektan.revolve.coreservices.PlayerBlockedCardDetails
import com.nektan.revolve.coreservices.PlayerExtra
import com.nektan.revolve.coreservices.PlayerStatus
import com.nektan.revolve.coreservices.PlayerWithdrawSettings
import com.nektan.revolve.coreservices.Site
import com.nektan.revolve.coreservices.Player
import com.nektan.revolve.coreservices.Transaction
import com.nektan.revolve.coreservices.TransactionSubtype
import com.nektan.revolve.coreservices.TransactionType
import com.nektan.revolve.dto.PlayerActivitySummaryDTO
import com.nektan.revolve.dto.NetworkPlayerDTO
import com.nektan.revolve.extras.CalendarUtility
import com.nektan.revolve.services.EventLogService
import grails.plugin.springsecurity.annotation.Secured
import groovy.sql.Sql
import org.apache.commons.lang.StringUtils
import pl.touk.excel.export.WebXlsxExporter

import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.regex.Matcher
import java.util.regex.Pattern


/*
* End points implemented to support player backoffice functionalities.
*/
@Secured('ROLE_PERMISSION_PLAYER_VIEW')
class PlayerController {

    def scaffold = Player
    def playerService
    def accountService
    def notesService
    def springSecurityService
    def paramService
    def operatorService
    def siteService
    def playerBonusService
    def playerFreeRoundsService
    def exportService
    def grailsApplication
    def dataSource
    def playerLoyaltyPointsService

    EventLogService eventLogService
    String ILLEGAL_ACCESS = "Illegal access. Unauthorized attempt to view or edit player"

    static mapExtensionFormat = ['pdf': 'pdf', 'xls': 'excel', 'csv': 'csv']
    /**
     * Redirects to "find" and shows the player search form
     * @return
     */
    def index() {
        redirect(action: 'find')
    }


    def beforeInterceptor = [action: this.&checkAuthorised, only: ['edit', 'update', 'summary', 'details', 'depositlimits', 'search']]

    private checkAuthorised() {

        Operator currentLoggedInUser = springSecurityService.getCurrentUser();
        Set<Site> sites = new HashSet<Site>()
        if (params.id) {
            Player player = playerService.findById(params.id)
            if (player != null) {
                sites.add(player.site)
            }
        }
        if (params.playerId) {
            Player player = playerService.findById(params.playerId)
            if (player != null) {
                sites.add(player.site)
            }
        }

//            if (params.site) {
//                sites.addAll(Site.findAllById(params.site))
//            }

        if (params.site?.class?.isArray()) {
            sites.addAll(Site.findAllById(params.site))
        } else {
            sites.addAll(Site.findAllById(params.site as Long))
        }

        Set<Site> operatingSites = new HashSet<Site>()
        List operatorSites = operatorService.operatingSites(currentLoggedInUser)
        operatingSites.addAll(operatorSites)

        if (!operatingSites.containsAll(sites)) {
            flash.message = ILLEGAL_ACCESS
            redirect(action: 'search')
            return false
        }
    }

/**
 * Show the player search form
 * @return
 */
    def find() {
        params.'max' = 20
        render(view: 'find', model: [entityName: "Player", params: params])
    }

    /**
     * Executes a search for player
     * @return
     */
    def search() {

        if (!params.site) {
            def sites = []
            operatorService.operatingSites().each() { Site site ->
                sites << "${site.id}"
            }
            params.site = sites
        }

        def results = playerService.find(params)
        if (results == null) {
            flash.message = message(code: "revolve.search.error.nousersfound", args: [params.playerId])
            render(view: "find", model: [params: params])
        } else {
            render(view: "find", model: [params: params, playersFound: results.getTotalCount(), playerInstanceList: results, playerInstanceCount: results.size()])
        }
    }


    /**
     * Search for players having same referrerTag.
     * @param referrerTag
     * @param playerId
     */
    def searchForReferrers() {
        def results = playerService.find(params)
        if (results.getTotalCount() == 0) {
            Player player = playerService.findById(params.id)
            flash.message = message(code: "revolve.search.error.nousersfound", args: [params.id])
            render(view: "tab_details", model: [params: params])
        } else {
            render(view: "find", model: [params: params, playersFound: results.getTotalCount(), playerInstanceList: results, playerInstanceCount: results.size()])
        }
    }

    /**
     * Initiate the editing of given player
     * @return
     */
    @Secured('ROLE_PERMISSION_PLAYER_EDIT')
    def edit() {
        def player = playerService.findById(Long.parseLong(params.id))
        render(view: 'edit', model: [playerInstance: player])
    }

    /**
     * Update the player with given properties.
     * @return
     */
    @Secured('ROLE_PERMISSION_PLAYER_EDIT')
    def update() {
        Player player = playerService.findById(params.id)

        boolean isAbuser = !player.isBonusAbuser && params.isBonusAbuser
        boolean isOptedOut = !player.bonusOptOut && params.bonusOptOut

        def result = playerService.update(params, false)

        if (result.errors) {
            render(view: "edit", model: [playerInstance: result.player, errors: result.errors])
        } else {

            if (isAbuser || isOptedOut) {
                playerBonusService.cancelAllBonuses(player, springSecurityService.getCurrentUser())
                playerFreeRoundsService.cancelAllFreeRounds(player, springSecurityService.getCurrentUser())

                if (playerLoyaltyPointsService.cancelLoyaltyPoints(player, TransactionType.SHORT_NAME.loyaltyDebit ,(isAbuser) ? TransactionSubtype.SHORT_NAME.bonusAbuser : TransactionSubtype.SHORT_NAME.bonusOptOut,
                        (isAbuser && isOptedOut) ? "as player is bonus abuser and bonus opted out" : ((isAbuser) ? "as player is bonus abuser" : "as player is bonus opted out"))) {
                    notesService.create(player, Operator.findByUsername("nektan"), ((isAbuser && isOptedOut) || isAbuser) ? NoteType.findByShortName(NoteType.SHORT_NAMES.BONUS_ABUSER) : NoteType.findByShortName(NoteType.SHORT_NAMES.BONUS_OPTOUT),
                            ((isAbuser && isOptedOut) || isAbuser) ? "Loyalty Points cancelled as player has marked bonus abuser" : "Loyalty Points cancelled as player has opted out of bonus",
                            Note.SEVERITY_LOW, null, false)
                }
            }
            flash.message = "Player \"${result.player.userName}\" updated."
            redirect(action: "details", params: [id: result.player.id])
        }
    }

    /**
     * Update players password
     * @return
     */
    @Secured('ROLE_PERMISSION_PLAYER_EDIT')
    def updatePasswordFromBackoffice() {
        Player player = playerService.findById(params.id)
        def isBonusAbuser = player.isBonusAbuser
        def result = playerService.update(params, true)

        if (result.errors) {
            render(view: "edit", model: [playerInstance: result.player, errors: result.errors])
        } else {

            /*if (!isBonusAbuser && params.isBonusAbuser) {
                playerBonusService.cancelAllBonuses(player, springSecurityService.getCurrentUser())
            }*/
            flash.message = "Player \"${result.player.userName}\" updated."
            redirect(action: "details", params: [id: result.player.id])
        }
    }

    /**
     * Initiate player creation
     * @return
     */
    @Secured('ROLE_PERMISSION_PLAYER_CREATE')
    def create() {
        render(view: "create")
    }

    /**
     * Create player
     * @return
     */
    @Secured('ROLE_PERMISSION_PLAYER_CREATE')
    def save() {
        def player = playerService.create(params)
        if (player.hasErrors()) {
            render(view: "create", model: [playerInstance: player])
        } else {
            playerService.triggerRegistrationEvent(player, null, null)
            redirect(action: "details", params: [id: player.id])
        }
    }


    /**
     * Fetches all allowed countries of a site during player creation from backoffice.
     * @param siteId
     * @return selectedCountries
     */
    @Secured('ROLE_PERMISSION_PLAYER_CREATE')
    def getDynamicCountries() {
        Site siteSelected = Site.findById(Integer.parseInt(params.id))
        List selectedCountries = new ArrayList()
        if (siteSelected?.multiCurrency) {
            selectedCountries.addAll(siteService.getInheritedValue(siteSelected, "countries"))
        } else {
            selectedCountries.addAll(Country.list())
        }
        render select(from: selectedCountries, id: "country", name: "country.id", noSelection: ['null': ''], optionKey: "id", class: "form-control", required: "required", onchange: "loadDynamicCurrencies()")
    }


    /**
     * Fetches all allowed currencies of selected countrie during player creation.
     * @param countryId
     * @return selectedCurrencies
     */
    @Secured('ROLE_PERMISSION_PLAYER_CREATE')
    def getDynamicCurrencies() {
        Country countrySelected = Country.findById(Integer.parseInt(params.id))
        Site siteSelected = Site.findById(Integer.parseInt(params.siteId))
        List selectedCurrencies = new ArrayList()
        if (siteSelected.multiCurrency) {
            selectedCurrencies.addAll(countrySelected.currency)
            if (null != countrySelected.defaultCurrency) {
                if (selectedCurrencies.contains(countrySelected.defaultCurrency)) {
                    selectedCurrencies.remove(countrySelected.defaultCurrency)
                    selectedCurrencies.add(0, countrySelected.defaultCurrency)
                } else {
                    selectedCurrencies.add(0, countrySelected.defaultCurrency)
                }
            }

        } else {
            selectedCurrencies.addAll(Currency.findAllByVisible(true))
        }
        render select(from: selectedCurrencies, id: "currency", name: "currency.id", noSelection: ['null': ''], optionKey: "id", class: "form-control", required: "required")
    }

    /**
     * Show player summary, redirects to "summary"
     * @return
     */
    def show() {
        redirect(action: 'summary', params: params)
    }


    /**
     * Takes operatot to summary tab of player where player details are populated.
     * @param playerId
     */
    def summary() {
        Player player = playerService.findById(params.id)
        if (player != null) {
            render(view: "tab_summary", model: [params: params, playerInstance: player, accounts: player.accounts])
        } else {
            flash.message = "Player not found"
            redirect(url: request.getHeader('referer'))
        }
    }


    /**
     * Takes operator to details tab of player where player details are populated.
     * @param playerId
     */
    def details() {
        Player player = playerService.findById(params.id)
        if (player != null) {
            PlayerWithdrawSettings playerWithdrawSettings = PlayerWithdrawSettings.findByPlayer(player)
            if (playerWithdrawSettings == null) {
                playerWithdrawSettings = new PlayerWithdrawSettings(player: player, isAllowed: true)
                playerWithdrawSettings.save(failOnError: true, flush: true)
            }
            boolean gamePlay = player.playerExtra.lastNonDemoGamePlayedAt != null;
            boolean isWithdrawAllowed = playerWithdrawSettings.isAllowed;
            Integer maxWithdrawalsPerDay = playerWithdrawSettings.withdrawalsPerDay != null ? playerWithdrawSettings.withdrawalsPerDay : player.site.noOfWithdrawals
            Integer playerWithdrawalsPerDay = CalendarUtility.isToday(player.playerExtra.lastWithdrawAt) ? player.playerExtra.withdrawCountToday : 0
            BigDecimal playerWithdrawAmountDaily = CalendarUtility.isToday(player.playerExtra.lastWithdrawAt) ? player.playerExtra.totalWithdrawAmountDay : BigDecimal.ZERO
            BigDecimal playerWithdrawAmountMonthly = CalendarUtility.isCurrentMonth(player.playerExtra.lastWithdrawAt) ? player.playerExtra.totalWithdrawAmountMonth : BigDecimal.ZERO
            playerWithdrawAmountDaily = playerWithdrawAmountDaily.setScale(2)
            playerWithdrawAmountMonthly = playerWithdrawAmountMonthly.setScale(2)
            BigDecimal maxWithdrawAmountDaily = playerWithdrawSettings.playerDailyLimit
            BigDecimal maxWithdrawAmountMonthly = playerWithdrawSettings.playerMonthlyLimit
            boolean isMaxWithdrawAmountDailyInherited = false;
            boolean isMaxWithdrawAmountMonthlyInherited = false;

            if (maxWithdrawAmountDaily == null || maxWithdrawAmountMonthly == null) {
                for (MaxAmountDayMonth maxAmountDayMonth : player.site.maxAmountDayMonth) {
                    if (maxWithdrawAmountDaily == null && maxAmountDayMonth.durationType == DurationType.DAILY.id && player.currency.id == maxAmountDayMonth.currency.id) {
                        maxWithdrawAmountDaily = maxAmountDayMonth.amount
                        isMaxWithdrawAmountDailyInherited = true
                    }
                    if (maxWithdrawAmountMonthly == null && maxAmountDayMonth.durationType == DurationType.MONTH.id && player.currency.id == maxAmountDayMonth.currency.id) {
                        maxWithdrawAmountMonthly = maxAmountDayMonth.amount
                        isMaxWithdrawAmountMonthlyInherited = true;
                    }
                }
            }
            List<PlayerBlockedCardDetails> playerBlockedCardDetailsList = null
            if(null != player.blockedPaymentMethods && player.blockedPaymentMethods?.size() > 0 ){
                playerBlockedCardDetailsList = PlayerBlockedCardDetails.findAllByPlayer(player)
            }

            render(view: "tab_details", model: [params                           : params, playerInstance: player, isWithdrawAllowed: isWithdrawAllowed, gamePlay: gamePlay,
                                                playerWithdrawalsPerDay          : playerWithdrawalsPerDay, maxWithdrawalsPerDay: maxWithdrawalsPerDay,
                                                playerWithdrawAmountDaily        : playerWithdrawAmountDaily, playerWithdrawAmountMonthly: playerWithdrawAmountMonthly,
                                                maxWithdrawAmountDaily           : maxWithdrawAmountDaily, maxWithdrawAmountMonthly: maxWithdrawAmountMonthly,
                                                isMaxWithdrawAmountDailyInherited: isMaxWithdrawAmountDailyInherited, isMaxWithdrawAmountMonthlyInherited: isMaxWithdrawAmountMonthlyInherited,
                                                isMaxWithdrawalPerDayInherited   : (playerWithdrawSettings.withdrawalsPerDay == null),
                                                defaultWithdrawPaymentMethod     : ( null == playerWithdrawSettings.defaultPaymentMethod ? "" : playerWithdrawSettings.defaultPaymentMethod.shortName),
                                                defaultWithdrawPaymentSolution   : ( null == playerWithdrawSettings.defaultPaymentMethod ? "" : playerWithdrawSettings.defaultPaymentMethod.paymentSolution.shortName),
                                                overrideDefaultPaymentMethod     : playerWithdrawSettings.overrideDefaultPaymentMethod,
                                                cardDetail                       : ( null == playerWithdrawSettings.cardDetail ? "" : playerWithdrawSettings.cardDetail?.cardType?.shortName+' '+playerWithdrawSettings.cardDetail.cardNumber),
                                                playerBlockedCardDetails         : playerBlockedCardDetailsList])
        } else {
            flash.message = "Player not found"
            redirect(url: request.getHeader('referer'))
        }
    }


    /**
     * Takes operator to transactions tab where operator is allowed to search for player transactions
     * @param playerId
     */
    def transactions() {
        Player player = playerService.findById(params.id)
        if (player != null) {
            params.playerId = player.id
            render(view: "/transaction/tab_transactions", model: [params: params, playerInstance: player])
        } else {
            flash.message = "Player not found"
            redirect(url: request.getHeader('referer'))
        }
    }


    /**
     * Takes operator to bonus tab where operator is allowed to search for player bonuses.
     * @param playerId
     */
    def bonuses() {
        Player player = playerService.findById(params.id)
        if (player != null) {
            render(view: "tab_bonuses", model: [params: params, playerInstance: player])
        } else {
            flash.message = "Player not found"
            redirect(url: request.getHeader('referer'))
        }
    }


    /**
     * Takes operator to notes tab where player notes are listed.
     * @param playerId
     */
    def notes() {
        Player player = playerService.findById(params.id)
        if (player != null) {
            render(view: "/notes/tab_notes", model: [params: params, playerInstance: player])
        } else {
            flash.message = "Player not found"
            redirect(url: request.getHeader('referer'))
        }
    }


    def events() {
        Player player = playerService.findById(params.id)
        if (player != null) {
            render(view: "tab_events", model: [params: params, playerInstance: player])
        } else {
            flash.message = "Player not found"
            redirect(url: request.getHeader('referer'))
        }
    }


    def fraud() {
        Player player = playerService.findById(params.id)
        if (player != null) {
            render(view: "tab_fraud", model: [params: params, playerInstance: player])
        } else {
            flash.message = "Player not found"
            redirect(url: request.getHeader('referer'))
        }
    }

    /**
     * Takes operator to players crm tab.
     * @param playerId
     */
    def crm() {
        Player player = playerService.findById(params.id)
        if (player != null) {
            render(view: "tab_crm", model: [params: params, playerInstance: player])
        } else {
            flash.message = "Player not found"
            redirect(url: request.getHeader('referer'))
        }
    }


    /**
     * Takes operator to deposit limits page where player deposit limits are populated.
     * @param playerId
     */
    @Secured('ROLE_PERMISSION_PLAYER_DEPOSIT_LIMITS')
    def depositlimits() {
        Player player = playerService.findById(params.id)
        if (player != null) {
            player = playerService.checkDepositLimits(player)
            render(view: "tab_depositlimits", model: [params: params, playerInstance: player])
        } else {
            flash.message = "Player not found"
            redirect(url: request.getHeader('referer'))
        }
    }


    /**
     * Updates player deposit limits.
     *
     * @param playerId
     * @param requestedDailyDepositLimit
     * @param requestedWeeklyDepositLimit
     * @param requestedMonthlyDepositLimit
     */
    @Secured('ROLE_PERMISSION_PLAYER_DEPOSIT_LIMITS')
    def updateDepositLimits() {
        Player player = playerService.findById(Long.valueOf(params.id))
        if (player == null) {
            flash.message = g.message(code: 'invalid.player')
            render(view: "tab_depositlimits", model: [params: params, playerInstance: player])
            return
        }

        def int requestedDailyLimit, requestedWeeklyLimit, requestedMonthlyLimit
        log.info(params)

        BigDecimal daily = StringUtils.isBlank(params.'requestedDailyDepositLimit') ? null : params.'requestedDailyDepositLimit'.toBigDecimal()
        BigDecimal weekly = StringUtils.isBlank(params.'requestedWeeklyDepositLimit') ? null : params.'requestedWeeklyDepositLimit'.toBigDecimal()
        BigDecimal monthly = StringUtils.isBlank(params.'requestedMonthlyDepositLimit') ? null : params.'requestedMonthlyDepositLimit'.toBigDecimal()

        if ((daily == null || daily <= 0) && (weekly == null || weekly <= 0) && (monthly == null || monthly <= 0)) {
            flash.message = g.message(code: 'depositLimits.select.atleast.onevalue')
            render(view: "tab_depositlimits", model: [params: params, playerInstance: player])
            return
        }

        playerService.checkDepositLimits(player)

//      if (checkNotNullAndNotZero(player.playerDepositLimits.pendingDailyLimit) && checkNotNullAndNotZero(player.playerDepositLimits.pendingWeeklyLimit) &&
//                checkNotNullAndNotZero(player.playerDepositLimits.pendingMonthlyLimit)) {
//                  flash.message = g.message(code: 'depositlimits.already.set')
//            render(view: "tab_depositlimits", model: [params: params, playerInstance: player])
//            return
//      }

        //daily should not be more than global deposit limit, weekly and monthly
        if (daily != null && daily > 0) {

            if (player.site.brandDepositLimit != null && daily.compareTo(player.site.brandDepositLimit) == 1) {

                flash.message = g.message(code: 'daily.depositLimit.greaterThan.brandDepositLimit')
                render(view: "tab_depositlimits", model: [params: params, playerInstance: player])
                return
            }
//            if(checkNotNullAndNotZero(player.playerDepositLimits.pendingDailyLimit)) {
//                flash.message = g.message(code: 'pendingDaily.depositLimit.already.set')
//                render(view: "tab_depositlimits", model: [params: params, playerInstance: player])
//                return
//            }

            if (weekly != null && weekly > 0 && daily.compareTo(weekly) == 1) {
                flash.message = g.message(code: 'daily.deposit.limit.greaterThanWeekly')
                render(view: "tab_depositlimits", model: [params: params, playerInstance: player])
                return
            }
            if ((weekly == null || weekly <= 0) &&
                    ((checkNotNullAndNotZero(player.playerDepositLimits.weeklyLimit) && daily.compareTo(player.playerDepositLimits.weeklyLimit) == 1) ||
                            (checkNotNullAndNotZero(player.playerDepositLimits.pendingWeeklyLimit) && daily.compareTo(player.playerDepositLimits.pendingWeeklyLimit) == 1))) {
                flash.message = g.message(code: 'daily.deposit.limit.greaterThanPendingWeekly')
                render(view: "tab_depositlimits", model: [params: params, playerInstance: player])
                return
            }

            if (monthly != null && monthly > 0 && daily.compareTo(monthly) == 1) {
                flash.message = g.message(code: 'daily.deposit.limit.greaterThanMonthly')
                render(view: "tab_depositlimits", model: [params: params, playerInstance: player])
                return
            }
            if ((monthly == null || monthly <= 0) &&
                    ((checkNotNullAndNotZero(player.playerDepositLimits.monthlyLimit) && daily.compareTo(player.playerDepositLimits.monthlyLimit) == 1) ||
                            (checkNotNullAndNotZero(player.playerDepositLimits.pendingMonthlyLimit) && daily.compareTo(player.playerDepositLimits.pendingMonthlyLimit) == 1))) {
                flash.message = g.message(code: 'daily.deposit.limit.greaterThanPendingMonthly')
                render(view: "tab_depositlimits", model: [params: params, playerInstance: player])
                return
            }
        }

        if (weekly != null && weekly > 0) {
//            if(checkNotNullAndNotZero(player.playerDepositLimits.pendingWeeklyLimit)) {
//                flash.message = g.message(code: 'pendingWeekly.depositLimit.already.set')
//                render(view: "tab_depositlimits", model: [params: params, playerInstance: player])
//                return
//            }

            if (daily != null && daily > 0 && daily.compareTo(weekly) == 1) {
                flash.message = g.message(code: 'weekly.deposit.limit.lessThanDaily')
                render(view: "tab_depositlimits", model: [params: params, playerInstance: player])
                return
            }
            if ((daily == null || daily <= 0) &&
                    ((checkNotNullAndNotZero(player.playerDepositLimits.dailyLimit) && weekly.compareTo(player.playerDepositLimits.dailyLimit) < 0) ||
                            (checkNotNullAndNotZero(player.playerDepositLimits.pendingDailyLimit) && weekly.compareTo(player.playerDepositLimits.pendingDailyLimit) < 0))) {
                flash.message = g.message(code: 'weekly.deposit.limit.lessThanPendingDaily')
                render(view: "tab_depositlimits", model: [params: params, playerInstance: player])
                return
            }

            if (monthly != null && monthly > 0 && weekly.compareTo(monthly) == 1) {
                flash.message = g.message(code: 'weekly.deposit.limit.greaterThanMonthly')
                render(view: "tab_depositlimits", model: [params: params, playerInstance: player])
                return
            }
            if ((monthly == null || monthly <= 0) &&
                    ((checkNotNullAndNotZero(player.playerDepositLimits.monthlyLimit) && weekly.compareTo(player.playerDepositLimits.monthlyLimit) == 1) ||
                            (checkNotNullAndNotZero(player.playerDepositLimits.pendingMonthlyLimit) && weekly.compareTo(player.playerDepositLimits.pendingMonthlyLimit) == 1))) {
                flash.message = g.message(code: 'weekly.deposit.limit.greaterThanPendingMonthly')
                render(view: "tab_depositlimits", model: [params: params, playerInstance: player])
                return
            }
        }

        if (monthly != null && monthly > 0) {
//            if(checkNotNullAndNotZero(player.playerDepositLimits.pendingMonthlyLimit)) {
//                flash.message = g.message(code: 'pendingMonthly.depositLimit.already.set')
//                render(view: "tab_depositlimits", model: [params: params, playerInstance: player])
//                return
//            }

            if (daily != null && daily > 0 && daily.compareTo(monthly) == 1) {
                flash.message = g.message(code: 'monthly.deposit.limit.lessThanDaily')
                render(view: "tab_depositlimits", model: [params: params, playerInstance: player])
                return
            }
            if ((daily == null || daily <= 0) &&
                    ((checkNotNullAndNotZero(player.playerDepositLimits.dailyLimit) && monthly.compareTo(player.playerDepositLimits.dailyLimit) < 0) ||
                            (checkNotNullAndNotZero(player.playerDepositLimits.pendingDailyLimit) && monthly.compareTo(player.playerDepositLimits.pendingDailyLimit) < 0))) {
                flash.message = g.message(code: 'monthly.deposit.limit.lessThanPendingDaily')
                render(view: "tab_depositlimits", model: [params: params, playerInstance: player])
                return
            }

            if (weekly != null && weekly > 0 && monthly.compareTo(weekly) < 1) {
                flash.message = g.message(code: 'monthly.deposit.limit.lessThanWeekly')
                render(view: "tab_depositlimits", model: [params: params, playerInstance: player])
                return
            }
            if ((weekly == null || weekly <= 0) &&
                    ((checkNotNullAndNotZero(player.playerDepositLimits.weeklyLimit) && monthly.compareTo(player.playerDepositLimits.weeklyLimit) < 0) ||
                            (checkNotNullAndNotZero(player.playerDepositLimits.pendingWeeklyLimit) && monthly.compareTo(player.playerDepositLimits.pendingWeeklyLimit) < 0))) {
                flash.message = g.message(code: 'monthly.deposit.limit.lessThanPendingWeekly')
                render(view: "tab_depositlimits", model: [params: params, playerInstance: player])
                return
            }
        }


        def result = playerService.setDepositLimits(player, daily, weekly, monthly)

        if (result.returnCode == ReturnCodes.Code.OK) {
            result.player.save()
            flash.message = "Deposit Limits changed."
        } else {
            flash.message = result.message
        }
        render(view: "tab_depositlimits", model: [params: params, playerInstance: result.player])
    }

    // show all players, not used in public
    def listAll() {
        def list = playerService.listAll()
        render(view: "list", model: [playerInstanceList: list, playerInstanceCount: list.size()])
    }

    /**
     * Display the change status screen
     * @return
     */
    def status() {
        Player player = playerService.findById(params.id)
        render(view: "status", model: [playerInstance: player, params: params])
    }

    /**
     * Display the change Welcome Offer Restriction screen
     * @return
     */
    def welcomeOfferRestriction() {
        Player player = playerService.findById(params.id)
        render(view: "welcomeOfferRestriction", model: [playerInstance: player, params: params])
    }

    @Secured('ROLE_PERMISSION_EDIT_PRECHECK_CONFIG')
    def cardDetails() {
        Player player = playerService.findById(params.id)
        if(player != null && params.paymentMethod != 'undefined') {
            PaymentMethod paymentMethod = PaymentMethod.findById(params.paymentMethod)
            if(null != paymentMethod && StringUtils.equalsIgnoreCase(paymentMethod.paymentSolution.shortName, "creditcards")) {
                PlayerWithdrawSettings playerWithdrawSettings = PlayerWithdrawSettings.findByPlayer(player)
                Set<CardDetail> playerUsedCards = CardDetail.findAllByPlayer(player)
                render(template: "cardDetailsTemplate", model: [playerUsedCards: playerUsedCards, playerWithdrawSettings: playerWithdrawSettings])
                return
            }
        }
        render("")
        return
    }

    /**
     * Display the change status screen
     * @return
     */
    @Secured('ROLE_PERMISSION_EDIT_PRECHECK_CONFIG')
    def kyc() {
        Player player = playerService.findById(params.id)
        Set<PaymentMethod> allowedWithdrawPaymentMethods = new HashSet<PaymentMethod>()
        if (player != null) {
            PlayerWithdrawSettings playerWithdrawSettings = PlayerWithdrawSettings.findByPlayer(player)
            if (playerWithdrawSettings == null) {
                playerWithdrawSettings = new PlayerWithdrawSettings(player: player, isAllowed: true)
                playerWithdrawSettings.save(failOnError: true, flush: true)
            }

            if(player.site.useWithdrawMappings && null != player.playerExtra.lastDepositPaymentMethod) {
                List<Long> allowedWithdrawPaymentMethodIds = null
                Sql sql = new Sql(dataSource)
                allowedWithdrawPaymentMethodIds = sql.rows("select pcmpm.payment_method_id  from pm_ctry_cur_mapping pcm  " +
                        " inner join payment_method pm on pcm.payment_method_id = pm.id and pm.short_name =:lastDepositPaymentMethod " +
                        " inner join pm_ctry_cur_mapping_country pc on pc.pm_ctry_cur_mapping_countries_id=pcm.id " +
                        " inner join pm_ctry_cur_mapping_currency pcur on pcur.pm_ctry_cur_mapping_currencies_id=pcm.id  " +
                        " inner join pm_ctry_cur_mapping_payment_method pcmpm on pcmpm.allowed_payment_method_id = pcm.id " +
                        " left outer join card_type ct on ct.id=pcm.card_type_id " +
                        " inner join (select player_id,currency_id,country_id from player p  inner join account acc on acc.player_id=p.id and acc.type=1) x\n" +
                        "  on x.currency_id=pcur.currency_id and x.country_id=pc.country_id " +
                        " where player_id=:playerId and ifnull(ct.short_name,'') = :cardType",
                              [lastDepositPaymentMethod: player.playerExtra.lastDepositPaymentMethod.shortName, playerId: player.id,
                                cardType: player.playerExtra.lastDepositCardType == null ? '' : player.playerExtra.lastDepositCardType.shortName]).collect {
                    it.payment_method_id
                };
                if(null != allowedWithdrawPaymentMethodIds && allowedWithdrawPaymentMethodIds.size() > 0) {
                    allowedWithdrawPaymentMethods = PaymentMethod.findAllByIdInList(allowedWithdrawPaymentMethodIds)
                }
            }

            DepositPaymentMethodCountryCurrencyMapping depositMappings = DepositPaymentMethodCountryCurrencyMapping.findByCountryAndCurrency(player.country, player.currency)
            List<PaymentMethod> blockedPaymentMethods = null
            if(null != depositMappings){
                blockedPaymentMethods = new ArrayList(depositMappings.paymentMethods)
            }else{
                blockedPaymentMethods = new ArrayList<PaymentMethod>()
            }

            render(view: "kyc", model: [playerInstance: player, params: params, playerWithdrawSettings: playerWithdrawSettings, allowedWithdrawPaymentMethods: allowedWithdrawPaymentMethods, blockedPaymentMethods: blockedPaymentMethods])
        } else {
            flash.message = "Player not found"
            redirect(url: request.getHeader('referer'))
        }
    }


    /**
     * Update player Kyc result and description and withdraw limits.
     * @param playerId
     * @param kycResult
     * @param kycDescription
     * @param isAllowed
     * @param withdrawalsPerDay
     * @param playerDailyLimit
     * @param playerMonthlyLimit
     */
    @Secured('ROLE_PERMISSION_EDIT_PRECHECK_CONFIG')
    def updateKyc() {
        Player player = playerService.findById(params.id)
        Operator currentLoggedInUser = springSecurityService.getCurrentUser();
        if (player != null) {
            PlayerExtra playerExtra = player.playerExtra
            log.debug("kyc-change-bo: user: " + currentLoggedInUser?.id + " playerId: " + player?.id + " kycRes: " + params.'playerExtra.kycResult' + " kycDesc: " + params.'playerExtra.kycDescription' + " Old kycRes: " + playerExtra?.kycResult + " Old kycRes: " + playerExtra?.kycDescription)
            PlayerWithdrawSettings playerWithdrawSettings = PlayerWithdrawSettings.findByPlayer(player)
            if (playerWithdrawSettings == null) {
                playerWithdrawSettings = new PlayerWithdrawSettings(player: player)
            }
            boolean isKycResultChanged = !StringUtils.equals(playerExtra.kycResult, params.'playerExtra.kycResult')
            boolean isKycDescChanged = !StringUtils.equals(playerExtra.kycDescription, params.'playerExtra.kycDescription')
            playerExtra.kycResult = params.'playerExtra.kycResult'
            playerExtra.kycDescription = params.'playerExtra.kycDescription'
            playerExtra.docVerificationStatusId = StringUtils.isEmpty(params.'playerExtra.docVerificationStatusId') ? null : new Integer(params.'playerExtra.docVerificationStatusId')
            playerWithdrawSettings.isAllowed = params.'isAllowed' as boolean
            if(player.site.useWithdrawMappings) {
                if(null == params.'playerWithdrawSettings.defaultPaymentMethod') {
                    params.remove('playerWithdrawSettings.defaultPaymentMethod')
                }
                playerWithdrawSettings.properties = params
            }


            if (params.'withdrawalsPerDay') {
                playerWithdrawSettings.withdrawalsPerDay = Integer.parseInt(params.'withdrawalsPerDay')
            } else {
                playerWithdrawSettings.withdrawalsPerDay = null
            }
            if (params.'playerDailyLimit') {
                playerWithdrawSettings.playerDailyLimit = new BigDecimal(params.'playerDailyLimit')
            } else {
                playerWithdrawSettings.playerDailyLimit = null
            }
            if (params.'playerMonthlyLimit') {
                playerWithdrawSettings.playerMonthlyLimit = new BigDecimal(params.'playerMonthlyLimit')
            } else {
                playerWithdrawSettings.playerMonthlyLimit = null
            }

            if (playerWithdrawSettings.playerMonthlyLimit != null && playerWithdrawSettings.playerDailyLimit != null) {
                if (playerWithdrawSettings.playerDailyLimit.toBigDecimal() > playerWithdrawSettings.playerMonthlyLimit.toBigDecimal()) {
                    flash.message = g.message(code: 'playerWithdrawSettings.playerMonthlyLimitGreaterThan.min.error')
                    render(view: "kyc", model: [playerInstance: player, params: params, playerWithdrawSettings: playerWithdrawSettings])
                    return
                }
            }
            if (playerWithdrawSettings.playerMonthlyLimit == BigDecimal.ZERO || playerWithdrawSettings.playerDailyLimit == BigDecimal.ZERO) {
                flash.message = g.message(code: 'playerWithdrawSettings.playerDailyMonthlyLimit.min.error')
                render(view: "kyc", model: [playerInstance: player, params: params, playerWithdrawSettings: playerWithdrawSettings])
                return
            }
            if (playerWithdrawSettings.playerDailyLimit == null && playerWithdrawSettings.playerMonthlyLimit != null) {
                BigDecimal day
                for (MaxAmountDayMonth obj : player.site.maxAmountDayMonth) {
                    if (obj.durationType == DurationType.DAILY.id && obj.currency.id == player.currency.id) {
                        day = obj.amount
                        break
                    }
                }
                if (playerWithdrawSettings.playerMonthlyLimit < day) {
                    def msg = "player Monthly Limit must be greater than site Daily limit."
                    flash.message = msg
                    render(view: "kyc", model: [playerInstance: player, params: params, playerWithdrawSettings: playerWithdrawSettings])
                    return
                }
            }

            if (playerWithdrawSettings.playerMonthlyLimit == null && playerWithdrawSettings.playerDailyLimit != null) {
                BigDecimal month
                for (MaxAmountDayMonth obj : player.site.maxAmountDayMonth) {
                    if (obj.durationType == DurationType.MONTH.id && obj.currency.id == player.currency.id) {
                        month = obj.amount
                        break
                    }
                }
                if (playerWithdrawSettings.playerDailyLimit > month) {
                    def msg = "player Daily Limit must be Less than site Monthly limit."
                    flash.message = msg
                    render(view: "kyc", model: [playerInstance: player, params: params, playerWithdrawSettings: playerWithdrawSettings])
                    return
                }
            }
            if(isKycResultChanged || isKycDescChanged){
                player.lastUpdated = new Date()
            }

            if( params.'enablePaymentMethodChangeThreshold' ||  params.'_enablePaymentMethodChangeThreshold' == ""  ){
                player.enablePaymentMethodChangeThreshold = params.'enablePaymentMethodChangeThreshold' as boolean
            }

            if( params.'enableMaxDepositMethodRestriction' ||  params.'_enableMaxDepositMethodRestriction' == ""  ){
                player.enableMaxDepositMethodRestriction = params.'enableMaxDepositMethodRestriction' as boolean
            }

            if( null != params.'blockedPaymentMethods'){
                List list = PaymentMethod.findAllByIdInList( params.list('blockedPaymentMethods') )
                player.blockedPaymentMethods = new HashSet(list)
            }else{
                player.blockedPaymentMethods = null
            }

            player.validate()
            if (player.hasErrors()) {
                render(view: "kyc", model: [playerInstance: player, params: params, playerWithdrawSettings: playerWithdrawSettings])
            }
            player.save(failOnError: true)
            //save player blocked card details
            PlayerBlockedCardDetails.findAllByPlayer(player).each {it.delete(failOnError: true, flush: true)}
            List<PlayerBlockedCardDetails> playerBlockedCardDetailsList = new ArrayList<PlayerBlockedCardDetails>()
            if( null != params.'blockedCardDetails'){
                List<CardDetail> list = CardDetail.findAllByIdInList( params.list('blockedCardDetails') )
                if( list?.size() > 0){
                    list.each { it ->
                        PlayerBlockedCardDetails blockedCardDetails = new PlayerBlockedCardDetails(player: player, cardDetail: it)
                        playerBlockedCardDetailsList.add(blockedCardDetails)
                    }
                    PlayerBlockedCardDetails.saveAll(playerBlockedCardDetailsList)
                }
            }
            redirect(action: "details", id: player.id)
        } else {
            flash.message = "Player not found"
            redirect(url: request.getHeader('referer'))
        }
    }

    /**
     * Initiate the players status change
     *
     * @param playerId
     * @return
     */
    @Secured('ROLE_PERMISSION_PLAYER_EDIT')
    def changeStatus() {

        Player player = playerService.findById(params.id)
        Operator currentLoggedInUser = springSecurityService.getCurrentUser();
        PlayerStatus playerStatus = PlayerStatus.get(params.'playerStatus.id')
        Date selfExcludeTo = null;
        if (playerStatus != null && (StringUtils.equalsIgnoreCase(playerStatus.name, "selfExcluded") || StringUtils.equalsIgnoreCase(playerStatus.name, "timeOut")) && (StringUtils.isNotBlank(params.selfExcludeTo))) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd")
            try {
                selfExcludeTo = sdf.parse(params.selfExcludeTo)
            } catch (ParseException e) {
                flash.message = "Invalid self exclusion to date."
                render(view: "status", model: [playerInstance: player, params: params])
                return;
            }
            Date todayDate = new Date()
            if (selfExcludeTo != null && todayDate.after(selfExcludeTo)) {
                flash.message = "Date should be greater than today."
                render(view: "status", model: [playerInstance: player, params: params])
                return;
            }
        }
        def result = playerService.changeStatus(player, playerStatus, selfExcludeTo, currentLoggedInUser, params.text)

        if(null != result && null != result.returnCode && result.returnCode == ReturnCodes.Code.OK){
            redirect(action: "details", id: player.id)
        } else {
            render(view: "status", model: [playerInstance: player, noteInstance: result.note, params: params])
        }
        log.info("changeStatus End:: ${player.userName}")

    }


    def viewDocument() {
        Document document = Document.get(params.id)
        render(view: 'document', model: [documentInstance: document, playerInstance: document.player])
    }

    def addDocument() {
        Player player = playerService.findById(params.id)
        render(view: "addDocument", model: [playerInstance: player])
    }


    def createDocument() {
        Player player = playerService.findById(params.id)
        Document document = new Document(params)
        if (params.expiry) {
            document.expiry = new java.sql.Date(params.date('expiry', "yyyy-mm-dd").getTime());
        }

        if (document.save(flush: true)) {
            player.addToDocuments(document)
            player.save(flush: true)
            redirect(action: "details", id: player.id)
        } else {
            render(view: "addDocument", model: [playerInstance: player, documentInstance: document])
        }
    }


    /**
     * Send new password to players email.
     * @param sendEncodedPasswordLink
     * @param playerId
     */
    def resetPasswordFromBackoffice() {
        boolean sendEncodedPasswordLink = false
        sendEncodedPasswordLink = paramService.getBoolean("player.sendEncodedPasswordLink")
        playerService.resetPasswordEncoded(playerService.findById(params.id), sendEncodedPasswordLink)
        render("Password set to one-shot and email is sent")
    }


    /**
     * Resends validation mail for newly registerd player
     *
     * @param playerId
     */
    def resendValidationMail() {
        Player player = playerService.findById(params.id)
        def result = playerService.resendValidationMail(player)
        render(result.errors)
    }


    /**
     * Exports searched players result to excel.
     */
    def export() {
        //if(!params.max) params.max =  null

        String format = mapExtensionFormat[params?.extension]

        def currentDate = new Date()
        def formattedDate = g.formatDate(date: currentDate, format: 'yyyy-MM-dd  hh:mm:ss')

        if (format && format != "html") {
            response.contentType = grailsApplication.config.grails.mime.types[params?.extension]
            response.setHeader("Content-disposition", "attachment; filename=Players-${formattedDate}.${params?.extension}")

            List fields = ["id", "site.name", "networkId", "createdAt", "userName", "firstName", "lastName", "dateOfBirth", "vipLevelShortName", "securityLevelShortName", "email", "mobileNumber", "landlineNumber", "address_1", "address_2", "houseNumber", "postcode", "city", "county", "state", "country", "registrationIpAddress", "referrerTag", "playerStatus"]
            Map labels = ["id": "Player Id", "site.name": "Account System", "networkId": "Network Id", "createdAt": "createdAt", "userName": "User Name", "firstName": "First Name", "lastName": "Last Name", "dateOfBirth": "Date of birth", "vipLevelShortName": "VIP Level", "securityLevelShortName": "Security Level", "email": "Email", "mobileNumber": "Mobile Number", "landlineNumber": " Landline Number", "address_1": "address_1", "address_2": "address_2", "houseNumber": "houseNumber", "postcode": "postcode", "city": "city", "county": "county", "state": "state", "country": "country", "registrationIpAddress": "registrationIpAddress", "referrerTag": "Referrer Tag", "playerStatus": "Status"]

            def formatDate = { Player, value ->
                return value.format('yyyy-MM-dd')
            }

            Map formatters = [createdAt: formatDate, dateOfBirth: formatDate]
            exportService.export(format, response.outputStream, playerService.find(params), fields, labels, formatters, [:])
        }

        // [playerInstanceList: playerService.find(params)]
        return;
    }

    /**
    * Exports global transactions and player transactions to excel.
    */
    def exportTransactions() {
        params.max = null
        params.offset = null
        Player player = playerService.findById(params.id)

        List<Transaction> transactions = accountService.getTransactionsForPlayer(player, null, null, null, params).transactions

        def headers = ['createdAt', 'game', 'type', 'externalGameInstanceId', 'account.type', 'credit', 'debit', 'balanceAfter', 'operator', 'sessionId', 'description']
        def withProperties = headers

        new WebXlsxExporter().with {
            setResponseHeaders(response)
            putCellValue(0, 0, "Transactions for player")
            putCellValue(1, 0, "Username: ${player.userName}")
            putCellValue(2, 0, "First name: ${player.firstName}")
            putCellValue(3, 0, "Last name: ${player.lastName}")
            fillRow(headers, 5)
            add(transactions, withProperties, 6)
            save(response.outputStream)
        }
    }



    /**
     * Method used to export required fields of linked players to csv
     * @return
     */
    def exportNetworkIds() {
        String format = mapExtensionFormat[params?.extension]

        def currentDate = new Date()
        def formattedDate = g.formatDate(date: currentDate, format: 'yyyy-MM-dd  hh:mm:ss')

        if (format && format != "html") {
            response.contentType = grailsApplication.config.grails.mime.types[params?.extension]
            response.setHeader("Content-disposition", "attachment; filename=NetworkPlayers-${params.networkId}-${formattedDate}.${params?.extension}")

            List<NetworkPlayerDTO> networkPlayerDTOLst = playerService.findNetworkIds(params)
            Double[] networkTotals = playerService.getSumNetworkGBP(networkPlayerDTOLst)

            List fields = ["playerId", "networkId", "currency", "deposits", "withdrawals", "ggr", "ngr", "accountSystem", "vipStatus", "accountStatus", "depositsGBP", "withdrawalsGBP", "ggrGBP","ngrGBP"]
            Map labels = ["playerId": "Player Id", "networkId": "Network ID", "currency": "Currency", "deposits": "Deposits", "withdrawals": "Withdrawals", "ggr": "GGR", "ngr":"NGR", "accountSystem": "Account System", "vipStatus": "VIP Status", "accountStatus": "Account Status", "depositsGBP": "Deposits GBP ("+networkTotals[0]+")", "withdrawalsGBP": "Withdrawals GBP ("+networkTotals[1]+")", "ggrGBP": "GGR GBP ("+networkTotals[2]+")", "ngrGBP": "NGR GBP ("+networkTotals[3]+")"]

            def formatDate = { Player, value ->
                return value.format('yyyy-MM-dd')
            }

            Map formatters = [createdAt: formatDate, dateOfBirth: formatDate]
            exportService.export(format, response.outputStream, networkPlayerDTOLst, fields, labels, formatters, [:])
        }
        return;
    }


    private boolean checkNotNullAndNotZero(BigDecimal limit) {
        return limit != null && limit > 0
    }

    def resendWelcomeMail() {
        /*Player player = Player.findById(params.id)
        PlayerExtra playerExtra = player.playerExtra
        playerExtra.welcomeMailDelivered = true
        playerExtra.save(flush:true)
        player.playerExtra = playerExtra*/
        def result = playerService.resendWelcomeMail(params)
        if (result.returnCode == ReturnCodes.Code.OK) {
            Player player = playerService.findById(params.id)
            render(status: 200, contentType: 'application/json') {
                return ["mailDelivered": player?.playerExtra?.welcomeMailDelivered
                ]
            }
        }
    }

    /**
     * Fetches all players having same networkId
     * @param playerId
     */
    @Secured('ROLE_PERMISSION_PLAYER_NETWORK_ID_VIEW')
    def networkPlayers() {
        def results
        Player player = Player.findById(params.id);
        List<Site> site = operatorService.operatingSites()
        List sites = new ArrayList();
        for(Site siteList:site){
            sites.add(siteList.getId())
        }

        if(player.networkId != null){
            def c = Player.createCriteria()
            results = c.list(max: params?.max != null ? params.max : 10, offset: params?.offset, sort: params?.sort == null ? 'id' : params?.sort,order: params?.order == null ? 'desc' : params?.order) {
                if (player.networkId) eq("networkId",player.networkId)
                if ( sites ) {
                    'in'("site.id", sites.collect {(it)})
                }
            }
        }
        render(view: "_tabNetworkPlayers", model: [playerInstanceList: results != null ? results : null , playerInstance: player, playersFound:results != null? results.getTotalCount():0, params: params])
    }

    /**
     * Initiates player networkId edit
     * Takes operator to view to edit networkId of player
     * @param playerId
     */
    @Secured('ROLE_PERMISSION_PLAYER_NETWORK_ID_EDIT')
    def editNetworkId() {
        Player player = Player.findById(params.id);
        render(view: "_editNetworkForm", model: [playerInstance: player, params: params])
    }

    /**
     * Fetches all players having networkId that matches newNetworkId given by operator
     * @param networkId
     * @param playerId
     */
    def getNewNetworkPlayers() {
        def results
        Player player = Player.findById(params.id);
        List<Site> site = operatorService.operatingSites()
        List sites = new ArrayList();
        for(Site siteList:site){
            sites.add(siteList.getId())
        }
        if(StringUtils.isNotEmpty(params.network)){
            def c = Player.createCriteria()
            results = c.list(sort: params?.sort == null ? 'id' : params?.sort,order: params?.order == null ? 'desc' : params?.order) {
                if ( params.long('network')) eq("networkId", params.long('network'))
                if ( sites ) {
                    'in'("site.id", sites.collect {(it)})
                }
            }
        }
        render(view: "_getNetworkDetails", model: [playerInstanceList: results != null ? results : null, playersFound: results != null ? results.getTotalCount() : 0, params: params, playerInstance: player, newNetworkId: params.network])
    }

    /**
     * Updates player networkId
     * @param networkId
     */
    @Secured('ROLE_PERMISSION_PLAYER_NETWORK_ID_EDIT')
    def updateNetwork() {
        def results
        Player player = Player.findById(params.id);
        if(StringUtils.isNotEmpty(params.networkId)){
            player.networkId = params.networkId as long
        }
        List<Site> site = operatorService.operatingSites()
        player.save();
        List sites = new ArrayList();
        for(Site siteList:site){
            sites.add(siteList.getId())
        }
        if(player.networkId != null){
            def c = Player.createCriteria()
            results = c.list(max: 20, offset: params?.offset,sort: params?.sort == null ? 'id' : params?.sort, order: params?.order == null ? 'desc' : params?.order) {
                if (player.networkId) eq("networkId",player.networkId)
                if ( sites ) {
                    'in'("site.id", sites.collect {(it)})
                }
            }
        }
        render(view: "_tabNetworkPlayers", model: [playerInstanceList: results != null ? results : null , playerInstance: player, playersFound: results != null ? results.getTotalCount():0, params: params])
    }

    /**
     * method to fetch player activity data from ware house database by giving player id as input.
     * @param id
     */
    @Secured('ROLE_PERMISSION_PLAYER_EDIT')
    def getPlayerActivitySummary() {
        try{
            Long playerId = Long.parseLong(params.id)
            PlayerActivitySummaryDTO activitySummaryDTO = playerService.getPlayerActivitySummary(playerId);
            render(template:"summaryPlayerActivityTemplate", model:[activitySummaryDTO: activitySummaryDTO])
        } catch(Exception _exp){
            log.error("getPlayerActivityData: Player Id: " + params.id + " Exception: " + _exp.getMessage())
            render(template:"summaryPlayerActivityTemplate", model:[activitySummaryDTO: null])
        }
    }

    /**
     * method will be used to identify the game launch done by mobile or not.
     * @param
     * @return
     */
    private boolean isMobile() {
        String reqAgent = request.getHeader("User-Agent")
        String patternString = "/Mobile|iP(hone|od|ad)|Android|BlackBerry|IEMobile|Kindle|NetFront|Silk-Accelerated|(hpw|web)OS|Fennec|Minimo|Opera M(obi|ini)|Blazer|Dolfin|Dolphin|Skyfire|Zune/"

        Pattern pattern = Pattern.compile(patternString);

        Matcher matcher = pattern.matcher(reqAgent);

        if (matcher.find())
            return true
        else
            return false

    }

    /**
     * change the players Welcome Offer Restiction status
     *
     * @param playerId
     * @return
     */
    @Secured('ROLE_PERMISSION_EDIT_PLAYER_WELCOME_OFFER')
    def changeWelcomeOfferRestriction() {
        Player player = playerService.findById(params.long('id'))
        Operator currentLoggedInUser = springSecurityService.getCurrentUser();

        NoteType type = NoteType.findByShortName(NoteType.SHORT_NAMES.CHANGE_PLAYER_STATUS)
        Note note = notesService.create(player, currentLoggedInUser, type, params.text, Note.SEVERITY_HIGH, null)

        if (note.hasErrors()) {
            player.discard()
            render(view: "welcomeOfferRestriction", model: [playerInstance: player, noteInstance: note, params: params])
        } else {
            playerService.changeStatus(params, player, type, currentLoggedInUser)
            note.open = false
            note.save(flush: true)
            redirect(action: "details", id: player.id)
        }
    }

    /**
     * Method used to block card details
     * @return
     */
    @Secured('ROLE_PERMISSION_EDIT_PRECHECK_CONFIG')
    def cardDetailsForBlock() {
        Player player = playerService.findById(params.id)
        if(player != null && params.paymentMethods != 'undefined') {
            boolean isCardAvble = false
            List<PaymentMethod> paymentMethodList = PaymentMethod.findAllByIdInList(params.list('paymentMethods'))
            if( null != paymentMethodList && paymentMethodList.size() > 0 ){
                for( PaymentMethod paymentMethod : paymentMethodList){
                    if(StringUtils.equalsIgnoreCase(paymentMethod.paymentSolution.shortName, "creditcards")) {
                        isCardAvble = true
                        break
                    }
                }
            }
            if( isCardAvble ){
                //player's blocked card details
                List<CardDetail> cardDetailList = new ArrayList<CardDetail>()
                if( player.blockedPaymentMethods?.size() > 0 ){
                    List<PlayerBlockedCardDetails> playerBlockedCardDetailsList = PlayerBlockedCardDetails.findAllByPlayer(player)
                    if( null != playerBlockedCardDetailsList && playerBlockedCardDetailsList?.size() > 0 ){
                        playerBlockedCardDetailsList.each { it ->
                            cardDetailList.add(it.cardDetail)
                        }
                    }
                }
                Set<CardDetail> playerUsedCards = CardDetail.findAllByPlayer(player)
                render(template: "blockedCardDetailsTemplate", model: [blockedCardDetils: playerUsedCards, playerInstance: player, playerBlockedCardDetails: cardDetailList])
                return
            }
        }
        render("")
        return
    }


    /**
     * Display the change Player Bonus Abuse Prevention screen
     * @return
     */
    @Secured('ROLE_PERMISSION_EDIT_PLAYER_BONUS_ABUSE_OVERRIDE')
    def bonusAbusePrevention() {
        Player player = playerService.findById(params.id)
        render(view: "bonusAbusePrevention", model: [playerInstance: player, params: params])
    }

    /**
     * change the players Bonus Abuse Prevetion details
     *
     * @param playerId
     * @return
     */
    @Secured('ROLE_PERMISSION_EDIT_PLAYER_BONUS_ABUSE_OVERRIDE')
    def changeBonusAbusePrevention() {
        Player player = playerService.findById(params.long('id'))
        Operator currentLoggedInUser = springSecurityService.getCurrentUser();

        NoteType type = NoteType.findByShortName(NoteType.SHORT_NAMES.CHANGE_PLAYER_STATUS)
        Note note = notesService.create(player, currentLoggedInUser, type, params.text, Note.SEVERITY_HIGH, null)

        player.playerExtra.tempBonusOverride       = (params.'tempBonusOverride'=="true" || params.'tempBonusOverride'=="on") ? true : false
        player.playerExtra.lifetimeBonusOverride   = (params.'lifetimeBonusOverride'=="true" || params.'lifetimeBonusOverride'=="on"  ) ? true : false

        if (player.playerExtra.tempBonusOverride && player.playerExtra.lifetimeBonusOverride) {
            flash.message = "Cannot select both Temporary and Lifetime bonus override flags at a time"
            render(view: "bonusAbusePrevention", model: [playerInstance: player, noteInstance: note, params: params])
            return
        }

        if (note.hasErrors()) {
            player.discard()
            render(view: "bonusAbusePrevention", model: [playerInstance: player, noteInstance: note, params: params])
        } else {

            playerService.updatePlayerExtraDetails(player)
            note.open = false
            note.save(flush: true)
            redirect(action: "details", id: player.id)
        }
    }
}