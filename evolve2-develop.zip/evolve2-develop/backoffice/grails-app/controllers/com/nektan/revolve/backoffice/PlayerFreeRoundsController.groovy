package com.nektan.revolve.backoffice

import com.nektan.revolve.api.BonusType
import com.nektan.revolve.api.PlayerFreeRoundsInfo
import com.nektan.revolve.api.ReturnCodes
import com.nektan.revolve.coreservices.Bonus
import com.nektan.revolve.coreservices.BonusDepConfig
import com.nektan.revolve.coreservices.DepBonusConfigPayout
import com.nektan.revolve.coreservices.DepFreeRoundsGameConfig
import com.nektan.revolve.coreservices.FreeRoundsGameConfig
import com.nektan.revolve.coreservices.Game
import com.nektan.revolve.coreservices.Player
import com.nektan.revolve.coreservices.PlayerFreeRounds
import com.nektan.revolve.coreservices.PlayerFreeRoundsGameConfig
import com.nektan.revolve.coreservices.PlayerFreeRoundsGameRoundMap
import grails.plugin.springsecurity.annotation.Secured
import org.apache.commons.lang.StringUtils

@Secured(['ROLE_PERMISSION_PLAYER_BONUS_VIEW'])
class PlayerFreeRoundsController {

    def playerService
    def playerFreeRoundsService
    def springSecurityService
    def gameRoundService

    def index() {
        Player playerInstance = playerService.findById(params.id)
        if (params.max == null) {
            params.max = 10
        }
        redirect(action: "search", params: params, playerInstance: playerInstance)
    }

    def search() {
        try {
            Player player = playerService.findById(params.id)
            List<PlayerFreeRounds> results = playerFreeRoundsService.find(player, params)
            List<PlayerFreeRoundsInfo> playerFreeRoundsInfos = new ArrayList<PlayerFreeRoundsInfo>();
            if (results != null && results.size() > 0) {
                ListIterator iterator = results.listIterator()
                while (iterator.hasNext()) {
                    PlayerFreeRounds freeRounds = (PlayerFreeRounds) iterator.next()
                    if(StringUtils.isBlank(freeRounds.games)) {
                        String gameProviders = "";
                        StringJoiner gameJoiner = new StringJoiner(",", "", "")
                        Set<String> gameProvidersSet = new HashSet<String>();
                        if (freeRounds.getBonus().bonusType == BonusType.Deposit.id) {
                            for (BonusDepConfig bonusDepConfig : freeRounds.getBonus().getBonusDepConfig()) {
                                if (bonusDepConfig.depositCount == freeRounds.depositCount) {
                                    for (DepFreeRoundsGameConfig depFreeRoundsGameConfig : bonusDepConfig.getFreeRoundsGameConfigList()) {
                                        if(depFreeRoundsGameConfig?.getGame()?.getRgs()?.getName().equals(freeRounds?.getGameProviders())) {
                                            gameJoiner.add(depFreeRoundsGameConfig.getGame().getShortName())
                                            gameProvidersSet.add(depFreeRoundsGameConfig.getGame().getRgs().getName())
                                        }
                                    }
                                }
                            }
                        } else if (freeRounds.getBonus().bonusType == BonusType.DepositOverTimePeriod.id) {
                            for (DepFreeRoundsGameConfig depFreeRoundsGameConfig : freeRounds.getBonus().getBonusDepConfig().get(0).getFreeRoundsGameConfigList()) {
                                if(depFreeRoundsGameConfig?.getGame()?.getRgs()?.getName().equals(freeRounds?.getGameProviders())) {
                                    gameJoiner.add(depFreeRoundsGameConfig.getGame().getShortName())
                                    gameProvidersSet.add(depFreeRoundsGameConfig.getGame().getRgs().getName())
                                }
                            }
                        } else {
                            for (FreeRoundsGameConfig freeRoundsGameConfig : freeRounds.getBonus().getFreeRoundsGameConfig()) {
                                if(freeRoundsGameConfig?.getGame()?.getRgs()?.getName().equals(freeRounds?.getGameProviders())){
                                    gameJoiner.add(freeRoundsGameConfig.getGame().getShortName())
                                    gameProvidersSet.add(freeRoundsGameConfig.getGame().getRgs().getName())
                                }
                            }
                        }
                        gameProviders = StringUtils.join(gameProvidersSet, ",");
                        PlayerFreeRoundsInfo playerFreeRoundsInfo = new PlayerFreeRoundsInfo(freeRounds.getId(), freeRounds.getBonus().getName(),
                                freeRounds.getAwardedOn(), freeRounds.getNoOfFreeRounds(), freeRounds.getFreeRoundsValidity(),
                                freeRounds.getBonusMoneyValidity(),freeRounds.getFreeRoundsBalance(), gameProviders, gameJoiner.toString(),freeRounds.getInGame(),freeRounds.getStatus(),freeRounds.getTotalWinning())
                        playerFreeRoundsInfos.add(playerFreeRoundsInfo);
                    }else{
                        PlayerFreeRoundsInfo playerFreeRoundsInfo = new PlayerFreeRoundsInfo(freeRounds.getId(), freeRounds.getBonus().getName(),
                                freeRounds.getAwardedOn(), freeRounds.getNoOfFreeRounds(), freeRounds.getFreeRoundsValidity(),
                                freeRounds.getBonusMoneyValidity(),freeRounds.getFreeRoundsBalance(), freeRounds.getGameProviders(), freeRounds.getGames(),freeRounds.getInGame(),freeRounds.getStatus(),freeRounds.getTotalWinning())
                        playerFreeRoundsInfos.add(playerFreeRoundsInfo);
                    }

                }
                //log.info playerFreeRoundsInfos.size();
            }
            render(view: "tab_playerFreeRounds", model: [params: params, playerFreeRoundsInstanceCount: results?.getTotalCount(), playerFreeRoundsInstanceList: playerFreeRoundsInfos, playerInstance: player])
        } catch (Exception e) {
            log.error("Caught Exception in PlayerBonusController.search()", e)
            return
        }
    }

    def details() {
        PlayerFreeRounds playerFreeRounds = PlayerFreeRounds.get(params.id)
        // List<Game> gamesList = FreeRoundsGameConfig.findAllByBonus(playerFreeRounds.bonus)
        // render(view: "_details", model: [playerFreeRoundsInstance: playerFreeRounds, gamesList: gamesList])
        render(view: "_details", model: [playerFreeRoundsInstance: playerFreeRounds])
    }

    /**
     *
     * @return
     */
    @Secured('ROLE_PERMISSION_PLAYER_BONUS_STATE_CHANGE')
    def cancel() {
        try {
            PlayerFreeRounds playerFreeRounds = PlayerFreeRounds.get(params.long('id'))
            playerFreeRoundsService.cancelFreeRound(playerFreeRounds, springSecurityService.getCurrentUser())
            redirect(action: "search", params: [id: playerFreeRounds.player.id], playerInstance: playerFreeRounds.player)
        } catch (Exception e) {
            log.error("Caught Exception in PlayerFreeRoundsController.cancel()", e)
            renderError(ReturnCodes.Code.ERROR, e.toString())
            return
        }
    }

    def closeGameRounds () {
        PlayerFreeRounds playerFreeRounds = PlayerFreeRounds.findById(params.id)
        if(playerFreeRounds == null) {
            renderError(ReturnCodes.Code.ERROR, "PLAYER FREE ROUNDS NOT FOUND")
            return
        }

        List<PlayerFreeRoundsGameRoundMap> playerFreeRoundsGameRoundMapList = PlayerFreeRoundsGameRoundMap.findAllByPlayerFreeRounds(playerFreeRounds)
        if(playerFreeRoundsGameRoundMapList.size() > 0) {
            for (PlayerFreeRoundsGameRoundMap playerFreeRoundsGameRoundMap : playerFreeRoundsGameRoundMapList) {
                gameRoundService.closeGameRound(playerFreeRoundsGameRoundMap.gameRound, 1)
                log.info("Closing game round ${playerFreeRoundsGameRoundMap.gameRound}")
                playerFreeRoundsService.detachGameRound(playerFreeRounds, playerFreeRoundsGameRoundMap.gameRound)
                log.info("Detaching game round ${playerFreeRoundsGameRoundMap.gameRound} and player bonus ${playerFreeRounds}")
            }
        }else{
            if(playerFreeRounds.inGame) {
                //ideally this should not occur, this is a special case where a player free rounds is stuck and there is no game round attached to it.
                playerFreeRoundsService.detachGameRound(playerFreeRounds, null)
            }
        }
        log.info("Closed games rounds if any")
        redirect(action: "search", params: [id: playerFreeRounds?.player?.id], playerInstance: playerFreeRounds?.player)
    }

    private def renderError(ReturnCodes.Code code, String reason) {
        //log.error("renderError(): API ERROR:" + code.toString() + ", reason:" + reason)
        render(status: code.httpCode(), contentType: 'application/json') {
            def result = [:]
            result.put('result', code.value())
            if (code != ReturnCodes.Code.OK) {
                result.put('error', code.description())
            }
            if (reason != null && reason != "null") {
                result.put('reason', reason)
            }
            return result
        }
    }

    /**
     *
     * @return
     */
    @Secured('ROLE_PERMISSION_PLAYER_BONUS_STATE_CHANGE')
    def retryEliteFreeSpinIOFailed() {
        log.info('retryEliteFreeSpinIOFailed with params:' + params)
        try {
            PlayerFreeRounds playerFreeRounds = PlayerFreeRounds.get(params.long('id'))
            playerFreeRoundsService.retryEliteFailedPlayerSpins(playerFreeRounds, springSecurityService.getCurrentUser())
            redirect(action: "search", params: [id: playerFreeRounds.player.id], playerInstance: playerFreeRounds.player)
        } catch (Exception e) {
            log.error("Caught Exception in PlayerFreeRoundsController.retryEliteFreeSpinIOFailed()", e)
            renderError(ReturnCodes.Code.ERROR, e.toString())
            return
        }
    }
}