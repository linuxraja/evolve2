package com.nektan.revolve.backoffice

import com.nektan.revolve.coreservices.GameRound
import com.nektan.revolve.coreservices.Operator
import com.nektan.revolve.coreservices.Player
import com.nektan.revolve.coreservices.Site
import com.nektan.revolve.coreservices.Transaction
import com.nektan.revolve.services.EventLogService
import grails.plugin.springsecurity.annotation.Secured
import grails.transaction.Transactional
import groovy.util.slurpersupport.NodeChild
import groovyx.net.http.HTTPBuilder


import static groovyx.net.http.ContentType.JSON
import static groovyx.net.http.Method.POST

@Secured(['ROLE_PERMISSION_TRANSACTIONS_GLOBAL_VIEW','ROLE_PERMISSION_TRANSACTIONS_PLAYER_ONLY'])
class GameRoundController {

    def paramService
    def springSecurityService
    def operatorService
    EventLogService eventLogService
    String ILLEGAL_ACCESS = "Illegal access. Unauthorized attempt to view game round details"


    def index() {}

    def beforeInterceptor = [action: this.&checkAuthorised, only: ['showDetails']]

    private checkAuthorised() {

        GameRound gameRound

        Operator currentLoggedInUser = springSecurityService.getCurrentUser();
        Set<Site> sites = new HashSet<Site>()

        if (params.id) {
         gameRound = GameRound.get(params.id)
           sites.add(gameRound?.gameSession?.site)
     }

        Set<Site> operatingSites = new HashSet<Site>()
        List operatorSites = operatorService.operatingSites(currentLoggedInUser)
        operatingSites.addAll(operatorSites)

        if (!operatingSites.containsAll(sites)) {
            flash.message = ILLEGAL_ACCESS
            redirect(action: 'search')
            return false
        }
    }


    def search() {
        log.info(params)

        /*if ( params.startAt?.length() == 0 && params.endAt?.length() == 0 ) {
            flash.message = "Please specify a start date, a end date or a date range!"
            render(view: view, model:[playerInstance: playerInstance])
            return
        }*/
        def results = find(params)
        render(view: "search", model: [params: params, gameRoundCount: results.getTotalCount(), gameRoundInstanceList: results, gameRoundInstanceCount: results.size()])
    }

    /**
     * Display selected gameRound
     * @return
     */
    @Secured(['ROLE_PERMISSION_TRANSACTIONS_GLOBAL_VIEW', 'ROLE_PERMISSION_TRANSACTIONS_PLAYER_ONLY'])
    def showDetails() {
        GameRound gameRound = GameRound.get(params.id)
        def c = Transaction.createCriteria()
        def transactions = c.list {
            eq("gameRound", gameRound)
        }
        def nyxData = null
        try {
            if(gameRound?.game?.rgs?.name == "NYX_RGS"){

                def http = new HTTPBuilder( paramService.getString("nyx.sapi.baseurl") )

                http.request(POST, JSON) { req ->
                    uri.path = 'auth/' // overrides any path in the default URL
                    send JSON, [ apiversion:'1.2', request:'authenticate' , username: paramService.getString("nyx.sapi.username"), password : paramService.getString("nyx.sapi.password")]
                    response.success = { resp, reader ->
                        if(resp.status == 200 && reader.RSP.rc == 0) {
                            http.request(POST) { anotherReq ->
                                uri.path = 'gamedetails/' // overrides any path in the default URL
                                send JSON, [apiversion: '1.2', request: 'getrounddetails', sapisession : reader.RSP.sapisession, ogsoperatorid: paramService.getInt("nyx.operatorid"), ogsgameid: gameRound.game.externalId, roundid :gameRound.externalRoundId]
                                response.success = { anotherResp, anotherReader ->
                                    log.info("NYX_SAPI_RESPONSE" + anotherResp)
                                    log.info(anotherReader)
                                    if(anotherResp.contentType == "application/xml"){
                                        if(anotherReader !=null ) {
                                            nyxData = groovy.xml.XmlUtil.serialize(anotherReader).replaceAll("html-data", "div")
                                        } else {
                                            nyxData = anotherReader
                                        }
                                    } else {
                                        nyxData = anotherReader
                                    }
                                }
                            }
                        } else {
                            log.info("SAPI API Call Failed (" + reader + ")")
                        }

                    }

                    // called only for a 404 (not found) status code:
                    response.'404' = { resp ->
                        println 'Not found'
                    }
                }
            }
        } catch (Exception e) {
            log.error("There is some error while fetching details ::" + e.getMessage())
            nyxData = "There is some problem while fetching NYX Data"
        }



        render(view: 'showDetails', model:[gameRoundInstance:gameRound, transactions: transactions, nyxData: nyxData])
    }

    def open() {
        GameRound gameRound = GameRound.findById(params.id)
        gameRound.status=0
        gameRound.endedAt = null
        gameRound.save(failOnError: true)
        render(text: "Successfully opened game round for round id $gameRound.id")
    }

    private List find(Map params) {

        Date startAt, endAt
        List gameId

        if (params.startAt && params.startAt.length() > 0) {
            startAt = Date.parse("yyyy-MM-dd HH:mm", params.startAt)
        }

        if (params.endAt != null && params.endAt.length() > 0) {
            endAt = Date.parse("yyyy-MM-dd HH:mm", params.endAt)
        }

        if (params.gameId ) {
            gameId = params.list('gameId')
        }

        if ( params.sort == null ) {
            params.sort = 'startedAt'
            params.order = 'desc'
        }

        def c = GameRound.createCriteria()
        def results = c.list(params) {
            if ( params.long('id') > 0 ) eq("id", params.long('id') )
            if ( startAt ) ge("startedAt", startAt )
            if ( endAt ) lt("startedAt", endAt )
            if ( params.'externalGameRoundId'?.length() > 0) eq("externalRoundId",params.'externalGameRoundId')

            if ( gameId ) {
                'in' ("game.id", gameId.collect { Long.parseLong( it )})
            }
        }
        return results
    }
}
