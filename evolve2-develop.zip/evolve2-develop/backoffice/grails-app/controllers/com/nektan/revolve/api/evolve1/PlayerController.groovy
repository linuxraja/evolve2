package com.nektan.revolve.api.evolve1

import com.nektan.revolve.api.APIReturnCode
import com.nektan.revolve.api.AccountValidationType
import com.nektan.revolve.api.BonusRewardType
import com.nektan.revolve.api.DocumentVerificationStatus
import com.nektan.revolve.api.RGSName
import com.nektan.revolve.api.RegistrationProperties
import com.nektan.revolve.api.elite.EliteFreeSpinGetBalanceResponse
import com.nektan.revolve.api.gamstop.GamstopRequest
import com.nektan.revolve.api.gamstop.GamstopUtil
import com.nektan.revolve.api.quickfire.QuickFireFreeSpinBundledGamesHolder
import com.nektan.revolve.api.quickfire.QuickFireFreeSpinGetAvailableFreeGamesResponse
import com.nektan.revolve.api.quickfire.QuickFireFreeSpinOfferInstancesHolder
import com.nektan.revolve.coreservices.BonusLangName
import com.nektan.revolve.coreservices.Country
import com.nektan.revolve.coreservices.FreeRoundsGameConfig
import com.nektan.revolve.coreservices.Game
import com.nektan.revolve.coreservices.Note
import com.nektan.revolve.coreservices.NoteType
import com.nektan.revolve.coreservices.Operator
import com.nektan.revolve.coreservices.Param
import com.nektan.revolve.coreservices.PaymentMethodChangeThreshold
import com.nektan.revolve.coreservices.PlayerFreeRounds
import com.nektan.revolve.coreservices.PlayerStatus
import com.nektan.revolve.coreservices.QuickfireGameConfig
import com.nektan.revolve.coreservices.TransactionSubtype
import com.nektan.revolve.coreservices.TransactionType
import com.nektan.revolve.dto.AddressDTO
import com.nektan.revolve.dto.AmountDetailsDTO
import com.nektan.revolve.dto.BonusByPaymentMethodsDTO
import com.nektan.revolve.dto.BonusLangNameDTO
import com.nektan.revolve.dto.EligibleBonusDetailsDTO
import com.nektan.revolve.dto.EligibleBonusPayoutDetailsDTO
import com.nektan.revolve.dto.EligibleBonusRespDTO
import com.nektan.revolve.dto.EligibleFreeRoundDetailsDTO
import com.nektan.revolve.dto.EligibleFreeRoundPayoutDetailsDTO
import com.nektan.revolve.dto.PlayerCommunicationDTO
import com.nektan.revolve.dto.PlayerEligibleBonusDTO
import com.nektan.revolve.dto.PlayerPropEvaluationRespDTO
import com.nektan.revolve.dto.SMSValidationDetailsDTO
import com.nektan.revolve.dto.WithdrawbleAmountDetailsDTO
import com.nektan.revolve.dto.BalanceDTO
import com.nektan.revolve.dto.BonusDetailsDTO
import com.nektan.revolve.dto.FreeRoundDetailsDTO
import com.nektan.revolve.dto.ProfileDetailsDTO
import com.nektan.revolve.exception.ValidationException
import com.nektan.revolve.extras.CalendarUtility
import com.nektan.revolve.services.EliteFreeSpinsService
import com.nektan.revolve.services.NotesService
import com.nektan.revolve.services.ParamService
import com.nektan.revolve.services.QuickFireFreeSpinsService
import com.nektan.revolve.util.JsonUtils
import com.nektan.revolve.services.SiteService
import com.nektan.revolve.util.Strings
import grails.plugins.rest.client.RestBuilder
import grails.plugins.rest.client.RestResponse
import groovy.json.JsonBuilder
import org.apache.commons.validator.routines.EmailValidator
import org.apache.commons.lang.StringUtils;
import com.nektan.revolve.dto.FreeSpinDetailsDTO
import com.nektan.revolve.extras.Utils

import com.nektan.revolve.api.EvolveConstants
import com.nektan.revolve.api.v1.ApiController
import com.nektan.revolve.coreservices.Account
import com.nektan.revolve.coreservices.Player
import com.nektan.revolve.coreservices.SecurityQuestion
import com.nektan.revolve.coreservices.Session
import com.nektan.revolve.coreservices.Bonus
import com.nektan.revolve.coreservices.Site;
import com.nektan.revolve.api.BonusType
import com.nektan.revolve.api.PlayerRewardStatus
import com.nektan.revolve.api.RewardStatus
import com.nektan.revolve.coreservices.PlayerBonus
import com.nektan.revolve.coreservices.PromoCodeEligible
import com.nektan.revolve.services.AccountService
import com.nektan.revolve.services.PlayerService
import com.nektan.revolve.services.PlayerBonusService
import com.nektan.revolve.services.SessionService
import com.nektan.revolve.services.LoyaltyService
import com.nektan.revolve.services.BonusService
import com.nektan.revolve.coreservices.RGS
import com.nektan.revolve.coreservices.Currency

import grails.plugin.springsecurity.annotation.Secured
import grails.converters.JSON
import org.codehaus.groovy.grails.web.json.JSONObject
import org.springframework.http.HttpStatus
import wslite.soap.SOAPClient

import javax.servlet.http.Cookie
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.regex.Matcher
import java.util.regex.Pattern

import static grails.async.Promises.task

@Secured(['permitAll'])
class PlayerController extends ApiController implements EvolveConstants {

    public static namespace = 'evolve1'
    def client
    ParamService paramService
    def springSecurityService
    def playerFreeRoundsService
    def transactionService
    def playerLoyaltyPointsService
    QuickFireFreeSpinsService quickFireFreeSpinsService
    EliteFreeSpinsService eliteFreeSpinsService
    def playerPromotionService

    static allowedMethods = [
            initialise                     : 'GET',
            result                         : 'POST',
            depositTermsAndConditions      : 'POST',
            termsAndConditions             : 'POST',
            updatePrivacyPolicy            : 'POST',
            getPaymentMethodChangeThreshold: 'GET',
            emailCheck                     : 'POST',
            setRealityCheckLimit           : ['GET', 'POST', 'DELETE'],
            bonusOptOut                    : 'POST',
            getPlayerEligibleDepositBonus  : 'GET',
            getPlayerEligibleDepositBonusForBonusCode  : 'POST',
            changeWithdrawalConfirmation : 'POST',
            optInToPromotion : 'POST',
            isBonusCodeValid : 'POST'

    ]

    static responseFormats = ['json']

    SessionService sessionService
    AccountService accountService
    PlayerService playerService
    LoyaltyService loyaltyService
    PlayerBonusService playerBonusService
    BonusService bonusService
    SiteService siteService
    NotesService notesService


    /**
     * Register a new player into the account system
     * @return
     */
    def register() {
        log.info("Player Rigistration payload :: " + request.JSON)
        //def payload = request.JSON
        Map<Enum, String> retMap
        try {
            retMap = JsonUtils.convertRegistrationJsonToMap(request.JSON)
            log.debug("RetMap:::" + retMap)
        } catch (ValidationException _exp) {
            log.error("ValidationException in Player Rigistration :: " + _exp.getMessage())
            createErrorResponse(APIReturnCode.INVALID_PARAMS)
            return
        }
        Site site = siteService.getSite(retMap.get(RegistrationProperties.accountSystemTag))
        if (site == null) {
            log.error "Player creation failed: Site not found. email:${retMap.get(RegistrationProperties.email)},mobileNumber:${retMap.get(RegistrationProperties.mobilePhoneNumber)}," +
                    "username:${retMap.get(RegistrationProperties.email)},firstname:${retMap.get(RegistrationProperties.firstName)},lastname:${retMap.get(RegistrationProperties.lastName)}," +
                    "postalcode:${retMap.get(RegistrationProperties.postCode)},dateOfBirth:${retMap.get(RegistrationProperties.dateOfBirth)},site:${retMap.get(RegistrationProperties.accountSystemTag)}"
            createErrorResponse(APIReturnCode.INVALID_SITE_ID)
            return
        }
        // Registration process implementation based on player property weightage
        PlayerPropEvaluationRespDTO result = playerService.playerRegistrationProcess(retMap)

        if (result.isDuplicatePlayer) {
            log.error "Player creation failed: found duplicate player. email:${retMap.get(RegistrationProperties.email)},mobileNumber:${retMap.get(RegistrationProperties.mobilePhoneNumber)}," +
                    "username:${retMap.get(RegistrationProperties.email)},firstname:${retMap.get(RegistrationProperties.firstName)},lastname:${retMap.get(RegistrationProperties.lastName)}," +
                    "postalcode:${retMap.get(RegistrationProperties.postCode)},dateOfBirth:${retMap.get(RegistrationProperties.dateOfBirth)},site:${retMap.get(RegistrationProperties.accountSystemTag)}"
            createErrorResponse(APIReturnCode.PLAYER_DUPLICATE_CHECK_ERROR)
            return
        }

        /*if (result.returnCode == ReturnCodes.Code.EMAIL_USED || result.returnCode == ReturnCodes.Code.USERNAME_USED) {
            log.error "Player creation failed: email or username already exists. email:${retMap.get(RegistrationProperties.email)},mobileNumber:${retMap.get(RegistrationProperties.mobilePhoneNumber)}," +
                    "username:${retMap.get(RegistrationProperties.email)},firstname:${retMap.get(RegistrationProperties.firstName)},lastname:${retMap.get(RegistrationProperties.lastName)}," +
                    "postalcode:${retMap.get(RegistrationProperties.postCode)},dateOfBirth:${retMap.get(RegistrationProperties.dateOfBirth)},site:${retMap.get(RegistrationProperties.accountSystemTag)}"
            render(status: 401, contentType: 'application/json') {
                createErrorJSONResponse("ValidationError", g.message(code: 'evolve1.lobby.emailinuse'))
            }
            return
        }*/

        if (result.returnCode == APIReturnCode.INVALID_COUNTRY_CURRENCY || result.returnCode == APIReturnCode.INVALID_COUNTRY
                || result.returnCode == APIReturnCode.INVALID_CURRENCY) {
            log.error "Player creation failed: Country or Currency invalid. email:${retMap.get(RegistrationProperties.email)},mobileNumber:${retMap.get(RegistrationProperties.mobilePhoneNumber)}," +
                    "username:${retMap.get(RegistrationProperties.email)},firstname:${retMap.get(RegistrationProperties.firstName)},lastname:${retMap.get(RegistrationProperties.lastName)}," +
                    "postalcode:${retMap.get(RegistrationProperties.postCode)},dateOfBirth:${retMap.get(RegistrationProperties.dateOfBirth)},site:${retMap.get(RegistrationProperties.accountSystemTag)}, countryCode:${retMap.get(RegistrationProperties.countryCode)},currencyCode: ${retMap.get(RegistrationProperties.currencyCode)}"
            createErrorResponse(result.returnCode)
            return
        }

        if (result.returnCode == APIReturnCode.GAMSTOP_SELF_EXCLUDED) {
            log.error "Player creation failed: Gamstop self excluded player email:${retMap.get(RegistrationProperties.email)}," +
                    "username:${retMap.get(RegistrationProperties.email)},firstname:${retMap.get(RegistrationProperties.firstName)}," +
                    "lastname:${retMap.get(RegistrationProperties.lastName)}," +
                    "postalcode:${retMap.get(RegistrationProperties.postCode)},dateOfBirth:${retMap.get(RegistrationProperties.dateOfBirth)}"
            createErrorResponse(result.returnCode)
            return
        }

        if (result.returnCode == APIReturnCode.TOO_YOUNG) {
            log.error "Player must be at least ${result.player.country.minAge} years old. email:${retMap.get(RegistrationProperties.email)},mobileNumber:${retMap.get(RegistrationProperties.mobilePhoneNumber)}," +
                    "username:${retMap.get(RegistrationProperties.email)},firstname:${retMap.get(RegistrationProperties.firstName)},lastname:${retMap.get(RegistrationProperties.lastName)}," +
                    "postalcode:${retMap.get(RegistrationProperties.postCode)},dateOfBirth:${retMap.get(RegistrationProperties.dateOfBirth)},site:${retMap.get(RegistrationProperties.accountSystemTag)}, countryCode:${retMap.get(RegistrationProperties?.countryCode)},currencyCode: ${retMap.get(RegistrationProperties?.currencyCode)}"
            String[] paramValues = ["${result.player.country.minAge}"]
            createDynamicErrorResponse(APIReturnCode.TOO_YOUNG, "Player must be at least {0} years old.",paramValues)
            return
        }

        if (result.returnCode == APIReturnCode.OK) {
            log.debug "Player ${result.player.userName} created -> $result.player.validationUUID"
            if(!result.getIsFraud() && !result.getIsFailedAML()){
                playerService.triggerRegistrationEvent(result.player, retMap.get(RegistrationProperties.bonusCode),retMap.get(RegistrationProperties.choiceCode))
            }
            result.player.playerExtra.userAgentDeviceString = request.getHeader("User-Agent")
            def authenticationResult =
                    sessionService.authenticatePlayer(
                            result.player.userName, retMap.get(RegistrationProperties.password), getIp(request),
                            retMap.get(RegistrationProperties.platformTag), retMap.get(RegistrationProperties.accountSystemTag),
                            request.getHeader("User-Agent"), true,false
                    )

            String trackingCode = null
            if (("app").equalsIgnoreCase(retMap.get(RegistrationProperties.platformTag))) {
                trackingCode = retMap.get(RegistrationProperties.tcode)
            } else {
                trackingCode = g.cookie(name: "trackingCode")
            }
            if (trackingCode) {
                result.player.referrerTag = trackingCode
                result.player.save(flush: true)
            }

            if (authenticationResult.returnCode == APIReturnCode.OK) {
                log.debug "Player ${result.player.userName} authenticated"
                Session session = sessionService.getSession(authenticationResult.token)

                setEvolveCookies(request,response, session)

                /*render(status: 200, contentType: 'application/json') {
                    createPlayerProfileJSONResponse(session, true)
                }*/

                //Need all these below because once async task is invoked then hibernate session is not available in the async call
                String username = "NK-"+ result?.player?.id
                String platform = isMobile() ? "M" : "W"
                String language = result?.player?.site?.lang != null ? site.lang : "en"
                String currency = result?.player?.currency?.iso
                String country = result?.player?.country?.iso3
                String externalToken = session?.token
                //String skinCode = result?.player?.site?.shortName
                String skinCode = paramService.getString("elite.site.id");

                //Asynchronous Task
                def promise = task {
                    log.info("Asynchronous task started : Invoking Elite system to process player login "+username)
                    //Thread.sleep(5000)
                    Map<String,String> jsonParams = new HashMap();
                    jsonParams.put("username",username)
                    jsonParams.put("platform",platform)
                    jsonParams.put("language",language)
                    jsonParams.put("currency",currency)
                    jsonParams.put("country",country)
                    jsonParams.put("externalToken",externalToken)
                    jsonParams.put("skinCode",skinCode)
                    playerService.invokeEliteSystemForLogin(jsonParams)
                    return "Asynchronous task completed successfully for elite with player username " + "${username}"

                }
                //TODO : Not working : null is logged in log but good point is that async functipnality is working
                /* if(promise!=null) {
                     promise.onError { Throwable err ->
                         log.info("An error occured ${err.message}")
                     }
                     promise.onComplete { result ->
                         log.info("Promise returned $result")
                     }
                 }else{
                     log.info("Promise task status unknown")
                 }*/

                createPlayerRegistrationJSONResponse(session)
                return
            } else {
                log.error "Player authentication failed: ${authenticationResult.returnCode}"
                createErrorResponse(authenticationResult.returnCode)
                return
            }
        } else {
            String errors = ""
            Map<Integer,String> errorMap = new HashMap<Integer,String>()
            g.eachError(bean: result.player) {
                if(StringUtils.isNumeric("${g.message(error: it)}")) {
                    try {
                        errorMap.put(Integer.parseInt("${g.message(error: it)}"), it.field)
                    } catch (Exception e) {
                        log.error("Exception in Register: " + e.getMessage())
                        // e.printStackTrace()
                    }
                }
                errors += "${g.message(error: it)}\n"
            }
            log.info "Player creation failed . email: ${retMap.get(RegistrationProperties.email)},username:${retMap.get(RegistrationProperties.email)},mobileNumber:${retMap.get(RegistrationProperties.mobilePhoneNumber)}," +
                    "firstName:${retMap.get(RegistrationProperties.firstName)},lastname:${retMap.get(RegistrationProperties.lastName)},postalCode:${retMap.get(RegistrationProperties.postCode)}," +
                    "dateOfBirth:${retMap.get(RegistrationProperties.dateOfBirth)},Site:${retMap.get(RegistrationProperties.accountSystemTag)},countryCode: ${retMap.get(RegistrationProperties.countryCode)}, " +
                    "currencyCode:${retMap.get(RegistrationProperties.currencyCode)}, ${errors}"

            createMultipleErrorResponse(APIReturnCode.MULTIPLE_ERROR_TYPE,g.message(code: 'evolve1.lobby.registrationfailed'),errorMap)
            return
        }
    }

    /**
     * Updates Player mobile number
     * @param mobileNumber
     */
    def updateMobileNumber() {
        def payload = request.JSON
        log.debug( "updateMobileNumber.." + payload."mobileNumber")
        String mobileNumber = payload."mobileNumber"?.trim();
        if (StringUtils.isBlank(mobileNumber)) {
            createErrorResponse(APIReturnCode.MOBNUM_NOT_VALID)
            return
        }
        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }

        if (mobileNumber.equals(session.player.mobileNumber)) {
            createErrorResponse(APIReturnCode.MOBNUM_SAME_AS_EXIST)
            return
        }
        if (session.player.site.smsValidationEnabled && session.player.country.smsValidationEnabled) {
            String iso2LangCode = payload?.lang
            PlayerPropEvaluationRespDTO result = playerService.updatePlayerMobileNumber(session.player, mobileNumber,iso2LangCode);
            if (result.returnCode == APIReturnCode.OK) {
                log.debug "Player ${result.player.userName} mobile number updated successfully to ${result.player.mobileNumber}."
                render(status: 200, contentType: 'application/json') {
                    [
                            g.message(code: 'evovle1.lobby.mobnum.update.succ.msg')
                    ]
                }
                return
            } else if (result.returnCode == APIReturnCode.UPDATION_FAILED) {
                createErrorResponse(APIReturnCode.MOBNUM_NOT_VALID)
                return
            } else {
                createErrorResponse(APIReturnCode.PLAYER_DUPLICATE_CHECK_ERROR)
                return
            }
        }
        createErrorResponse(APIReturnCode.SMSPIN_VALIDATION_NOT_ENABLED)
    }

    /**
    *
     * */
    def validateSMS() {
        def payload = request.JSON
        String smsPin = payload."smsPin"?.trim()
        if (StringUtils.isBlank(smsPin)) {
            createErrorResponse(APIReturnCode.SMSPIN_NOT_VALID)
            return
        }

        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }

        if (session.player.site.smsValidationEnabled && session.player.country.smsValidationEnabled) {
            if (StringUtils.isBlank(session.player.smsValidationCode)) {
                log.error("validateSMS ${session.player.userName} does not have SMS Pin.")
                createErrorResponse(APIReturnCode.SMSPIN_NOT_VALID)
                return
            }
            if (session.player.isSmsValidated) {
                /*render(status: 200, contentType: 'application/json') {
                    [
                            "isSmsValidated": session.player.isSmsValidated
                    ]
                }*/
                createSMSValidationJSONResponse(session)
                return
            }

            String bonusCode = null;
            if(StringUtils.isNotBlank(payload."bonusCode")) {
                bonusCode  = payload."bonusCode"?.trim()
            }
            String choiceCode = null;
            if(StringUtils.isNotBlank(payload."choiceCode")) {
                choiceCode  = payload."choiceCode"?.trim()
            }
            PlayerPropEvaluationRespDTO result = playerService.validateSMS(session.player, smsPin, bonusCode, choiceCode)

            if (result.returnCode == APIReturnCode.OK) {
                log.debug "Player ${result.player.userName} sms validated successfully."
                createSMSValidationJSONResponse(session)
                return
            } else if (result.returnCode == APIReturnCode.SMSPIN_NOT_VALID) {
                createErrorResponse(APIReturnCode.SMSPIN_NOT_VALID)
                return
            } else {
                createErrorResponse(APIReturnCode.PLAYER_DUPLICATE_CHECK_ERROR)
                return
            }
        }
        createErrorResponse(APIReturnCode.SMSPIN_VALIDATION_NOT_ENABLED)
    }

    def resendSMS() {
        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }
        String iso2LangCode = request?.JSON?.lang
        if (session.player.site.smsValidationEnabled && session.player.country.smsValidationEnabled) {
            PlayerPropEvaluationRespDTO result = playerService.resendSMS(session.player,iso2LangCode);
            if (result.returnCode == APIReturnCode.OK) {
                log.debug "Player ${result.player.userName} SMS has been resent successfully to ${result.player.mobileNumber}."
                render(status: 200, contentType: 'application/json') {
                    [
                            "SMS has been resent successfully."
                    ]
                }
                return
            } else if (result.returnCode == APIReturnCode.UPDATION_FAILED) {
                createErrorResponse(APIReturnCode.SMSPIN_UPDATION_FAILED)
                return
            } else {
                createErrorResponse(APIReturnCode.PLAYER_DUPLICATE_CHECK_ERROR)
                return
            }
        }
        createErrorResponse(APIReturnCode.SMSPIN_VALIDATION_NOT_ENABLED)
    }

    /**
     * Verify players email
     */
    def verifyEmail() {
        String verifyToken = params.token
        String accountSystem = params.accountSystemTag

        def result = playerService.validateEmailToken(accountSystem, verifyToken)

        if (result.returnCode == APIReturnCode.OK) {
            log.debug("verfication successfull")
        } else {
            log.debug("verification failed: $result.errors ")
        }
        redirect(url: result.site.url)
    }

    /**
     * Login from the Evolve1 Lobby
     * @return the Player JSON Details
     */
    def login() {

        def payload = request.JSON
        String principle = payload."login.principle"?.trim()
        String password = payload."login.password"?.trim()
        String platformTag = payload."login.platformTag"?.trim()
        String accountSystemTag = payload."login.accountSystemTag"?.trim()

        def result = sessionService.authenticatePlayer(principle, password, getIp(request), platformTag, accountSystemTag, request.getHeader("User-Agent"), false,true)

        if (result.returnCode == APIReturnCode.OK) {

            Session session = sessionService.getSession(result.token)
            setEvolveCookies(request,response, session)

            result.player.playerExtra.userAgentDeviceString = request.getHeader("User-Agent")
            result.player.save()
            /*render(status: 200, contentType: 'application/json') {
                createPlayerProfileJSONResponse(session, false)
            }*/

            ProfileDetailsDTO profileDetailsDTO = createPlayerLoginJSONResponse(session)
            respond profileDetailsDTO
            return
        }

        if (result.returnCode == APIReturnCode.PLAYER_NOT_PERMITTED) {
            createErrorResponse(APIReturnCode.PLAYER_NOT_PERMITTED)
            return
        }

        if (result.returnCode == APIReturnCode.GAMSTOP_SELF_EXCLUDED) {
            createErrorResponse(APIReturnCode.GAMSTOP_SELF_EXCLUDED)
            return
        }

        createErrorResponse(APIReturnCode.PLAYER_NOT_FOUND)
    }

    /**
     * Email front-end validation
     */
    def emailCheck() {
        try {
            def payload = request.JSON
            String[] requiredParams = ["email", "accountSystemTag"]
            String paramError = checkParams(payload, requiredParams)

            if (paramError != null) {
                createDynamicErrorResponse(APIReturnCode.INVALID_PARAMS,paramError,null)
                return
            }
            String email = payload.email


            EmailValidator em = EmailValidator.getInstance()


            if (StringUtils.isBlank(email)) {
                createErrorResponse(APIReturnCode.EMAIL_ID_NULL)
                return
            } else if (!em.isValid(email)) {
                createErrorResponse(APIReturnCode.INVALID_EMAIL_ID)
                return
            }
            String accountSystem = payload.accountSystemTag
            if (StringUtils.isBlank(accountSystem)) {
                createErrorResponse(APIReturnCode.SITE_ID_NULL)
                return
            }

            Site site = Site.findByShortName(accountSystem.toLowerCase())
            if (site == null) {
                createErrorResponse(APIReturnCode.INVALID_SITE_ID)
                return
            }
            def result = Player.countByEmailAndSite(email, site)
            def used = ["used": false];
            if (result > 0) {
                used = ["used": true];
            }

            render(status: 200, contentType: 'application/json') {
                used
            }
        } catch (Exception e) {
            createErrorResponse(APIReturnCode.ERROR)
        }
    }

    def getAllBonusDetails() {
        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }

        Player player = session.player
        List<PlayerBonus> playerBonuses = PlayerBonus.findAllByPlayerAndStatusInListAndAwardedAmountGreaterThan(player,  PlayerRewardStatus
                .getActiveTypes()*.id, BigDecimal.ZERO)
        if (null != playerBonuses && playerBonuses.size() > 0) {
            List<BonusDetailsDTO> bonusDetailsDTOS = new ArrayList<BonusDetailsDTO>()
            for (PlayerBonus playerBonus : playerBonuses) {
                BigDecimal wageringContribution = playerBonus.getScaledPlayThroughRequired()
                BigDecimal wagerRequired = wageringContribution.subtract(playerBonus.getScaledPlayThroughReached())
                wagerRequired = (wagerRequired.compareTo(BigDecimal.ZERO) <= 0) ? BigDecimal.ZERO : wagerRequired
                List<String> allowedGamesList = new ArrayList<String>()
                if (playerBonus.bonus.rewardType == BonusRewardType.BonusFunds.id && playerBonus.bonus.bonusType != BonusType.Manual.id) {
                    for (FreeRoundsGameConfig freeRoundsGameConfig : playerBonus.bonus.freeRoundsGameConfig) {
                        allowedGamesList.add(freeRoundsGameConfig.getGame().getShortName())
                    }
                }
                BigDecimal minDeposit = null
                BigDecimal maxDeposit = null
                BigDecimal depositPercentage = null
                Integer noOfFreeRounds = null
                Integer depositCount = null
                Bonus bonus = playerBonus.bonus
                if (bonus.bonusType == BonusType.Deposit.id || bonus.bonusType == BonusType.DepositOverTimePeriod.id) {
                    minDeposit = playerBonus?.bonusDepConfig?.minDeposit
                    maxDeposit = playerBonus?.bonusDepConfig?.maxDeposit
                    depositPercentage = playerBonus?.bonusDepConfig?.depositPercent
                    noOfFreeRounds = playerBonus?.bonusDepConfig?.noOfFreeRounds
                    depositCount = player?.playerExtra?.depositCount
                } else if (bonus.rewardType == BonusRewardType.FreeRounds.id && (bonus.bonusType == BonusType.AccountValidation.id || bonus.bonusType == BonusType.Login.id || bonus.bonusType == BonusType.Registration.id
                        || bonus.bonusType == BonusType.Bulk.id || bonus.bonusType == BonusType.Manual.id)) {
                    noOfFreeRounds = bonus.noOfFreeRounds
                }
                Map<String, String> languageDescMap = this.createBonusLangNameMap(playerBonus.bonus, player.getCurrency(), playerBonus.awardedAmount, noOfFreeRounds, minDeposit, maxDeposit, depositPercentage,depositCount);
                bonusDetailsDTOS.add(new BonusDetailsDTO(playerBonus.awardedAmount,
                        new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(playerBonus.expires),
                        ((PlayerRewardStatus) PlayerRewardStatus.getStatusType(playerBonus.status)).name,
                        ((BonusType) BonusType.getBonusType(playerBonus.bonus.bonusType)).name,
                        playerBonus.playerDescription, playerBonus.internalDescription,allowedGamesList,wageringContribution,wagerRequired,playerBonus.getScaledPlayThroughReached(),
                        languageDescMap, String.valueOf(playerBonus.bonus.identifier)))

            }
            def builder = new JsonBuilder()
            def root = builder {
                bonusDetails(
                        bonusDetailsDTOS.collect { bonusDetailsDTO ->
                            [
                                    "id"                        : bonusDetailsDTO.id,
                                    "name"                      : bonusDetailsDTO.name,
                                    "description"               : bonusDetailsDTO.description,
                                    "amount"                    : bonusDetailsDTO.amount,
                                    "status"                    : bonusDetailsDTO.status,
                                    "event"                     : bonusDetailsDTO.event,
                                    "expires"                   : bonusDetailsDTO.expires,
                                    "totalWageringContribution" : bonusDetailsDTO.totalWageringContribution,
                                    "wagerContributionRequired" : bonusDetailsDTO.wageringContributionRequired,
                                    "wagerContributionReached"  : bonusDetailsDTO.wageringContributionReached,
                                    "allowedGames"              : bonusDetailsDTO.allowedGames,
                                    "language_name_map"         : bonusDetailsDTO.languageNameMap.collect { languageNameMapRec ->
                                        [
                                                "${languageNameMapRec.key}": "${languageNameMapRec.value}"
                                        ]
                                    }
                            ]
                        }
                )
            }
            render(status: 200, text: builder.toPrettyString(), contentType: "application/json", encoding: "UTF-8")
        } else {
            render(status: 200, contentType: 'application/json')
        }
    }

    def getBonusDetails() {
        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }

        Player player = session.player
        PlayerBonus playerBonus = PlayerBonus.findByPlayerAndStatus(player, PlayerRewardStatus.Active.id)
        if (null != playerBonus) {
            BigDecimal wageringContribution = playerBonus.getScaledPlayThroughRequired()
            BigDecimal wagerRequired = wageringContribution.subtract(playerBonus.getScaledPlayThroughReached())
            wagerRequired = (wagerRequired.compareTo(BigDecimal.ZERO) <= 0) ? BigDecimal.ZERO : wagerRequired
            List<String> allowedGamesList = new ArrayList<String>()
            if(playerBonus.bonus.rewardType == BonusRewardType.BonusFunds.id && playerBonus.bonus.bonusType != BonusType.Manual.id){
                for(FreeRoundsGameConfig freeRoundsGameConfig : playerBonus.bonus.freeRoundsGameConfig) {
                    allowedGamesList.add(freeRoundsGameConfig.getGame().getShortName())
                }
            }
            BigDecimal minDeposit = null
            BigDecimal maxDeposit = null
            BigDecimal depositPercentage = null
            Integer noOfFreeRounds = null
            Integer depositCount = null
            Bonus bonus = playerBonus.bonus
            if(bonus.bonusType == BonusType.Deposit.id || bonus.bonusType == BonusType.DepositOverTimePeriod.id){
                minDeposit = playerBonus?.bonusDepConfig?.minDeposit
                maxDeposit = playerBonus?.bonusDepConfig?.maxDeposit
                depositPercentage = playerBonus?.bonusDepConfig?.depositPercent
                noOfFreeRounds = playerBonus?.bonusDepConfig?.noOfFreeRounds
                depositCount = player?.playerExtra?.depositCount
            } else if(bonus.rewardType == BonusRewardType.FreeRounds.id && (bonus.bonusType == BonusType.AccountValidation.id || bonus.bonusType == BonusType.Login.id || bonus.bonusType == BonusType.Registration.id
                    || bonus.bonusType == BonusType.Bulk.id || bonus.bonusType == BonusType.Manual.id)){
                noOfFreeRounds = bonus.noOfFreeRounds
            }
            Map<String, String> languageDescMap = this.createBonusLangNameMap(playerBonus.bonus, player.getCurrency(), playerBonus.awardedAmount, noOfFreeRounds, minDeposit, maxDeposit, depositPercentage,depositCount);
            render(status: 200, contentType: 'application/json') {
                ["totalWageringContribution": wageringContribution, "wagerContributionRequired": wagerRequired, "wagerContributionReached": playerBonus.getScaledPlayThroughReached(),
                 "name": playerBonus.playerDescription, "description": playerBonus.internalDescription, "allowedGames": allowedGamesList,
                 "language_name_map":
                         languageDescMap.collect {  languageDescMapRec ->
                             [
                                     "${languageDescMapRec.key}" : "${languageDescMapRec.value}"
                             ]
                         },
                 "id": playerBonus.bonus.identifier
                ]
            }
        } else {
            render(status: 200, contentType: 'application/json')
        }
    }

    def cancelAllBonuses() {
        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }

        ArrayList<PlayerBonus> activeBonuses = PlayerBonus.findAllByPlayerAndStatusInListAndAwardedAmountGreaterThan(session.player,
                PlayerRewardStatus.getActiveTypes()*.id, BigDecimal.ZERO)
        Operator operator = Operator.findByUsername("nektan")
        NoteType noteType = NoteType.findByShortName(NoteType.SHORT_NAMES.BONUS_OPTOUT)
        if (null != activeBonuses && activeBonuses.size() > 0) {
            activeBonuses.each { playerbonus ->
                String text = "$session.player requested to cancel bonus $playerbonus.id"
                playerBonusService.updateBonusStatus(playerbonus, PlayerRewardStatus.Cancelled, operator, false)
                notesService.create(session.player, operator, noteType, text, Note.SEVERITY_NORMAL, null)
            }
            render(status: 200, contentType: 'application/json')
        } else {
            log.info("no active Bonuses")
            render(status: 200, contentType: 'application/json')
        }
    }

    /**
     * Method to cancel all bonuses of player if player select bonusOptout option from his profile.
     *
     * @param sessio
     * @param bonusOptOut
     *
     * */
    def bonusOptOut() {
        def payload = request.JSON
        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }

        Boolean bonusOptOut = payload.bonusOptOut
        if (null != bonusOptOut) {
            boolean playerBonusOptOutOldValue = session.player.bonusOptOut
            session.player.bonusOptOut = bonusOptOut.booleanValue()
            session.player.save()
            if (session.player.bonusOptOut && !playerBonusOptOutOldValue) {
                playerBonusService.cancelAllBonuses(session.player, springSecurityService.getCurrentUser())
                playerFreeRoundsService.cancelAllFreeRounds(session.player, springSecurityService.getCurrentUser())

                if(playerLoyaltyPointsService.cancelLoyaltyPoints(session.player,TransactionType.SHORT_NAME.loyaltyDebit,TransactionSubtype.SHORT_NAME.bonusOptOut,"as player is bonus opted out.")){
                    notesService.create(session.player, Operator.findByUsername("nektan"), NoteType.findByShortName(NoteType.SHORT_NAMES.BONUS_OPTOUT),
                             "Loyalty Points cancelled as player has opted out of bonus", Note.SEVERITY_LOW, null, false)
                }
            }
            Operator operator = Operator.findByUsername("nektan")
            NoteType noteType = NoteType.findByShortName(bonusOptOut.booleanValue() ? NoteType.SHORT_NAMES.BONUS_OPTOUT : NoteType.SHORT_NAMES.BONUS_OPTIN)
            String text = "Bonus Opted "+(bonusOptOut.booleanValue() ? "out" : "in")
            notesService.create(session.player, operator, noteType, text, Note.SEVERITY_NORMAL, null, false)
            render(status: 200, contentType: 'application/json')
        } else {
            log.info("Failed as bonusOptOut:${payload.bonusOptOut}")
            createErrorResponse(APIReturnCode.INVALID_PARAMS)
        }
    }


    /**
     * Method to cancel all active bonuses of player depending on player status.
     *
     * @param session
     */
    def cancelActiveBonus() {

        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }

        ArrayList<PlayerBonus> activeBonuses = PlayerBonus.findAllByPlayerAndStatusAndAwardedAmountGreaterThan(session.player,
                PlayerRewardStatus.Active.id, BigDecimal.ZERO)
        Operator operator = Operator.findByUsername("nektan")
        NoteType noteType = NoteType.findByShortName(NoteType.SHORT_NAMES.BONUS_OPTOUT)
        if (null != activeBonuses && activeBonuses.size() > 0) {
            activeBonuses.each { playerbonus ->
                String text = "$session.player.userName:requested to cancel bonus $playerbonus.id"
                playerBonusService.updateBonusStatus(playerbonus, PlayerRewardStatus.Cancelled, operator, true)
                notesService.create(session.player, operator, noteType, text, Note.SEVERITY_NORMAL, null)
            }
            PlayerBonus playerNextActiveBonus = PlayerBonus.findByPlayerAndStatus(session.player, PlayerRewardStatus.Active.id)

            if (null != playerNextActiveBonus) {
                BigDecimal wageringContribution = playerNextActiveBonus.getScaledPlayThroughRequired()
                BigDecimal wagerRequired = wageringContribution.subtract(playerNextActiveBonus.getScaledPlayThroughReached())
                wagerRequired = (wagerRequired.compareTo(BigDecimal.ZERO) <= 0) ? BigDecimal.ZERO : wagerRequired
                render(status: 200, contentType: 'application/json') {
                    ["totalWageringContribution": wageringContribution, "wagerContributionRequired": wagerRequired, "wagerContributionReached": playerNextActiveBonus.getScaledPlayThroughReached(),
                     "name": playerNextActiveBonus.playerDescription, "description": playerNextActiveBonus.internalDescription, "id": playerNextActiveBonus?.bonus?.identifier]
                }

            } else {
                render(status: 200, contentType: 'application/json')
            }
        } else {
            log.info("no active Bonuses")
            render(status: 200, contentType: 'application/json')
        }
    }

    /**
     *  player free round details
     *
     */
    def getFreeSpinDetails() {

        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }

        //Getting the IGT freespin details
        List<FreeSpinDetailsDTO> igtFreeSpinDetailsLst = prepareIgtFreeSpinDetailsDTO(session)
        //Getting the Netent freespin details
        List<FreeSpinDetailsDTO> netentFreeSpinDetailsLst = prepareNetentFreeSpinsDetailsDTO(session)
        //Getting the Quickfire freespin details
        List<FreeSpinDetailsDTO> quickFireFreeSpinDetailsLst = prepareQuickFireFreeSpinsDetailsDTO(session)
        //Getting the Elite freespin details
        List<FreeSpinDetailsDTO> eliteFreeSpinDetailsLst = prepareEliteFreeSpinsDetailsDTO(session)
        //Initializing the final freespin details list
        List<FreeSpinDetailsDTO> freeSpinList = new ArrayList<>()
        //Adding igt freespin details to the final list
        if (igtFreeSpinDetailsLst) {
            freeSpinList.addAll(igtFreeSpinDetailsLst)
        }
        //Adding Netent freespin details to the final list
        if (netentFreeSpinDetailsLst) {
            freeSpinList.addAll(netentFreeSpinDetailsLst)
        }
        //Adding Quickfire freespin details to the final list
        if (quickFireFreeSpinDetailsLst) {
            freeSpinList.addAll(quickFireFreeSpinDetailsLst)
        }
        //Adding Elite freespin details to the final list
        if (eliteFreeSpinDetailsLst) {
            freeSpinList.addAll(eliteFreeSpinDetailsLst)
        }
        def builder = new JsonBuilder()
        def root = builder {
            freeSpinDetails(
                    freeSpinList.collect { freespin ->
                        [
                                "id": freespin.id,
                                "name": freespin.name,
                                "description": freespin.bonusDescription,
                                "game": freespin.gameList,
                                "noOfFreeRounds": freespin.freeRoundsBalance
                        ]
                    }
            )
        }
        render(status: 200, text: builder.toPrettyString(), contentType: "application/json", encoding: "UTF-8")
    }

    /**
     *  player free round details for IGT
     *
     */
    private List<FreeSpinDetailsDTO> prepareIgtFreeSpinDetailsDTO(Session session) {
        Player player = session.player
        PlayerFreeRounds playerFreeRounds = PlayerFreeRounds.findByPlayerAndStatusAndGameProviders(player, RewardStatus.Active.id, RGSName.IGT.rgsName())
        List<FreeSpinDetailsDTO> freeSpinDetailsDTOLst
        if(playerFreeRounds!=null) {
            freeSpinDetailsDTOLst = new ArrayList<FreeSpinDetailsDTO>()
            List<String> gamesList = playerFreeRounds ? Arrays.asList( playerFreeRounds.games.split(",")) : null
            freeSpinDetailsDTOLst.add(new FreeSpinDetailsDTO(String.valueOf(playerFreeRounds?.bonus?.identifier), playerFreeRounds?.bonus?.name, playerFreeRounds?.bonus?.description, gamesList, playerFreeRounds.freeRoundsBalance))
        }
        return freeSpinDetailsDTOLst
    }

    /**
     *  player free round details for NETENT
     *
     */
    private List<FreeSpinDetailsDTO> prepareNetentFreeSpinsDetailsDTO(Session session) {
        String SOAPclient = paramService.getString("netent.admin.wsdl.url")
        client = new SOAPClient(SOAPclient)
        def response
        try {
            response = client.send(SOAPAction: '') {
                envelopeAttributes('xmlns:api': 'http://casinomodule.com/api')
                body {
                    'api:getUserFreeRoundInformation' {
                        'userName'(session.player.id)
                        'merchantId'(paramService.getString("netent.api.merchant.id"))
                        'merchantPassword'(paramService.getPassword("netent.api.merchant.password"))
                    }
                }
            }
            log.debug('Response for prepareNetentFreeSpinsDetailsDTO:' + response.httpResponse.statusCode)
            if (response.httpResponse.statusCode != 200) {
                render(status: 400, contentType: 'application/json') {
                    [
                            "message": "Invalid response"
                    ]
                }
                return
            }
            def freeRoundsResponse = new XmlSlurper().parseText(response.text)
            def freeRoundsResponseReturn = freeRoundsResponse.Body.getUserFreeRoundInformationResponse.getUserFreeRoundInformationReturn
            List<FreeSpinDetailsDTO> freeSpinDetailsDTOLst
            if (null != freeRoundsResponseReturn) {
                freeSpinDetailsDTOLst = new ArrayList<FreeSpinDetailsDTO>()
                FreeSpinDetailsDTO freeSpinDetailsDTO
                freeRoundsResponseReturn.each { freeRoundsResponseRet ->
                    freeSpinDetailsDTOLst.add(new FreeSpinDetailsDTO("", "", "", this.getGames(freeRoundsResponseRet.gameIds.toString()), freeRoundsResponseRet.freeRoundsLeft.toInteger()));
                }
            }
            return freeSpinDetailsDTOLst
        } catch (Exception e) {
            log.error "Unable to get NETENT free rounds info [ Cause: " + e.getMessage() + "]"
            return null
        }
    }

    /**
     *  player free round details for Quickfire
     *
     */
    private List<FreeSpinDetailsDTO> prepareQuickFireFreeSpinsDetailsDTO(Session session) {
        try{
            List<FreeSpinDetailsDTO> freeSpinDetailsDTOLst;
            List<String> gamesList;
            Integer spinsRemaining;
            List<QuickFireFreeSpinGetAvailableFreeGamesResponse> freeRoundsResponseReturn = quickFireFreeSpinsService.getPlayerFreeSpinsBalance(session?.player);
                if (null != freeRoundsResponseReturn && freeRoundsResponseReturn.size()>0) {
                    freeSpinDetailsDTOLst = new ArrayList<FreeSpinDetailsDTO>()
                    freeRoundsResponseReturn.each { freeRoundsResponse ->
                            List<QuickFireFreeSpinBundledGamesHolder> bundledGames = freeRoundsResponse.bundledGames;
                        bundledGames.each { bundledGame ->
                            gamesList = this.getQuickFireGameShortName(bundledGame)
                        }
                         List<QuickFireFreeSpinOfferInstancesHolder> offerInstances = freeRoundsResponse.offerInstances;
                        offerInstances.each { quickFireFreeSpinOfferInstancesHolder ->
                            spinsRemaining = getQuickFireOfferInstances(quickFireFreeSpinOfferInstancesHolder)
                        }
                        freeSpinDetailsDTOLst.add(new FreeSpinDetailsDTO("", "", "", gamesList,spinsRemaining==null?0:spinsRemaining));
                    }
                }
                return freeSpinDetailsDTOLst
        } catch (Exception e) {
            log.error "Unable to get QuickFire free rounds info [ Cause: " + e.getMessage() + "]"
            return null
        }
    }


    /**
     *  player free round details for Elite,
     *  Since elite does not any api to fetch freespin details, FS details are sent from bonus.
     *
     */
    private List<FreeSpinDetailsDTO> prepareEliteFreeSpinsDetailsDTO(Session session) {
        try{
            List<FreeSpinDetailsDTO> freeSpinDetailsDTOLst = new ArrayList<FreeSpinDetailsDTO>()
             List<String> gamesList;
             Integer spinsRemaining;
             Boolean invokeElite = paramService.getBoolean("elite.freespins.balance.enable")
             if(invokeElite!=null && invokeElite?.booleanValue()){
                 EliteFreeSpinGetBalanceResponse eliteFreeSpinGetBalanceResponse = eliteFreeSpinsService.getPlayerFreeSpinsBalance(session?.player);
                 if (null != eliteFreeSpinGetBalanceResponse && eliteFreeSpinGetBalanceResponse.result?.playerFreeSpinDetails?.size()>0) {
                     eliteFreeSpinGetBalanceResponse?.result?.playerFreeSpinDetails.each { playerFreeSpinDetail ->
                         gamesList = this.getEliteGameShortName(playerFreeSpinDetail.games)
                         spinsRemaining = playerFreeSpinDetail?.noOfSpinsAwarded?.intValue() - playerFreeSpinDetail?.noOfSpinsCompleted?.intValue();
                         freeSpinDetailsDTOLst.add(new FreeSpinDetailsDTO("", "", "", gamesList,spinsRemaining==null?0:spinsRemaining));
                     }
                 }
             }else {
                    List<PlayerFreeRounds> playerFreeRounds = PlayerFreeRounds.findAllByPlayerAndStatusAndGameProvidersAndFreeRoundsValidityGreaterThan(session?.player,PlayerRewardStatus.Consumed.id, RGSName.ELITE.rgsName(),new Date())
                    if (playerFreeRounds != null) {
                    playerFreeRounds.collect { playerFreeRound->
                         gamesList = playerFreeRound ? Arrays.asList(playerFreeRound.games.split(",")) : null
                         freeSpinDetailsDTOLst.add(new FreeSpinDetailsDTO(String.valueOf(playerFreeRound?.bonus?.id), playerFreeRound?.bonus?.name, playerFreeRound?.bonus?.description, gamesList, playerFreeRound.freeRoundsBalance))
                        }
                    }
             }
            return freeSpinDetailsDTOLst
        } catch (Exception e) {
            log.error "Unable to get Elite free rounds info [ Cause: " + e.getMessage() + "]"
            return null
        }
    }

    /**
     * method to find the game names list
     * @param gameIds
     * @return
     */
    private List<String> getGames(String gameIds){
        List<String> gameList = new ArrayList<String>()
        try {
            Set<String> gameExternalIds = new HashSet<String>()
            gameIds.split("\\|").each { gameId ->
                gameExternalIds.add(gameId.trim());
            }

            if (gameExternalIds.size() > 0) {
                RGS netEntRgs = RGS.findByName(RGSName.NETENT.rgsName())
                List<Game> games = Game.findAllByExternalIdInListAndRgs(gameExternalIds.collect {it}, netEntRgs)
                if(games!=null) {
                    games.collect { game ->
                        gameList.add(game.shortName)
                    }
                }
            }
        }catch(Exception e){
            log.error("Exception occurred while getting games list for Netent gameIds : "+e.getMessage())
        }
        return gameList;
    }

    /**
     *
     * @param quickFireFreeSpinBundledGamesHolder
     * @return
     */
    private List<String> getQuickFireGameShortName(List<QuickFireFreeSpinBundledGamesHolder> quickFireFreeSpinBundledGamesHolderList){
        try {
            List<String> gameList = new ArrayList<String>()
            if (null != quickFireFreeSpinBundledGamesHolderList && quickFireFreeSpinBundledGamesHolderList.size()>0) {
                for(QuickFireFreeSpinBundledGamesHolder quickFireFreeSpinBundledGamesHolder : quickFireFreeSpinBundledGamesHolderList) {
                    BigDecimal moduleId = new BigDecimal(quickFireFreeSpinBundledGamesHolder.getModuleId())
                    BigDecimal clientId = new BigDecimal(quickFireFreeSpinBundledGamesHolder.getClientId())
                    //String iLikeSearch = "%moduleId:" + moduleID + "%clientId:" + clientId+"%";
                    QuickfireGameConfig quickfireGameConfig = QuickfireGameConfig.findByModuleIdAndClientId(moduleId,clientId);
                    Game game = Game.findById(quickfireGameConfig?.game?.id);
                    if (game != null) {
                        gameList.add(game.shortName);
                    }
                }
            }
            log.info("getQuickFireGameShortName - Games List "+gameList)
            return gameList;
        }catch(Exception _exp){
            log.error("getQuickFireGameShortName - Exception occured while getching games by module and client id")
            return null;

        }
    }

    /**
     *
     * @param quickFireFreeSpinBundledGamesHolder
     * @return
     */
    private List<String> getEliteGameShortName(List<String> eliteGamesList){
        try {
            List<String> gameList = new ArrayList<String>()
            if (null != eliteGamesList && eliteGamesList.size()>0) {
                for(String externalId : eliteGamesList) {
                    Game game = Game.findByExternalId(externalId);
                    if (game != null) {
                        gameList.add(game.shortName);
                    }
                }
            }
            log.info("getEliteGameShortName - Games List "+gameList)
            return gameList;
        }catch(Exception _exp){
            log.error("getEliteGameShortName - Exception occured while getching games by module and client id")
            return null;

        }
    }

    /**
     *
     * @param quickFireFreeSpinBundledGamesHolder
     * @return
     */
    private Integer getQuickFireOfferInstances(List<QuickFireFreeSpinOfferInstancesHolder> quickFireFreeSpinOfferInstancesHolderList){
        try {
            int spinsRemaining;
            if (null != quickFireFreeSpinOfferInstancesHolderList && quickFireFreeSpinOfferInstancesHolderList.size()>0) {
                for(QuickFireFreeSpinOfferInstancesHolder quickFireFreeSpinOfferInstancesHolder : quickFireFreeSpinOfferInstancesHolderList) {
                    spinsRemaining = spinsRemaining + quickFireFreeSpinOfferInstancesHolder.getNumberOfGamesRemaining()?.intValue();
                }
            }
            log.info("getQuickFireOfferInstances - Spins Remaining "+spinsRemaining)
            return new Integer(spinsRemaining);
        }catch(Exception _exp){
            log.error("getQuickFireOfferInstances - Exception occured while fetching offer instances " +_exp.getMessage())
            return null;

        }
    }


    /**
     * Guest Login
     * @TODO HK Whats this for a login?
     */
    def guestLogin() {
        def payload = request.JSON
        String acccountSystemTag = payload.acccountSystemTag?.trim()
        String platformTag = payload.platformTag?.trim()
    }

    /**
     * Change contactable settings from Evolve 1 Lobby
     * @return The updated settings
     */
    def changeContactableSettings() {
        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }

        PlayerCommunicationDTO playerCommunicationDTO = null
        try {
            playerCommunicationDTO = JsonUtils.convertPlayerCommunicationJsonToMap(request.JSON)
            log.debug("changeContactableSettings player id: " + session.player.id + " playerCommunicationDTO:::" + playerCommunicationDTO)
        } catch (ValidationException _exp) {
            log.error("ValidationException in changeContactableSettings: "+ _exp.getMessage())
            createErrorResponse(APIReturnCode.INVALID_PARAMS)
            return
        }


        def result = playerService.changeContactableSettings(session.player, playerCommunicationDTO)
        if (result.returnCode == APIReturnCode.OK) {

            render(status: 200, contentType: 'application/json') {
                [
                        "contactableByUs"    : session.player.isContactable,
                        "contactableBySms": session.player.isContactableBySms,
                        "contactableByOthers": session.player.isContactableByOthers,
                        "contactableByCall":session.player.isContactableByCall,
                        "contactableByPost":session.player.isContactableByPost
                ]
            }
        } else {
            createErrorResponse(APIReturnCode.ERROR)
        }
    }
    /**
     * Change contactable settings from Evolve 1 Lobby
     * @return The updated settings
     */
    def changeSMSContactableSettings() {
        def payload = request.JSON

        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }

        boolean contactableBySms = "${payload.contactableBySms}".trim().toBoolean()
        if(payload.contactableBySms != null) {
            session.player.isContactableBySms = contactableBySms
        }
        def result = playerService.changeSMSContactableSettings(session.player)
        if (result.returnCode == APIReturnCode.OK) {
            render(status: 200, contentType: 'application/json') {
                [
                        "contactableByUs"    : session.player.isContactable,
                        "contactableBySms"   : session.player.isContactableBySms,
                        "contactableByOthers": session.player.isContactableByOthers,
                        "isContactableByCall": session.player.isContactableByCall,
                        "isContactableByPost": session.player.isContactableByPost
                ]
            }
        } else {
            createErrorResponse(APIReturnCode.ERROR)
        }
    }


    /**
     * Change withdrawal confirmation settings from Evolve 1 Lobby
     * @return The updated settings
     */
    def changeWithdrawalConfirmation() {
        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }
        def payload = request.JSON
        Boolean withdrawConfirmationOptInOptOut = payload.withdrawConfirmationOptIn
        if (null != withdrawConfirmationOptInOptOut) {
            def result = playerService.changeWithdrawalConfirmationOptIn(session?.player,withdrawConfirmationOptInOptOut.booleanValue())
            if (result.returnCode == APIReturnCode.OK) {
                render(status: 200, contentType: 'application/json') {
                    [
                            "withdrawConfirmationOptIn"    : result?.player?.withdrawConfirmationOptIn
                    ]
                }
                return
            } else {
                createErrorResponse(APIReturnCode.ERROR)
                return
            }
        } else {
            log.info("Failed as withdrawConfirmationOptIn:${payload.withdrawConfirmationOptIn}")
            createErrorResponse(APIReturnCode.INVALID_PARAMS)
            return
        }
    }


    /**
     * Set autoLogin ("Remember me")
     * @return
     */
    def autoLoginPreference() {
        def payload = request.JSON
        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }

        if (payload.autoLoginValue == "REMEMBER_USERNAME_PASSWORD") {
            session.player.autoLoginPreference = Player.REMEMBER_USERNAME_PASSWORD
        } else {
            session.player.autoLoginPreference = Player.DO_NOT_REMEMBER_ME
        }

        if (session.player.save(flush: true)) {
            render(status: 200, contentType: 'application/json') {
                [
                        "autoLoginValue": session.player.autoLoginPreferenceDescription[session.player.autoLoginPreference],
                ]
            }
        } else {
            createErrorResponse(APIReturnCode.ERROR)
        }
    }

/**
 * Return the players profile to the Evolve 1 Lobby
 * @return the Player JSON Details
 */
    def profile() {
        redirect(uri: "/api/account/redirectedProfile?timestamp=" + System.currentTimeMillis())
    }

    def redirectedProfile() {
        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }

        if (session?.player) {
            /*render(status: 200, contentType: 'application/json') {
                createPlayerProfileJSONResponse(session, false)
            }*/
            createPlayerRedirectedProfileJSONResponse(session)
        }
    }

    /**
     * Return the players balance to the Evolve 1 Lobby
     * @return the Player JSON Details
     */
    def balance() {
        redirect(uri: "/api/account/redirectedBalance?timestamp=" + System.currentTimeMillis())
    }

    def redirectedBalance() {
        Session session = initialiseEvolveSession()
        if (session == null) {
            render(status: 401, contentType: 'application/json') {
                createErrorJSONResponse('ValidationError', g.message(code: 'evovle1.lobby.sessioninvalid'))
            }
            return
        }
        if (session?.player) {
            render(status: 200, contentType: 'application/json') {
                createPlayerBalanceJSONResponse(session)
            }
        }
    }


    def challengeQuestions() {
        def securityQuestions = SecurityQuestion.findAll().sort { it.id }

        render(status: 200, contentType: 'application/json') {
            [
                    "challengeQuestionList":
                            securityQuestions.each { SecurityQuestion question ->
                                [
                                        "id"  : "${question.id}",
                                        "text": "${question.question}",
                                ]
                            }
            ]
        }
    }

    /**
     * Change password setting from Evolve 1 lobby
     * @return
     */
    def changePassword() {

        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }

        def payload = request.JSON
        String oldPassword = payload.oldPassword?.trim()
        String newPassword = payload.newPassword?.trim()

        def result = playerService.changePassword(session.player, oldPassword, newPassword)
        if (result.returnCode == APIReturnCode.OK) {
            render(status: 200, text: "${result.returnCode.message()}")
        } else {
            createErrorResponse(APIReturnCode.PLAYER_PASSWORD_MISMATCH)
        }

    }

    /**
     * Request resetting password
     */
    def passwordReset() {
        def payload = request.JSON

        String lookupEmail = payload.email
        String lookupAccountSystem = payload.accountSystemTag
        //Player player = Player.findByEmail(lookupEmail)
        if (StringUtils.isNotBlank(lookupAccountSystem)) {
            Site site = Site.findByShortName(lookupAccountSystem.toLowerCase())
            Player player = Player.findByEmailAndSite(lookupEmail, site)
            if (player) {
                playerService.resetPassword(player)
            }
        }
        render(status: 200, contentType: 'application/json')
    }


    def changePassword2() {
        Session session = initialiseEvolveSession()

        def payload = request.JSON
    }

    /**
     * Change deposit limits via Evolve 1 Lobby
     * @return
     */
    def limits() {
        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }


        if (request.method == 'GET') {

            // retrieve current deposit limits

            playerService.checkDepositLimits(session.player)

            render(status: 200, contentType: 'application/json') {
                [
                        "daily"  : session.player.playerDepositLimits.dailyLimit,
                        "weekly" : session.player.playerDepositLimits.weeklyLimit,
                        "monthly": session.player.playerDepositLimits.monthlyLimit
                ]
            }

        } else {

            // request new deposit limits

            Player player = session.player
            if (player == null) {
                createErrorResponse(APIReturnCode.INVALID_PLAYER)
                return
            }

            def int requestedDailyLimit, requestedWeeklyLimit, requestedMonthlyLimit
            log.info(params)

            def payload = request.JSON
            BigDecimal daily = payload.daily ? "${payload.daily}".toBigDecimal() : null
            BigDecimal weekly = payload.weekly ? "${payload.weekly}".toBigDecimal() : null
            BigDecimal monthly = payload.monthly ? "${payload.monthly}".toBigDecimal() : null

            if ((daily == null || daily <= 0) && (weekly == null || weekly <= 0) && (monthly == null || monthly <= 0)) {
                createErrorResponse(APIReturnCode.DEPOSIT_LIMITS_NULL)
                return
            }

            if ((daily != null && daily.precision() > 6) || (weekly != null && weekly.precision() > 6) || (monthly != null && monthly.precision() > 6)) {
                String msg = "Deposit limit cannot be greater than {0}."
                String[] paramValues = ["999999"]
                if (player.site.brandDepositLimit != null) {
                    paramValues = ["${player.site.brandDepositLimit}"]
                }
                createDynamicErrorResponse(APIReturnCode.DEPOSIT_BRANDLIMIT_EXCEEDED,msg,paramValues)
                return
            }


            playerService.checkDepositLimits(player)



            //daily should not be more than brand deposit limit, weekly and monthly
            if (daily != null && daily > 0) {

                if (player.site.brandDepositLimit != null && daily.compareTo(player.site.brandDepositLimit) == 1) {
                    createErrorResponse(APIReturnCode.DAILY_DEPOSIT_LMT_EXCEEDED)
                    return
                }


                if (weekly != null && weekly > 0 && daily.compareTo(weekly) == 1) {
                    createErrorResponse(APIReturnCode.DAILY_DEPOSIT_LMT_EXCEEDED_WKLY)
                    return
                }
                if ((weekly == null || weekly <= 0) &&
                        ((checkNotNullAndNotZero(player.playerDepositLimits.weeklyLimit) && daily.compareTo(player.playerDepositLimits.weeklyLimit) == 1) ||
                                (checkNotNullAndNotZero(player.playerDepositLimits.pendingWeeklyLimit) && daily.compareTo(player.playerDepositLimits.pendingWeeklyLimit) == 1))) {
                    createErrorResponse(APIReturnCode.DLY_DEPOSIT_LMT_EXCEEDED_PENDDING_WKLY)
                    return
                }

                if (monthly != null && monthly > 0 && daily.compareTo(monthly) == 1) {
                    createErrorResponse(APIReturnCode.DAILY_DEPOSIT_LMT_EXCEEDED_MONTHLY)
                    return
                }
                if ((monthly == null || monthly <= 0) &&
                        ((checkNotNullAndNotZero(player.playerDepositLimits.monthlyLimit) && daily.compareTo(player.playerDepositLimits.monthlyLimit) == 1) ||
                                (checkNotNullAndNotZero(player.playerDepositLimits.pendingMonthlyLimit) && daily.compareTo(player.playerDepositLimits.pendingMonthlyLimit) == 1))) {
                    createErrorResponse(APIReturnCode.DAILY_DEPOSIT_LMT_EXCEEDED_PENDDING_MONTHLY)
                    return
                }
            }

            if (weekly != null && weekly > 0) {
                if (daily != null && daily > 0 && daily.compareTo(weekly) == 1) {
                    createErrorResponse(APIReturnCode.WKLY_DEPOSIT_LIMIT_LESSTHAN_DLY)
                    return
                }
                if ((daily == null || daily <= 0) &&
                        ((checkNotNullAndNotZero(player.playerDepositLimits.dailyLimit) && weekly.compareTo(player.playerDepositLimits.dailyLimit) < 0) ||
                                (checkNotNullAndNotZero(player.playerDepositLimits.pendingDailyLimit) && weekly.compareTo(player.playerDepositLimits.pendingDailyLimit) < 0))) {
                    createErrorResponse(APIReturnCode.WKLY_DEPOSIT_LIMIT_LESSTHAN_PENDDING_DLY)
                    return
                }

                if (monthly != null && monthly > 0 && weekly.compareTo(monthly) == 1) {
                    createErrorResponse(APIReturnCode.WKLY_DEPOSIT_LMT_EXCEEDED_MONTHLY)
                    return
                }
                if ((monthly == null || monthly <= 0) &&
                        ((checkNotNullAndNotZero(player.playerDepositLimits.monthlyLimit) && weekly.compareTo(player.playerDepositLimits.monthlyLimit) == 1) ||
                                (checkNotNullAndNotZero(player.playerDepositLimits.pendingMonthlyLimit) && weekly.compareTo(player.playerDepositLimits.pendingMonthlyLimit) == 1))) {
                    createErrorResponse(APIReturnCode.WKLY_DEPOSIT_LMT_EXCEEDED_PENDDING_MONTHLY)
                    return
                }
            }

            if (monthly != null && monthly > 0) {


                if (daily != null && daily > 0 && daily.compareTo(monthly) == 1) {
                    createErrorResponse(APIReturnCode.MONTHLY_DEPOSIT_LIMIT_LESSTHAN_DLY)
                    return
                }
                if ((daily == null || daily <= 0) &&
                        ((checkNotNullAndNotZero(player.playerDepositLimits.dailyLimit) && monthly.compareTo(player.playerDepositLimits.dailyLimit) < 0) ||
                                (checkNotNullAndNotZero(player.playerDepositLimits.pendingDailyLimit) && monthly.compareTo(player.playerDepositLimits.pendingDailyLimit) < 0))) {
                    createErrorResponse(APIReturnCode.MONTHLY_DEPOSIT_LMT_EXCEEDED_PENDDING_MONTHLY)
                    return
                }

                if (weekly != null && weekly > 0 && monthly.compareTo(weekly) < 1) {
                    createErrorResponse(APIReturnCode.MONTHLY_DEPOSIT_LIMIT_LESSTHAN_WKLY)
                    return
                }
                if ((weekly == null || weekly <= 0) &&
                        ((checkNotNullAndNotZero(player.playerDepositLimits.weeklyLimit) && monthly.compareTo(player.playerDepositLimits.weeklyLimit) < 0) ||
                                (checkNotNullAndNotZero(player.playerDepositLimits.pendingWeeklyLimit) && monthly.compareTo(player.playerDepositLimits.pendingWeeklyLimit) < 0))) {
                    createErrorResponse(APIReturnCode.MONTHLY_DEPOSIT_LMT_EXCEEDED_PENDDING_WKLY)
                    return
                }
            }
            def result = playerService.setDepositLimits(session.player, daily, weekly, monthly)

            log.debug("Result: ${result}")

            if (result) {
                render(status: 200, contentType: 'application/json')
            } else {
                createErrorResponse(APIReturnCode.DEPOSIT_LIMIT_ALREADY_SET)
            }

        }

    }

    /**
     * Logout the current player
     * @return
     */
    def logout() {
        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }

        sessionLogout(session)
        render(status: 200)
    }

    /**
     * Create player response JSON
     * @param session
     * @return
     */
    def createPlayerJSONResponse(Session session) {
        Account cash = accountService.getCashAccount(session.player)
        Account bonus = accountService.getBonusAccount(session.player)
        Account loyalty = accountService.getLoyaltyAccount(session.player)

        def jsonResponse = [
                "username"                   : "${session.player.userName}",
                "title"                      : "${session.player.salutation}",
                "firstName"                  : "${session.player.firstName}",
                "lastName"                   : "${session.player.lastName}",
                "dateOfBirth"                : "${session.player.dateOfBirth}",
                "email"                      : "${session.player.email}",
                "mobilePhoneNumber"          : "${session.player.mobileNumber}",
                "address"                    : [
                        "country"     : "${session.player.country}",
                        "country_code": "${session.player.country.iso3}",
                        "address"     : "${session.player.address_1}",
                        "city"        : "${session.player.city}",
                        "houseNumber" : "${session.player.houseNumber}",
                        "postCode"    : "${session.player.postcode}",
                        "county"      : "${session.player.county}"
                ],
                "challengeAnswer"            : "${session.player.securityAnswer}",
                "preferredCurrency"          : "${bonus.currency.iso}",
                "includeExternalBalance"     : "",
                "accountSystemTag"           : "${session.player.site.shortName}",
                "balanceType"                : "",
                "balance"                    : [
                        "total"                 : [
                                "amount"  : cash.balance + bonus.balance,
                                "currency": "${cash.currency.iso}"
                        ],
                        "ewalletNonWithdrawable": [
                                "amount"  : bonus.balance?.floatValue(),
                                "currency": "${bonus.currency.iso}"
                        ],
                        "sessionReturns"        : 0,
                        "externalAccount"       : [
                                "amount"  : 0,
                                "currency": ""
                        ],
                        "sessionStakes"         : 0,
                        "ewalletWithdrawable"   : [
                                "amount"  : cash.balance?.floatValue(),
                                "currency": "${cash.currency.iso}"
                        ]
                ],
                "pin"                        : "",
                "referAFriendCode"           : "",
                "countryCallingCode"         : session.player.country.dialcode,
                "pinIsVerified"              : session.player.isEmailValidated,
                "vip"                        : "${session.player.vipLevel}",
                "autoLoginPreference"        : "${session.player.autoLoginPreferenceDescription[session.player.autoLoginPreference]}",
                "depositAmount"              : 0,
                "termsAndCondsVersion"       : session.player.termsAndConditionsVersion,
                "emailIsVerified"            : session.player.isEmailValidated,
                "trackingCode"               : "${session.player.referrerTag}",
                "pspType"                    : "EPG",
                "contactableByOthers"        : session.player.isContactableByOthers,
                "challengeQuestionId"        : session.player.securityQuestion?.id,
                "userCorrelationId"          : "${session.player.userCorrelationId}",
                "registrationLevel"          : "FULL",
                "platformTag"                : "${session.player.platformTag}",
                "demoPlay"                   : "",
                "passwordIsOneShot"          : session.player.isPasswordOneshot,
                "contactableByUs"            : session.player.isContactable,
                "depositTermsAndCondsVersion": session.player.depositTermsAndConditionsVersion,
                "loyaltyPointsAwarded"       : loyalty.balance == null ? BigDecimal.ZERO : loyalty.balance.setScale(0, RoundingMode.DOWN),
                "realityCheckLimit"          : session.player.realityCheckLimit,
                "depositCount"               : (session.player.playerExtra == null || session.player.playerExtra.depositCount == null) ? BigDecimal.ZERO : session.player.playerExtra.depositCount,
                "totalDepositAmount"         : session.player.playerExtra == null ? BigDecimal.ZERO : session.player.playerExtra.scaledTotalDepositAmount
        ]
        return jsonResponse
    }

    /**
     * Create player balance response JSON
     * @param session
     * @return
     */
    def createPlayerBalanceJSONResponse(Session session) {
        Account cash = accountService.getCashAccount(session.player)
        Account bonus = accountService.getBonusAccount(session.player)

        def jsonResponse = [

                "balance": [
                        "total"                 : [
                                "amount"  : cash.balance + bonus.balance,
                                "currency": "${cash.currency.iso}"
                        ],
                        "ewalletNonWithdrawable": [
                                "amount"  : bonus.balance?.floatValue(),
                                "currency": "${bonus.currency.iso}"
                        ],
                        "sessionReturns"        : 0,
                        "externalAccount"       : [
                                "amount"  : 0,
                                "currency": ""
                        ],
                        "sessionStakes"         : 0,
                        "ewalletWithdrawable"   : [
                                "amount"  : cash.balance?.floatValue(),
                                "currency": "${cash.currency.iso}"
                        ]
                ],

        ]
        return jsonResponse
    }

    /**
     * update deposit terms and conditions
     * @return
     */
    def depositTermsAndConditions() {
        def payload = request.JSON
        int version = payload."version"
        if (version <= 0 || version > 1) {
            createErrorResponse(APIReturnCode.DEPOSIT_TERMS_CONDITION_NOT_ACCEPTED)
            return
        }

        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }

        if (session.player.depositTermsAndConditionsVersion == version) {
            render(status: 204)
            return
        }
        def result = playerService.depositTermsAndConditions(session.player, version)
        if (result.returnCode == APIReturnCode.OK) {
            render(status: 204)
        } else {
            createErrorResponse(APIReturnCode.ERROR)
        }

    }

    def termsAndConditions() {
        def payload = request.JSON
        int version = payload."version"
        if (version <= 0) {
            createErrorResponse(APIReturnCode.TERMS_CONDITION_NOT_ACCEPTED)
            return
        }

        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }

        if (session.player.termsAndConditionsVersion == version) {
            render(status: 204)
            return
        }
        def result = playerService.termsAndConditions(session.player, version)
        if (result.returnCode == APIReturnCode.OK) {
            render(status: 204)
        } else {
            createErrorResponse(APIReturnCode.ERROR)
        }
    }

    def updatePrivacyPolicy() {
        def payload = request.JSON
        int version = payload."version"
        if (version <= 0) {
            createErrorResponse(APIReturnCode.PRIVACY_POLICY_NOT_ACCEPTED)
            return
        }

        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }

        if (session.player.privacyPolicyAcceptedVersion == version) {
            render(status: 204)

            return
        }
        def result = playerService.updatePrivacyPolicy(session.player, version)
        if (result.returnCode == APIReturnCode.OK) {
            render(status: 204)
        } else {
            createErrorResponse(APIReturnCode.ERROR)
        }
    }

    def getPaymentMethodChangeThreshold() {
        def accountSystemTag = params.accountSystemTag
        if (accountSystemTag == null || "".equals(accountSystemTag)) {
            render(status: 400, contentType: 'application/json', text: "Account System Tag is null or empty")
            return
        }
        Session session = initialiseEvolveSession()
        if (session == null) {
            render(status: 401, contentType: 'application/json') {
                createErrorJSONResponse('ValidationError', g.message(code: 'evovle1.lobby.sessioninvalid'))
            }
            return
        }

        if (sessionService.isActiveSession(session)) {
            BigDecimal paymentChangeThreshold = null
            if(session.site.paymentMethodChangeThresholds != null && session.site.paymentMethodChangeThresholds.size() > 0) {
                for(PaymentMethodChangeThreshold changeThreshold : session.site.paymentMethodChangeThresholds) {
                    if(changeThreshold != null && changeThreshold?.currency?.id == session.player.currency.id){
                        paymentChangeThreshold = changeThreshold.amount
                    }
                }
            }
            if (paymentChangeThreshold != null) {
                render(status: 200, contentType: 'application/json') {
                    ["thresholdEnabled": true, "thresholdValue": paymentChangeThreshold]
                }
            } else {
                render(status: 400, contentType: 'application/json', text: "Invalid account system Tag")
            }
        } else {
            render(status: 400, contentType: 'application/json', text: "Session invalid")
        }
    }

    /**
     * Api for promo code redemption
     *
     * @return
     */
    def promoCodeRedemption() {
        boolean used = false;
        boolean eligible = true;
        boolean validPromoCode = false;


        log.info("PromoBonus request method type : " + request.method)

        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }

        Player player = session.player
        if (session.player.bonusOptOut) {
            createErrorResponse(APIReturnCode.PROMOCODE_NOT_REDEEM_OPTED_OUT)
            return
        }

        if (session.player.isBonusAbuser) {
            createErrorResponse(APIReturnCode.PROMOCODE_NOT_REDEEM_BONUS_ABUSER)
            return
        }

        //check is player is DepositToBonus restricted or not
        if(playerBonusService.isPlayerDepositToBonusRestriction(player)){
            log.debug("DepositToBonus PromoCode PlayerId: "+session.player?.id+" has restricted for PlayerDepToBon%")
            createErrorResponse(APIReturnCode.DEPOSIT_TO_BONUS_PERC_RESTRICTED)
            return
        }

        if (request.method == 'GET') {
            String promoCode = params.bonusCode
            log.info("promoCode : " + promoCode)
            Bonus bonus = bonusService.findBonusBySiteAndBonusTypeAndStatusAndPromoCode(player.site, BonusType.PromoCode.id, RewardStatus.Active.id, promoCode)

            if (bonus == null) {
                createErrorResponse(APIReturnCode.INVALID_PROMOCODE)
                return
            }
            if (bonus.availableToMiniGames)
                eligible = playerBonusService.getPromoCodeEligible(promoCode, player, bonus)

            PlayerBonus playerBonus = playerBonusService.findByPlayerAndBonus(player, bonus);

            if (playerBonus != null)
                used = true

            render(status: 200, contentType: 'application/json') {
                ["used": used, eligible: eligible]
            }
        } else if (request.method == 'POST') {
            def payload = request.JSON
            String promoCode = params.bonusCode == null ? payload.promoCode : params.bonusCode

            log.info("promoCode : " + promoCode)
            Bonus bonus = bonusService.findBonusBySiteAndBonusTypeAndStatusAndPromoCode(player.site, BonusType.PromoCode.id, RewardStatus.Active.id, promoCode)

            if (bonus == null) {
                createErrorResponse(APIReturnCode.INVALID_PROMOCODE)
                return
            }
            if (bonus.availableToMiniGames && !(playerBonusService.getPromoCodeEligible(promoCode, player, bonus))) {
                PromoCodeEligible promoCodeEligible = playerBonusService.createPromoCodeEligible(promoCode, player, bonus);
                eligible = promoCodeEligible.eligble;
            }

            PlayerBonus playerBonus = playerBonusService.findByPlayerAndBonus(player, bonus);

            if (playerBonus != null)
                used = true

            render(status: 200, contentType: 'application/json') {
                ["used": used, eligible: eligible]
            }
        } else if (request.method == 'PUT') {
            def payload = request.JSON
            String promoCode = params.bonusCode == null ? payload.promoCode : params.bonusCode

            log.info("promoCode : " + promoCode)

            Bonus bonus = bonusService.findBonusBySiteAndBonusTypeAndStatusAndPromoCode(player.site, BonusType.PromoCode.id, RewardStatus.Active.id, promoCode)

            if (bonus == null) {
                createErrorResponse(APIReturnCode.INVALID_PROMOCODE)
                return
            }
            if (bonus.availableToMiniGames && !(playerBonusService.getPromoCodeEligible(promoCode, player, bonus))) {
                createErrorResponse(APIReturnCode.PROMOCODE_NOT_ELIGIBLE)
                return
            }

            def bonusCodeUsed
            if (bonus.oneTimeCode)
                bonusCodeUsed = PlayerBonus.countByBonus(bonus);

            def playerBonus = PlayerBonus.countByPlayerAndBonus(player, bonus);

            if (playerBonus > 0 || bonusCodeUsed > 0) {
                String[] paramValues = ["${promoCode}"]
                createDynamicErrorResponse(APIReturnCode.PROMOCODE_ALREADY_USED,"Promo code {0} already used.",paramValues)
                return
            }

            playerBonus = playerBonusService.createBonus(player, bonus, null, null);
            //update player DepositToBonusRatio
            playerBonusService.updatePlayerDepositToBonusRatio(player, null, playerBonus.awardedAmount, true)

            List<PlayerBonus> playerBonuses = new ArrayList<PlayerBonus>();
            playerBonuses.add(playerBonus);
            def returnMap = [playerBonus: playerBonuses]
            render returnMap as JSON
        }

    }


    def redeemLoyaltyPoints() {

        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }

        if (session.player.bonusOptOut) {
            createErrorResponse(APIReturnCode.LTY_POINTS_NOT_REDEEM_OPTED_OUT)
            return
        }

        if (session.player.isBonusAbuser) {
            createErrorResponse(APIReturnCode.LTY_POINTS_NOT_REDEEM_BONUS_ABUSER)
            return
        }

        int noOfBlocks = params.noOfBlocks as int
        if (noOfBlocks <= 0) {
            createErrorResponse(APIReturnCode.INVALID_NO_OF_BLOCKS)
            return
        }
        //check is player is DepositToBonus restricted or not
        /*if(playerBonusService.isPlayerDepositToBonusRestriction(session.player)){
            log.debug("DepositToBonus redeemLoyaltyPoints PlayerId: "+session.player?.id+" has restricted for PlayerDepToBon%")
            createErrorResponse(APIReturnCode.DEPOSIT_TO_BONUS_PERC_RESTRICTED)
            return
        }*/

        def result = loyaltyService.redeemLoyaltyPoints(noOfBlocks, session.site, session.player)
        if (result.returnCode == APIReturnCode.OK) {
            render(status: 200, contentType: 'application/json') {
                return ["loyaltyPoints"       : result.loyaltyDetails.loyaltyPoints,
                        "blockSize"           : result.loyaltyDetails.blockSize,
                        "maxBlocksInOneGo"    : result.loyaltyDetails.maxBlocksInOneGo,
                        "maxBlocksPerDay"     : result.loyaltyDetails.maxBlocksPerDay,
                        "blocksRedeemedToday" : result.loyaltyDetails.blocksRedeemedToday,
                        "bonusAmount"         : result.loyaltyDetails.bonusAmount,
                        "maxConvertibleAmount": result.loyaltyDetails.maxConvertibleAmount]
            }
        } else if (result.returnCode == APIReturnCode.BLOCKSIZE_GREATER_THAN_ONEGO) {
            String[] paramValues = ["${result.loyaltyRedemption.maxBlocksInOneGo * result.loyaltyRedemption.blockSize}"]
            //createDynamicErrorResponse(APIReturnCode.BLOCKSIZE_GREATER_THAN_ONEGO,g.message(code: "block.size.greaterthan.blocks.peronego", args: [result.loyaltyRedemption.maxBlocksInOneGo * result.loyaltyRedemption.blockSize]),null)
            createDynamicErrorResponse(APIReturnCode.BLOCKSIZE_GREATER_THAN_ONEGO,g.message(code: "block.size.greaterthan.blocks.peronego"),paramValues)
        } else if (result.returnCode == APIReturnCode.GREATER_AVAILABLE_POINTS) {
            createErrorResponse(APIReturnCode.GREATER_AVAILABLE_POINTS)
        } else if (result.returnCode == APIReturnCode.EXCEEDED_NO_OF_BLOCKS_PERDAY) {
            String[] paramValues = ["${result.loyaltyRedemption.maxBlocksPerDay * result.loyaltyRedemption.blockSize}"]
            //createDynamicErrorResponse(APIReturnCode.EXCEEDED_NO_OF_BLOCKS_PERDAY,g.message(code: "exceeded.numberof.bolocks.perday", args: [result.loyaltyRedemption.maxBlocksPerDay * result.loyaltyRedemption.blockSize]),null)
            createDynamicErrorResponse(APIReturnCode.EXCEEDED_NO_OF_BLOCKS_PERDAY,g.message(code: "exceeded.numberof.bolocks.perday"),paramValues)
        } else if (result.returnCode == APIReturnCode.NO_BONUSES_FOUND) {
            createErrorResponse(APIReturnCode.NO_BONUSES_FOUND)
        }

    }

    def getLoyaltyDetails() {
        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }
        //check is player is DepositToBonus restricted or not
       /* if(playerBonusService.isPlayerDepositToBonusRestriction(session.player)){
            log.debug("DepositToBonus getLoyaltyDetails PlayerId: "+session.player?.id+" has restricted for PlayerDepToBon%")
            createErrorResponse(APIReturnCode.DEPOSIT_TO_BONUS_PERC_RESTRICTED)
            return
        }*/

        def result = loyaltyService.getLoyaltyDetails(session.player)
        if (result.returnCode == APIReturnCode.NO_BONUSES_FOUND) {
            createErrorResponse(APIReturnCode.NO_BONUSES_FOUND)
        } else {
            render(status: 200, contentType: 'application/json') {
                return ["loyaltyPoints"       : result.loyaltyDetails.loyaltyPoints,
                        "blockSize"           : result.loyaltyDetails.blockSize,
                        "maxBlocksInOneGo"    : result.loyaltyDetails.maxBlocksInOneGo,
                        "maxBlocksPerDay"     : result.loyaltyDetails.maxBlocksPerDay,
                        "blocksRedeemedToday" : result.loyaltyDetails.blocksRedeemedToday,
                        "bonusAmount"         : result.loyaltyDetails.bonusAmount,
                        "maxConvertibleAmount": result.loyaltyDetails.maxConvertibleAmount
                ]
            }
        }
    }

    def createPlayerBonusJSONResponse(def playerBonus) {
        def jsonResponse = [
                "playerBonus": [
                        "name"       : playerBonus.bonus.name,
                        "status"     : PlayerRewardStatus.getStatusType(playerBonus.status).name,
                        "bonusAmount": "${playerBonus.balance}",
                        "awardedDate": playerBonus.dateCreated,
                        "expireDate" : playerBonus.expires
                ],
        ]
        return jsonResponse
    }


    def setRealityCheckLimit() {
        try {
            def payload = request.JSON
            Session session = getEvolvePlayerSession()
            if (session == null || !session.isActive()) {
                createErrorResponse(APIReturnCode.INVALID_SESSION)
                return
            }

            if (request.method == 'POST') {

                if (StringUtils.isBlank(String.valueOf(payload.realityCheckLimit))) {
                    createErrorResponse(APIReturnCode.INVALID_REALITY_CHECK_LIMIT)
                    return
                }
                if (!StringUtils.isNumeric(String.valueOf(payload.realityCheckLimit))) {
                    createErrorResponse(APIReturnCode.INVALID_REALITY_CHECK_LIMIT)
                    return
                }
                Integer realityCheckLimit = Integer.valueOf(payload.realityCheckLimit);
                if (realityCheckLimit == null || realityCheckLimit <= 0) {
                    createErrorResponse(APIReturnCode.INVALID_REALITY_CHECK_LIMIT)
                    return
                }
                log.info("Reality check limit for player with id:" + session.player.id + ", realityCheckLimit : " + realityCheckLimit)
                def realityCheckLimits = [5, 15, 30, 45, 60]
                if (!realityCheckLimits.contains(realityCheckLimit)) {
                    createErrorResponse(APIReturnCode.INVALID_REALITY_CHECK_LIMIT)
                    return
                }
                log.info("updating player reality check limit for player with id:" + session.player.id + ", realityCheckLimit : " + payload.realityCheckLimit)
                session.player.realityCheckLimit = realityCheckLimit
                if (session.player.save(flush: true)) {
                    render(status: 200, contentType: 'application/json') {
                        [
                                "realityCheckLimit": session.player.realityCheckLimit
                        ]
                    }

                } else {
                    createErrorResponse(APIReturnCode.ERROR)
                }

            } else if (request.method == 'GET') {

                render(status: 200, contentType: 'application/json') {
                    [
                            "realityCheckLimit": session.player.realityCheckLimit
                    ]
                }

            } else if (request.method == 'DELETE') {
                log.info("deleting player reality check limit for player with id:" + session.player.id)
                session.player.realityCheckLimit = null
                if (session.player.save(flush: true)) {
                    render(status: 200)
                } else {
                    createErrorResponse(APIReturnCode.ERROR)
                }
            }
        }
        catch (Exception e) {
            //    e.printStackTrace()
            createErrorResponse(APIReturnCode.ERROR)
        }


    }

    def selfExclude() {
        def payload = request.JSON
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd")
        Date selfExcludeTo = sdf.parse(payload.selfExcludeTo)
        Date todayDate = new Date()
        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }
        Player player = session?.player

        if (todayDate.after(selfExcludeTo)) {
            createErrorResponse(APIReturnCode.INVALID_SELFEXCLUDE_DATE)
            return
        }
        try {
            PlayerPropEvaluationRespDTO result = playerService.selfExclude(selfExcludeTo, player, null)
            if (result.returnCode == APIReturnCode.OK) {
                log.debug "Player ${result.player.userName} has been Self Excluded successfully."
                sessionLogout(session)
                render(status: 200, contentType: 'application/json') {
                    [
                            "message": "SelfExclusion Successful"
                    ]
                }
            } else {
                createErrorResponse(APIReturnCode.PLAYER_DUPLICATE_CHECK_ERROR)
            }
        } catch (Exception e) {
            log.error "Error occured in selfExclude() for the Player ${player.userName} " + e.getMessage()
            createErrorResponse(APIReturnCode.ERROR)
        }
    }

    /**
     * API for reactivate player account whose account was locked with issue REV-432 (Player Account edit issue) - ne need to supply the old password.
     */
    def reactivatePlayer() {
        try {
            def payload = request.JSON
            String email = payload.email?.trim()
            String accountSystem = payload.accountSystemTag?.trim()
            String newPassword = payload.newPassword?.trim()
            String platformTag = payload.platformTag?.trim()
            String encodedUserToken = payload.userCorrelationId?.trim()

            if (StringUtils.isBlank(email) || StringUtils.isBlank(accountSystem) || StringUtils.isBlank(newPassword) || StringUtils.isBlank(platformTag) || StringUtils.isBlank(encodedUserToken)) {
                createErrorResponse(APIReturnCode.INVALID_PARAMS)
                return
            }
            Player player = Player.findByUserCorrelationId(encodedUserToken)

            if (player == null) {
                createErrorResponse(APIReturnCode.INVALID_PLAYER_CORRELATION_ID)
                return
            } else if (!StringUtils.equals(player.site?.shortName, accountSystem) || !StringUtils.equals(player.email, email)) {
                createErrorResponse(APIReturnCode.INVALID_PLAYER_EMAIL_ID)
                return
            } else if (!player.reactivate) {
                createErrorResponse(APIReturnCode.INVALID_PLAYER_REACTIVE)
                return
            }

            def resetResult = playerService.reactivatePlayer(player, newPassword)
            if (resetResult?.returnCode == APIReturnCode.OK) {
                log.info(" password reset completed for player :  " + player.id)
                def result = sessionService.authenticatePlayer(player.userName, newPassword, getIp(request), platformTag, accountSystem, request.getHeader("User-Agent"), false,false)
                if (result.returnCode == APIReturnCode.OK) {
                    Session session = sessionService.getSession(result.token)
                    setEvolveCookies(request,response, session)
                    result.player.playerExtra.userAgentDeviceString = request.getHeader("User-Agent")
                    result.player.save()
                    /*render(status: 200, contentType: 'application/json') {
                        createPlayerProfileJSONResponse(session, false)
                    }*/
                    createReactivatePlayerJSONResponse(session)
                    return
                }
                if (result.returnCode == APIReturnCode.PLAYER_NOT_PERMITTED) {
                    createErrorResponse(APIReturnCode.PLAYER_NOT_PERMITTED)
                    return
                }
                createErrorResponse(APIReturnCode.PLAYER_NOT_FOUND)
            } else {
                createErrorResponse(APIReturnCode.PLAYER_NOT_PERMITTED)
            }
        } catch (Exception e) {
            log.error("Caught Exception in PlayerController.reactivatePlayer()", e)
            createErrorResponse(APIReturnCode.ERROR)
        }
    }//reactivatePlayer()

    /**
     * gets the jackpot winning details if won by the player.
     */
    def getOpenWinsForPlayer() {
        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }
        long startTime = System.currentTimeMillis();
        JSONObject payload = request.JSON
        if(payload == null){
            return
        }
        String loggerId = getLoggerID() + "-getOpenWinsForPlayer()-";
        log.info(loggerId + "Request received with payload " + payload);
        try {
            //No need of player validation as players session is already validated
            String playerId = session.player?.id.toString()
            String siteShortName = payload.siteShortName

            if (!Strings.valueNotNullOrEmpty.test(siteShortName)) {
                log.info(loggerId + "Response provided is " + "Failed - Invalid request received error in payload Invalid Site ID");
                renderFailureJsonMessage(HttpStatus.BAD_REQUEST, "Failed - Invalid request received error in payload Invalid Site ID")
            }

            Site site = siteService.getSite(siteShortName);
            if (site == null) {
                log.info(loggerId + "Response provided is " + "Invalid Site name");
                renderFailureJsonMessage(HttpStatus.BAD_REQUEST, "Invalid Site name")
            }

            //methodName#param1#param2#param3#....paramn
            //getOpenWinsForPlayer#externalPlayerId#externalSiteId
            //String jsonParams = "getOpenWinsForPlayer#${playerId}#${site?.shortName}"
            Map<String,String> jsonParams = new HashMap();
            jsonParams.put("method","getOpenWinsForPlayer")
            jsonParams.put("externalPlayerId",playerId)
            jsonParams.put("externalSiteId",site?.shortName)

            //config in site table upto : http://localhost:8080/revolve/api/jackpot/
            def jackpotResponse = invokeJackpotSystem(site?.jackpotSystemUrl + "getOpenWinsForPlayer", jsonParams, site?.jackpotAuthenticationKey, site?.jackpotExternalSystemId);
            if (jackpotResponse?.result == 0) {
                renderSuccessJsonMessage(HttpStatus.OK, jackpotResponse)
                log.info(loggerId + "Response provided is " + jackpotResponse);
                log.info(loggerId + "processed successfully in " + (System.currentTimeMillis() - startTime) + " milli seconds");
                return
            } else {
                log.info(loggerId + "Response provided is " + jackpotResponse);
                createErrorResponse(APIReturnCode.JACKPOT_SYSTEM_ERROR_RESPONSE)
                return
            }
        } catch (Exception exception) {
            log.error(loggerId + "Exception occured in getOpenWinsForPlayer and the exception is " + exception);
            renderFailureJsonMessage(HttpStatus.INTERNAL_SERVER_ERROR, exception.getCause())
            return
        }
    }


    /**
     * winJackpot
     * @return
     */
    def winJackpot() {
        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }
        long startTime = System.currentTimeMillis();
        JSONObject payload = request.JSON
        if(payload == null){
            return
        }
        String loggerId = getLoggerID() + "-winJackpot()-";
        log.info(loggerId + "Request received with payload " + payload);
        try {
            //No need of player validation as players session is already validated
            String playerId = session.player?.id.toString()
            String siteShortName = payload.siteShortName
            String jackpotInstanceId = payload.jackpotInstanceId
            //TODO : Not sure if mandatory so no validations in place for this param
            //TODO : not required in payload we can send base currency of site
            String currencyIso3 = payload.currencyIso3

            if (!Strings.valueNotNullOrEmpty.test(jackpotInstanceId)) {
                log.info(loggerId + "Response provided is " + "Failed - Invalid request received error in payload Invalid Jackpot Instance ID");
                renderFailureJsonMessage(HttpStatus.BAD_REQUEST, "Failed - Invalid request received error in payload Invalid Jackpot Instance ID")
            }

            if (!Strings.valueNotNullOrEmpty.test(siteShortName)) {
                log.info(loggerId + "Response provided is " + "Failed - Invalid request received error in payload Invalid External Site ID");
                renderFailureJsonMessage(HttpStatus.BAD_REQUEST, "Failed - Invalid request received error in payload Invalid External Site ID")
            }

            Site site = siteService.getSite(siteShortName);
            if (site == null) {
                log.info(loggerId + "Response provided is " + "Invalid Site name");
                renderFailureJsonMessage(HttpStatus.BAD_REQUEST, "Invalid Site name")
            }

            //methodName#param1#param2#param3#....paramn
            //winJackpot#externalPlayerId#jackpotInstanceId#currencyIso3
            //String jsonParams = "winJackpot#${playerId}#${jackpotInstanceId}#${site?.currency?.iso}"
            Map<String,String> jsonParams = new HashMap();
            jsonParams.put("method","winJackpot")
            jsonParams.put("externalPlayerId",playerId)
            jsonParams.put("jackpotInstanceId",jackpotInstanceId)
            jsonParams.put("currencyIso3",site?.currency?.iso)

            def jackpotResponse = invokeJackpotSystem(site?.jackpotSystemUrl + "winJackpot", jsonParams, site?.jackpotAuthenticationKey, site?.jackpotExternalSystemId);
            if (jackpotResponse?.result == 0) {
                renderSuccessJsonMessage(HttpStatus.OK, jackpotResponse)
                log.info(loggerId + "Response provided is " + jackpotResponse);
                log.info(loggerId + "processed successfully in " + (System.currentTimeMillis() - startTime) + " milli seconds");
                return
            } else {
                log.info(loggerId + "Response provided is " + jackpotResponse);
                createErrorResponse(APIReturnCode.JACKPOT_SYSTEM_ERROR_RESPONSE)
                return
            }
        }catch(Exception exception){
            log.error(loggerId + "Exception occured in winJackpot and the exception is " + exception);
            renderFailureJsonMessage(HttpStatus.INTERNAL_SERVER_ERROR, exception.getCause())
            return
        }
    }


    /**
     * creditJackpot
     * @return
     */
    def creditJackpot() {
        long startTime = System.currentTimeMillis();
        String loggerId = getLoggerID() + "-creditJackpot()-";
        JSONObject payload = request.JSON
        if(payload == null){
            return
        }
        log.info(loggerId + "Request received with payload " +payload);
        try {
            //TODO : Request params validation
            // Create a finalcial transaction for player with win amount
            TransactionType transactionType = TransactionType.findByShortName(TransactionType.SHORT_NAME.jackpotWin.toString())
            Player player = playerService.findById(payload?.playerId)
            Game game = Game.findByShortName(payload?.externalGameId)
            if(player!=null && game != null) {
                def transaction = transactionService.insertCashTransaction(player,
                        game,
                        BigDecimal.ZERO,
                        new BigDecimal(payload.wonAmount),
                        payload?.jackpotShortName,
                        null,
                        payload?.externalTransactionId,
                        null,
                        null,
                        null,
                        transactionType)
                renderSuccessJsonMessage(HttpStatus.OK ,"Success - Jackpot Has been Credited to Player")
                log.info(loggerId + "Response provided is " + "Success - Jackpot Has been Credited to Player "+player.id);
                log.info(loggerId + "processed successfully in " + (System.currentTimeMillis() - startTime) + " milli seconds");
                return
            }else{
                log.info(loggerId + "Invalid player or game.");
                renderFailureJsonMessage(HttpStatus.BAD_REQUEST, "Invalid Player or Game")
                return
            }
        }catch(Exception exception){
            log.error(loggerId + "Exception occured in winJackpot and the exception is " + exception);
            renderFailureJsonMessage(HttpStatus.INTERNAL_SERVER_ERROR, exception.getCause())
            return
        }
    }

    private boolean checkNotNullAndNotZero(BigDecimal limit) {
        return limit != null && limit > 0
    }

    /**
     *  Create Registration response for the Player.
     */
    def createPlayerRegistrationJSONResponse(Session session) {
        ProfileDetailsDTO profileDetailsDTO = new ProfileDetailsDTO()
        try {
            profileDetailsDTO = createPlayerProfileJSONResponse(session, profileDetailsDTO)
            //  Prepare Player Registration Bonus awarded details
            profileDetailsDTO = prepareRegistrationBonusDTO(session, profileDetailsDTO)
        } catch (Exception _exp) {
            log.error("Error while create Player Registration Response::: " + _exp.getMessage())
        }
        respond profileDetailsDTO
    }

    /**
     * Create Login response for the Player.
     */
    def createPlayerLoginJSONResponse(Session session) {
        ProfileDetailsDTO profileDetailsDTO = new ProfileDetailsDTO()
        try {
            profileDetailsDTO = createPlayerProfileJSONResponse(session, profileDetailsDTO)
            //  Prepare Player Registration Bonus awarded details
            profileDetailsDTO = prepareLoginBonusDTO(session, profileDetailsDTO)
        } catch (Exception _exp) {
            log.error("Error while create Player Login Response::: " + _exp.getMessage())
        }
        respond profileDetailsDTO
    }

    /**
     * Create Redirected Profile response for the Player.
     */
    def createPlayerRedirectedProfileJSONResponse(Session session) {
        ProfileDetailsDTO profileDetailsDTO = new ProfileDetailsDTO()
        try {
            profileDetailsDTO = createPlayerProfileJSONResponse(session, profileDetailsDTO)
        } catch (Exception _exp) {
            log.error("Error while create Player RedirectedProfile Response::: " + _exp.getMessage())
        }
        respond profileDetailsDTO
    }

    /**
     * Create Reactivate response for the Player.
     */
    def createReactivatePlayerJSONResponse(Session session) {
        ProfileDetailsDTO profileDetailsDTO = new ProfileDetailsDTO()
        try {
            profileDetailsDTO = createPlayerProfileJSONResponse(session, profileDetailsDTO)
        } catch (Exception _exp) {
            log.error("Error while create ReactivatePlayer Response::: " + _exp.getMessage())
        }
        respond profileDetailsDTO
    }
    /**
     * Create player profile response JSON
     *      :   if regBonusInRespFlag is true then will send player registration bonus awarded details in the profile response, otherwise will not send these details.
     * @param session
     * @return
     */
    private ProfileDetailsDTO createPlayerProfileJSONResponse(Session session, ProfileDetailsDTO profileDetailsDTO) {
        log.info("Player::" + session.player.id)
        Account cash = accountService.getCashAccount(session.player)
        Account bonus = accountService.getBonusAccount(session.player)
        Account loyalty = accountService.getLoyaltyAccount(session.player)

        try {
            if (null == profileDetailsDTO) {
                profileDetailsDTO = new ProfileDetailsDTO()
            }

            profileDetailsDTO.setUsername(session.player.userName)
            profileDetailsDTO.setTitle(session.player.salutation)
            profileDetailsDTO.setFirstName(session.player.firstName)
            profileDetailsDTO.setLastName(session.player.lastName)
            profileDetailsDTO.setDateOfBirth(CalendarUtility.convertDateToString(session.player.dateOfBirth, "yyyy-MM-dd"))
            profileDetailsDTO.setEmail(session.player.email)
            profileDetailsDTO.setMobilePhoneNumber(session.player.mobileNumber)
            profileDetailsDTO.setAddress(prepareAddressDTO(session))
            profileDetailsDTO.setChallengeAnswer(session.player.securityAnswer)
            profileDetailsDTO.setPreferredCurrency(bonus.currency.iso)
            profileDetailsDTO.setIncludeExternalBalance("")
            profileDetailsDTO.setAccountSystemTag(session.player.site.shortName)
            profileDetailsDTO.setBalanceType("")
            profileDetailsDTO.setBalance(prepareBalanceDTO(cash, bonus))
            profileDetailsDTO.setPin("")
            profileDetailsDTO.setReferAFriendCode("")
            profileDetailsDTO.setCountryCallingCode(session.player.country.dialcode)
            profileDetailsDTO.setPinIsVerified(session.player.isEmailValidated)
            profileDetailsDTO.setVip(session.player.getVipLevelShortName())
            profileDetailsDTO.setAutoLoginPreference(session.player.autoLoginPreferenceDescription[session.player.autoLoginPreference])
            profileDetailsDTO.setDepositAmount(0)
            profileDetailsDTO.setTermsAndCondsVersion(session.player.termsAndConditionsVersion)
            profileDetailsDTO.setPrivacyPolicyVersion(session.player.privacyPolicyAcceptedVersion == null ? 0 : session.player.privacyPolicyAcceptedVersion)
            profileDetailsDTO.setEmailIsVerified(session.player.isEmailValidated)
            profileDetailsDTO.setTrackingCode(session.player.referrerTag)
            profileDetailsDTO.setPspType("EPG")
            profileDetailsDTO.setContactableByOthers(session.player.isContactableByOthers)
            profileDetailsDTO.setChallengeQuestionId(session.player.securityQuestion?.id)
            profileDetailsDTO.setUserCorrelationId(session.player.userCorrelationId)
            profileDetailsDTO.setRegistrationLevel("FULL")
            profileDetailsDTO.setPlatformTag(session.player.platformTag)
            profileDetailsDTO.setDemoPlay("")
            profileDetailsDTO.setPasswordIsOneShot(session.player.isPasswordOneshot)
            profileDetailsDTO.setContactableByUs(session.player.isContactable)
            profileDetailsDTO.setContactableBySms(session.player.isContactableBySms);
            profileDetailsDTO.setDepositTermsAndCondsVersion(session.player.depositTermsAndConditionsVersion)
            profileDetailsDTO.setLoyaltyPointsAwarded(loyalty.balance == null ? BigDecimal.ZERO : loyalty.balance.setScale(0, RoundingMode.DOWN))
            profileDetailsDTO.setRealityCheckLimit(session.player.realityCheckLimit)
            profileDetailsDTO.setDepositCount((session.player.playerExtra == null || session.player.playerExtra.depositCount == null) ? BigDecimal.ZERO : session.player.playerExtra.depositCount)
            profileDetailsDTO.setTotalDepositAmount(session.player.playerExtra == null ? BigDecimal.ZERO : session.player.playerExtra.scaledTotalDepositAmount)
            profileDetailsDTO.setSmsValidationEnabled((session.player.site.smsValidationEnabled && session.player.country.smsValidationEnabled))
            profileDetailsDTO.setSmsValidated(session.player.isSmsValidated)
            profileDetailsDTO.setBonusOptOut(session.player.bonusOptOut)
            profileDetailsDTO.setHasPlayedOnApp(session.player.playerExtra.hasPlayedOnApp)
            profileDetailsDTO.setBonusAbuser(session.player.isBonusAbuser)
            Date activeOptInThresholdDate = paramService.getDate("threshold.date.active.optin")
            profileDetailsDTO.setShowOptInPopUp((session.player.playerExtra.showOptInPopUp && null != activeOptInThresholdDate && session.player.createdAt.before(activeOptInThresholdDate)) ? true : false)
            profileDetailsDTO.setContactableByCall(session.player.isContactableByCall)
            profileDetailsDTO.setContactableByPost(session.player.isContactableByPost)
            profileDetailsDTO.setWelcomeOfferAbuser((session.player.site.enableWelcomeOfferRestriction && session.player.isWelcomeOfferAbuser) ? true : false)
            profileDetailsDTO.setWithdrawConfirmationOptIn(session.player.withdrawConfirmationOptIn)
            profileDetailsDTO.setPromotionsOptedIn(playerPromotionService.findActivePromotionsByPlayer(session.player.id))
            profileDetailsDTO.setDocumentVerificationStatus((null != session.player?.playerExtra?.docVerificationStatusId) ? ((DocumentVerificationStatus) DocumentVerificationStatus.getStatusType(session.player.playerExtra.docVerificationStatusId.intValue())).name : "")
            profileDetailsDTO.setIgnoreUkWithdrawalRestrictions(session.player.site.ignoreUkWithdrawalRestrictions)
        } catch (Exception _exp) {
            log.error("Error while create Player Profile Response::: " + _exp.getMessage())
        }
        return profileDetailsDTO
    }

    private AddressDTO prepareAddressDTO(Session session) {
        return new AddressDTO(
                country: session.player.country,
                country_code: session.player.country.iso3,
                address: session.player.address_1,
                city: session.player.city,
                houseNumber: session.player.houseNumber,
                postCode: session.player.postcode,
                county: session.player.county
        )
    }
    /**
     * Method to prepare ewalletNonWithdrawable, ewalletWithdrawable, externalAccount and total balance details.
     * @param cash
     * @param bonus
     * @return balanceDTO
     */
    private BalanceDTO prepareBalanceDTO(Account cash, Account bonus) {
        return new BalanceDTO(
                total: prepareAmountDetailsDTO((cash.balance).add(bonus.balance), cash.currency.iso),
                ewalletNonWithdrawable: prepareWithdrawbleAmountDetailsDTO(bonus.balance, bonus.currency.iso),
                sessionReturns: 0,
                externalAccount: prepareAmountDetailsDTO(0, ""),
                sessionStakes: 0,
                ewalletWithdrawable: prepareWithdrawbleAmountDetailsDTO(cash.balance, cash.currency.iso)
        )
    }

    private AmountDetailsDTO prepareAmountDetailsDTO(BigDecimal amount, String currency) {
        return new AmountDetailsDTO(amount, currency)
    }

    private WithdrawbleAmountDetailsDTO prepareWithdrawbleAmountDetailsDTO(BigDecimal amount, String currency) {
        return new WithdrawbleAmountDetailsDTO(amount, currency)
    }

    /**
     * Method to prepare player registration bonus awarded details. If the player is awarded with registration bonus then will set the bonusAllotedFlag to True otherwise False.
     * @param session
     * @param profileDetailsDTO
     * @return profileDetailsDTO
     */
    private ProfileDetailsDTO prepareLoginBonusDTO(Session session, ProfileDetailsDTO profileDetailsDTO) {
        List<PlayerBonus> playerBonuses = PlayerBonus.findAllByPlayerAndSessionAndAwardedAmountGreaterThan(session
                .player, session, BigDecimal.ZERO)
        List<PlayerFreeRounds> playerFreeRounds = PlayerFreeRounds.findAllByPlayerAndSession(session.player, session)
        return prepareBonusDTO(session, profileDetailsDTO, playerBonuses, playerFreeRounds);
    }

    /**
     * Method to prepare player registration bonus awarded details. If the player is awarded with registration bonus then will set the bonusAllotedFlag to True otherwise False.
     * @param session
     * @param profileDetailsDTO
     * @return profileDetailsDTO
     */
    private ProfileDetailsDTO prepareRegistrationBonusDTO(Session session, ProfileDetailsDTO profileDetailsDTO) {
        List<PlayerBonus> playerBonuses = PlayerBonus.findAllByPlayerAndAwardedAmountGreaterThan(session.player, BigDecimal.ZERO)
        List<PlayerFreeRounds> playerFreeRounds = PlayerFreeRounds.findAllByPlayer(session.player)
        return prepareBonusDTO(session, profileDetailsDTO, playerBonuses, playerFreeRounds);
    }

    /**
     * Method to prepare player SMS Validation bonus awarded details.
     * @param session
     * @param profileDetailsDTO
     * @return profileDetailsDTO
     */
    private ProfileDetailsDTO prepareSMSValidationBonusDTO(Session session, ProfileDetailsDTO profileDetailsDTO) {
        List<Bonus> validSMSValidationBonuses = bonusService.findAccountValidationBonusesBySiteAndAccountValidationTypes(session.player.site, AccountValidationType.SMS, AccountValidationType.EITHER);
        List<PlayerBonus> playerBonuses = PlayerBonus.findAllByPlayerAndBonusInListAndAwardedAmountGreaterThan(session.player,
                validSMSValidationBonuses, BigDecimal.ZERO)
        List<PlayerFreeRounds> playerFreeRounds = PlayerFreeRounds.findAllByPlayerAndBonusInList(session.player, validSMSValidationBonuses)
        return prepareBonusDTO(session, profileDetailsDTO, playerBonuses, playerFreeRounds);
    }


    private ProfileDetailsDTO prepareBonusDTO(Session session, ProfileDetailsDTO profileDetailsDTO, List<PlayerBonus> playerBonuses, List<PlayerFreeRounds> playerFreeRounds) {
        Account cash = accountService.getCashAccount(session.player)
        profileDetailsDTO.bonusAllotedFlag = session.player?.playerExtra.registrationBonusAwarded
        profileDetailsDTO.bonusDetails = new ArrayList<BonusDetailsDTO>()
        profileDetailsDTO.freeRoundDetails = new ArrayList<FreeRoundDetailsDTO>()

        if (playerBonuses != null && playerBonuses.size() > 0) {
            log.debug("PlayerId:: " + session.player?.id + " ::PlayerBonuses:: " + playerBonuses?.size())
            BigDecimal bonusAmt = BigDecimal.ZERO
            List<String> allowedGamesList;
            if (playerBonuses != null && playerBonuses.size() > 0) {
                for (PlayerBonus playerBonus : playerBonuses) {
                    allowedGamesList = new ArrayList<String>()
                    if (playerBonus.status == RewardStatus.Active.id) {
                        profileDetailsDTO.bonusAllotedMessage = "You received a " + cash.currency.prefix + playerBonus.awardedAmount + " bonus."
                        bonusAmt = bonusAmt.add(playerBonus.awardedAmount)
                    }
                    if(playerBonus.bonus.rewardType == BonusRewardType.BonusFunds.id && playerBonus.bonus.bonusType != BonusType.Manual.id){
                        for(FreeRoundsGameConfig freeRoundsGameConfig : playerBonus.bonus.freeRoundsGameConfig) {
                            allowedGamesList.add(freeRoundsGameConfig.getGame().getShortName())
                        }
                    }
                    profileDetailsDTO.getBonusDetails().add(new BonusDetailsDTO(playerBonus.awardedAmount,
                            new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(playerBonus.expires),
                            ((PlayerRewardStatus) PlayerRewardStatus.getStatusType(playerBonus.status)).name,
                            ((BonusType) BonusType.getBonusType(playerBonus.bonus.bonusType)).name,
                            playerBonus.bonus.description, playerBonus.playerDescription, allowedGamesList));
                }
                if (null != profileDetailsDTO.bonusAllotedMessage && null != profileDetailsDTO.balance) {
                    profileDetailsDTO.balance.total.amount = bonusAmt.add(cash.balance)
                    profileDetailsDTO.balance.ewalletNonWithdrawable.amount = bonusAmt
                }
            }
        }
        if (playerFreeRounds != null && playerFreeRounds.size() > 0) {
            log.debug("PlayerId:: " + session.player?.id + " ::PlayerFreeRounds:: " + playerFreeRounds?.size())
            if (playerFreeRounds != null && playerFreeRounds.size() > 0) {
                int freeRounds = 0
                String status = "";
                for (PlayerFreeRounds playerFreeRound : playerFreeRounds) {
                    freeRounds += playerFreeRound.noOfFreeRounds.intValue()
                    if (playerFreeRound.gameProviders?.equals(RGSName.NETENT)) {
                        status = "Active";
                    } else {
                        status = ((PlayerRewardStatus) PlayerRewardStatus.getStatusType(playerFreeRound.status)).name
                    }
                    FreeRoundDetailsDTO freeRoundDetailsDTO = new FreeRoundDetailsDTO(playerFreeRound.noOfFreeRounds,
                            new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(playerFreeRound.freeRoundsValidity),
                            ((BonusType) BonusType.getBonusType(playerFreeRound.bonus.bonusType)).name,
                            playerFreeRound.bonus.description,
                            status,
                            playerFreeRound.gameProviders);

                    List<FreeRoundsGameConfig> freeRoundsGameConfigLst = FreeRoundsGameConfig.findAllByBonus(playerFreeRound.bonus)
                    for (FreeRoundsGameConfig freeRoundsGameConfig : freeRoundsGameConfigLst) {
                        if (freeRoundsGameConfig?.game?.rgs?.name.equals(playerFreeRound?.gameProviders)) {
                            freeRoundDetailsDTO.getGame().add(freeRoundsGameConfig.game.shortName)
                        }
                    }
                    profileDetailsDTO.getFreeRoundDetails().add(freeRoundDetailsDTO)
                }
                profileDetailsDTO.freeRoundsAllotedMessage = "You received a " + freeRounds + " free spins."
            }
        }
        return profileDetailsDTO
    }

    /**
     * method to perform session logout.
     * @param session
     */
    private sessionLogout(Session session) {

        if (session != null) {
            sessionService.closeSession(session, Session.CLOSED, "Player logged out")
        }
        Cookie[] cookies = request.getCookies();
        for(Cookie cookie : cookies) {
            if(cookie.name.equalsIgnoreCase(EvolveConstants.cookieSessionCorrelation)) {
                cookie.setValue("");
                cookie.setMaxAge(0);
                cookie.setPath("/");
                response.addCookie(cookie);
            }
        }
    }

    /**
     * create SMS Validation Response JSON
     * @param session
     * @return
     */
    def createSMSValidationJSONResponse(Session session) {
        log.info("createSMSValidationJSONResponse:Player::" + session.player.id)
        Account cash = accountService.getCashAccount(session.player)
        SMSValidationDetailsDTO smsValidationDetailsDTO
        ProfileDetailsDTO profileDetailsDTO = prepareSMSValidationBonusDTO(session, new ProfileDetailsDTO())
        try {
            smsValidationDetailsDTO = new SMSValidationDetailsDTO(
                    bonusAllotedFlag: profileDetailsDTO.getBonusAllotedFlag(),
                    bonusAllotedMessage: profileDetailsDTO.getBonusAllotedMessage(),
                    bonusDetails: profileDetailsDTO.getBonusDetails(),
                    freeRoundDetails: profileDetailsDTO.getFreeRoundDetails(),
                    freeRoundsAllotedMessage: profileDetailsDTO.getFreeRoundsAllotedMessage(),
                    smsValidated: session.player.isSmsValidated
            )
        } catch (Exception _exp) {
            log.error("Error while create SMS validation Response:: " + _exp.getMessage())
        }
        respond smsValidationDetailsDTO
    }

    /**
     * Method fetches player all deposit and depositOverTimePeriod bonuses.
     * @param session
     * @return eligibleBonusRespDTO
     */
    def getPlayerEligibleDepositBonus() {
        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }
        if(session?.player?.isBonusAbuser || session?.player?.isBonusOptOut() ){
            log.info("getPlayerEligibleDepositBonus::Player:: bonus abuser" + session?.player?.id)
            respond new ArrayList<PlayerEligibleBonusDTO>();
            return
        }
        log.info("getPlayerEligibleDepositBonus::Player:: " + session?.player?.id)
        List<PlayerEligibleBonusDTO> playerEligibleBonusDTOLst = playerBonusService.getPlayerEligibleDepositBonus(session.player, null, null, true,null, null)
        EligibleBonusRespDTO eligibleBonusRespDTO = createPlayerEligibleDepositBonusJSONResponse(session, playerEligibleBonusDTOLst)
        if(null != eligibleBonusRespDTO){
            respond eligibleBonusRespDTO
        }
    }

    /**
     * Method fetches player all deposit and depositOverTimePeriod bonuses.
     * @param session
     * @return eligibleBonusRespDTO
     */
    def getPlayerEligibleDepositBonusForBonusCode() {
        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }
        if(session?.player?.isBonusAbuser || session?.player?.isBonusOptOut() ){
            log.info("getPlayerEligibleDepositBonus::Player:: bonus abuser" + session?.player?.id)
            respond new ArrayList<PlayerEligibleBonusDTO>();
            return
        }
        def payload = request.JSON
        log.info("getPlayerEligibleDepositBonus::Player:: " + session?.player?.id+" request "+payload)
        if(StringUtils.isEmpty(payload?.bonusCode)){
            log.info("getPlayerEligibleDepositBonus:: bonus code is null or empty")
            respond new ArrayList<PlayerEligibleBonusDTO>();
            return
        }
        List<PlayerEligibleBonusDTO> playerEligibleBonusDTOLst = playerBonusService.getPlayerEligibleDepositBonus(session.player, null, null, true,payload?.bonusCode, null)
        EligibleBonusRespDTO eligibleBonusRespDTO = createPlayerEligibleDepositBonusJSONResponse(session, playerEligibleBonusDTOLst)
        if(null != eligibleBonusRespDTO){
            respond eligibleBonusRespDTO
        }
    }

    /**
     * method to prepare list of all the eligible deposit and depositOverTimePeriod bonuses.
     * @param session
     * @param playerEligibleBonusDTOLst
     * @return
     */
    private EligibleBonusRespDTO createPlayerEligibleDepositBonusJSONResponse(Session session, List<PlayerEligibleBonusDTO> playerEligibleBonusDTOLst) {
        log.info("createPlayerEligibleDepositBonusJSONResponse::Player:: " + session.player.id)
        EligibleBonusRespDTO eligibleBonusRespDTO = new EligibleBonusRespDTO()
        eligibleBonusRespDTO.setBonusDetails(new ArrayList<EligibleBonusDetailsDTO>())
        eligibleBonusRespDTO.setFreeRoundDetails(new ArrayList<EligibleFreeRoundDetailsDTO>())
        Map<String, EligibleBonusDetailsDTO> eligibleBonusMapByName = new HashMap<String, EligibleBonusDetailsDTO>()
        Map<String, EligibleFreeRoundDetailsDTO> eligibleFreeRoundsMapByName = new HashMap<String, EligibleFreeRoundDetailsDTO>()
        boolean hasBonusCode = false
        Currency playerCurrency = session.player.getCurrency()
        try {
            playerEligibleBonusDTOLst.collect{ playerEligibleBonusDTO ->
                hasBonusCode = StringUtils.isNotBlank(playerEligibleBonusDTO.getBonus().getBonusCode())
                if (playerEligibleBonusDTO.getBonus().rewardType == BonusRewardType.BonusFunds.id) {
                    if(eligibleBonusMapByName.containsKey(playerEligibleBonusDTO.getBonus().name + "~" + BonusRewardType.BonusFunds.id)){
                        EligibleBonusDetailsDTO eligibleBonusDetailsDTO = eligibleBonusMapByName.get(playerEligibleBonusDTO.getBonus().name + "~" + BonusRewardType.BonusFunds.id)
                        eligibleBonusDetailsDTO.getTiers().add(this.createEligibleBonusPayoutDetailsDTO(playerEligibleBonusDTO, playerCurrency))
                    } else{
                        eligibleBonusMapByName.put(playerEligibleBonusDTO.getBonus().name + "~" + BonusRewardType.BonusFunds.id, this.createEligibleBonusDetailsDTO(playerEligibleBonusDTO, hasBonusCode, playerCurrency))
                    }
                } else if(playerEligibleBonusDTO.getBonus().rewardType == BonusRewardType.FreeRounds.id) {
                    List<FreeRoundsGameConfig> freeRoundsGameConfigLst = FreeRoundsGameConfig.findAllByBonusDepConfig(playerEligibleBonusDTO.getBonusDepConfig())
                    List<String> gameNameLst = null
                    if(null != freeRoundsGameConfigLst){
                        gameNameLst = new ArrayList<String>()
                        freeRoundsGameConfigLst.collect{ freeRoundsGameConfig ->
                            gameNameLst.add(freeRoundsGameConfig.game.shortName)
                        }
                    }
                    if(eligibleFreeRoundsMapByName.containsKey(playerEligibleBonusDTO.getBonus().name + "~" + BonusRewardType.FreeRounds.id)){
                        EligibleFreeRoundDetailsDTO eligibleFreeRoundDetailsDTO = eligibleFreeRoundsMapByName.get(playerEligibleBonusDTO.getBonus().name + "~" + BonusRewardType.FreeRounds.id)
                        eligibleFreeRoundDetailsDTO.getTiers().add(this.createEligibleFreeRoundPayoutDetailsDTO(playerEligibleBonusDTO, gameNameLst, playerCurrency))
                    } else{
                        eligibleFreeRoundsMapByName.put(playerEligibleBonusDTO.getBonus().name + "~" + BonusRewardType.FreeRounds.id, this.createEligibleFreeRoundDetailsDTO(playerEligibleBonusDTO, hasBonusCode, gameNameLst, playerCurrency))
                    }
                }
            }
            eligibleBonusMapByName.entrySet().iterator().collect { eligibilityBonus ->
                eligibleBonusRespDTO.getBonusDetails().add(eligibilityBonus.value)
            }
            eligibleFreeRoundsMapByName.entrySet().iterator().collect { eligibilityFreeRound ->
                eligibleBonusRespDTO.getFreeRoundDetails().add(eligibilityFreeRound.value)
            }
        } catch (Exception _exp) {
            log.error("ERROR while create Player Eligible Deposit Bonus Response:: " + _exp.getMessage())
            createErrorResponse(APIReturnCode.ERROR)
            return
        }
        return eligibleBonusRespDTO
    }

    /**
     * Method to create eligible Bonus Details
     * 1.   Fetch bonus payout details and prepare tiers
     * 2.   Fetch bonus currency language details
     * @param playerEligibleBonusDTO
     * @param hasBonusCode
     * @return
     */
    private EligibleBonusDetailsDTO createEligibleBonusDetailsDTO(PlayerEligibleBonusDTO playerEligibleBonusDTO, boolean hasBonusCode, Currency playerCurrency){
        List<EligibleBonusPayoutDetailsDTO> eligibleBonusPayoutDetailsDTOLst = new ArrayList<EligibleBonusPayoutDetailsDTO>()
        eligibleBonusPayoutDetailsDTOLst.add(this.createEligibleBonusPayoutDetailsDTO(playerEligibleBonusDTO, playerCurrency))
        List<BonusByPaymentMethodsDTO> bonusPaymentMethods = bonusService.getBonusCurrentPaymentMenthods(playerEligibleBonusDTO.getBonus())
        this.maxDepositMethodRestriction(playerEligibleBonusDTO.playerId, bonusPaymentMethods)
        playerBonusService.removeBlockedPaymentMethods(playerEligibleBonusDTO.playerId, bonusPaymentMethods)
        return new EligibleBonusDetailsDTO(playerEligibleBonusDTO.getBonus().name, hasBonusCode, String.valueOf(playerEligibleBonusDTO.getBonus().identifier), eligibleBonusPayoutDetailsDTOLst,playerEligibleBonusDTO.getBonus().choiceCode, bonusPaymentMethods,playerEligibleBonusDTO.getBonus()?.cancelExistingPlayerBonuses!=null ? playerEligibleBonusDTO.getBonus()?.cancelExistingPlayerBonuses : false)
    }

    /**
     * Method to create Bonus Payout Details
     * @param playerEligibleBonusDTO
     * @return
     */
    private EligibleBonusPayoutDetailsDTO createEligibleBonusPayoutDetailsDTO(PlayerEligibleBonusDTO playerEligibleBonusDTO, Currency playerCurrency){
        return new EligibleBonusPayoutDetailsDTO(playerEligibleBonusDTO.getBonusConfigPayout().amount, playerEligibleBonusDTO.getBonusDepConfig().getDepositPercent(),
                playerEligibleBonusDTO.getBonusDepConfig().getMinDeposit(), playerEligibleBonusDTO.getBonusDepConfig().getMaxDeposit(),
                this.createBonusLangNameMap(playerEligibleBonusDTO.bonus, playerCurrency, playerEligibleBonusDTO.getBonusConfigPayout().amount, null,
                        playerEligibleBonusDTO.getBonusDepConfig().getMinDeposit(), playerEligibleBonusDTO.getBonusDepConfig().getMaxDeposit(),
                        playerEligibleBonusDTO.getBonusDepConfig().getDepositPercent(),playerEligibleBonusDTO.getPlayerDepositCount()), playerEligibleBonusDTO.getBonus().getIdentifier() + "-" + playerEligibleBonusDTO.getBonusDepConfig().getDepositCount())
    }

    /**
     * Method to create eligible Free Rounds Details
     * 1.   Fetch free rounds payout details and prepare tiers
     * 2.   Fetch bonus currency language details
     * @param playerEligibleBonusDTO
     * @param hasBonusCode
     * @param gameNameLst
     * @return
     */
    private EligibleFreeRoundDetailsDTO createEligibleFreeRoundDetailsDTO(PlayerEligibleBonusDTO playerEligibleBonusDTO, boolean hasBonusCode, List<String> gameNameLst, Currency playerCurrency){
        List<EligibleFreeRoundPayoutDetailsDTO> eligibleFreeRoundPayoutDetailsDTOLst = new ArrayList<EligibleFreeRoundPayoutDetailsDTO>()
        eligibleFreeRoundPayoutDetailsDTOLst.add(this.createEligibleFreeRoundPayoutDetailsDTO(playerEligibleBonusDTO, gameNameLst, playerCurrency))
        List<BonusByPaymentMethodsDTO> bonusPaymentMethods = bonusService.getBonusCurrentPaymentMenthods(playerEligibleBonusDTO.getBonus())
        this.maxDepositMethodRestriction(playerEligibleBonusDTO.playerId, bonusPaymentMethods)
        playerBonusService.removeBlockedPaymentMethods(playerEligibleBonusDTO.playerId, bonusPaymentMethods)
        return new EligibleFreeRoundDetailsDTO(playerEligibleBonusDTO.getBonus().name, hasBonusCode, String.valueOf(playerEligibleBonusDTO.getBonus().identifier), eligibleFreeRoundPayoutDetailsDTOLst,playerEligibleBonusDTO.bonus.choiceCode, bonusPaymentMethods,playerEligibleBonusDTO.getBonus()?.cancelExistingPlayerBonuses!=null ? playerEligibleBonusDTO.getBonus()?.cancelExistingPlayerBonuses : false)
    }

    /**
     * Method to create Free Rounds Payout Details
     * @param playerEligibleBonusDTO
     * @param gameNameLst
     * @return
     */
    private EligibleFreeRoundPayoutDetailsDTO createEligibleFreeRoundPayoutDetailsDTO(PlayerEligibleBonusDTO playerEligibleBonusDTO, List<String> gameNameLst, Currency playeCurrency){
        return new EligibleFreeRoundPayoutDetailsDTO(playerEligibleBonusDTO.getBonusDepConfig().noOfFreeRounds,
                playerEligibleBonusDTO.getBonusDepConfig().getMinDeposit(), playerEligibleBonusDTO.getBonusDepConfig().getMaxDeposit(), gameNameLst,
                this.createBonusLangNameMap(playerEligibleBonusDTO.bonus, playeCurrency, null, playerEligibleBonusDTO.getBonusDepConfig().noOfFreeRounds,
                        playerEligibleBonusDTO.getBonusDepConfig().getMinDeposit(), playerEligibleBonusDTO.getBonusDepConfig().getMaxDeposit(), null,playerEligibleBonusDTO.getPlayerDepositCount()),
                playerEligibleBonusDTO.getBonus().getIdentifier() + "-" + playerEligibleBonusDTO.getBonusDepConfig().getDepositCount(),playerEligibleBonusDTO.getBonusDepConfig().getDepositCount()
        )
    }

    /**
     * renders error message with provided http code
     * @param httpCode
     * @return
     */
    private renderSuccessJsonMessage(HttpStatus httpStatus, Object responseObject) {
        render(status: httpStatus.value(), contentType: 'application/json') {
            [
                    "success": responseObject
            ]
        }
        return
    }

    /**
     * renders error message with provided http code
     * @param httpCode
     * @return
     */
    private renderFailureJsonMessage(HttpStatus httpStatus, Object responseObject) {
        render(status: httpStatus.value(), contentType: 'application/json') {
            [
                    "failed": responseObject
            ]
        }
        return
    }

    /**
     * Used to generate unique id for logging purpose.
     * @return
     */
    String getLoggerID() {
        UUID loggerID = UUID.randomUUID();
        return loggerID.toString().replaceAll("-", "");
    }

    /**
     *
     * @param url
     * @param jsonParams
     * @param authorizationKey
     * @param externalSystemID
     * @return
     */
    def invokeJackpotSystem(String url, Map<String,String> jsonParams, String authorizationKey, String externalSystemID) {

        try {
            //Getting the configured external system connection time out value
            Param connectionTimeout = Param.findByParamKey('jackpotSystem.connectiontimeout')
            Param readTimeout = Param.findByParamKey('jackpotSystem.readtimeout')
            String methodName = jsonParams.get("method")
            RestBuilder rest = new RestBuilder(connectTimeout: new Integer(connectionTimeout != null ? connectionTimeout.val : 3000).intValue(),
                    readTimeout: new Integer(readTimeout != null ? readTimeout.val : 3000).intValue(),
                    proxy: null)
            RestResponse jackpotResponse = rest.post("${url}") {
                accept("application/json")
                contentType("application/json")
                header("Authorization", authorizationKey)
                header("ExternalSystemID", externalSystemID)
                if (methodName.equalsIgnoreCase("getOpenWinsForPlayer")) {
                    json {
                        externalPlayerId = jsonParams.get("externalPlayerId")
                        externalSiteId = jsonParams.get("externalSiteId")
                    }
                } else if (methodName.equalsIgnoreCase("winJackpot")) {
                    json {
                        externalPlayerId = jsonParams.get("externalPlayerId")
                        jackpotInstanceId = jsonParams.get("jackpotInstanceId")
                        currencyIso3 = jsonParams.get("currencyIso3")
                    }
                }
            }
            if(jackpotResponse?.getResponseEntity()?.statusCode == HttpStatus.OK) {
                def jsonResponse = jackpotResponse.json
                log.info("Received Success response from jackpot system : " + jsonResponse)
                return jsonResponse
            }else{
                def jsonResponse = jackpotResponse.json
                log.info("Received Error response from jackpot system : " + jsonResponse)
                return jsonResponse
            }
        } catch (Exception e) {
            log.error("Exception in acessing jackpot system because of : " + e.getCause())
            createErrorResponse(APIReturnCode.ERROR)
            return
        }

    }

    /**
     * Method to prepare language_currency_map details with all the configured languages.
     * @param playerEligibleBonusDTO
     * @return
     */
    private Map<String, String> createBonusLangNameMap(Bonus bonus, Currency playerCurrency, BigDecimal amount, Integer freeSpinsCount,
                                                       BigDecimal minDeposit, BigDecimal maxDeposit, BigDecimal depositPercentage,Integer depositCount){
        Map<String, String> bonusLangNameMap = new HashMap<String, String>()
        // fetching details from the bonus
        if(null != bonus){
            for(BonusLangName bonusLangNameObj : bonus.bonusLangName){
                bonusLangNameMap.put(bonusLangNameObj.language.iso,
                        Utils.replaceNameWithMatchingTokens(new BonusLangNameDTO(bonusLangNameObj.name, playerCurrency?.iso, playerCurrency?.prefix,
                                amount, freeSpinsCount, minDeposit, maxDeposit, depositPercentage, bonus.freeRoundsValidityDays,depositCount)));
            }
        }
        return bonusLangNameMap
    }

    /**
     * method will be used to identify the game launch done by mobile or not.
     * @param
     * @return
     */
    private boolean isMobile() {
        String reqAgent = request.getHeader("User-Agent")
        String patternString = "/Mobile|iP(hone|od|ad)|Android|BlackBerry|IEMobile|Kindle|NetFront|Silk-Accelerated|(hpw|web)OS|Fennec|Minimo|Opera M(obi|ini)|Blazer|Dolfin|Dolphin|Skyfire|Zune/"

        Pattern pattern = Pattern.compile(patternString);

        Matcher matcher = pattern.matcher(reqAgent);

        if (matcher.find())
            return true
        else
            return false

    }

    /**
     * Method used to remove Boku Payment Method if player has more than 1 deposit
     * @param playerId
     * @param bonusPaymentMethods
     */
    private void maxDepositMethodRestriction(Long playerId, List<BonusByPaymentMethodsDTO> bonusPaymentMethods){
        if( null != playerId){
            Player player = Player.findById(playerId)
            int depositCount = player.playerExtra?.depositCount
            if( null != player){
                if( player?.site?.enableMaxDepositMethodRestriction && player?.enableMaxDepositMethodRestriction && null != player.site.maxBokuDepositsAllowed && bonusPaymentMethods?.size() > 0 && depositCount >= player.site.maxBokuDepositsAllowed ){
                    Iterator<BonusByPaymentMethodsDTO> bonusByPaymentMethodsDTOIterator = bonusPaymentMethods.iterator()
                    while( bonusByPaymentMethodsDTOIterator.hasNext() ){
                        BonusByPaymentMethodsDTO paymentMehtod = bonusByPaymentMethodsDTOIterator.next()
                        if( paymentMehtod.paymentMethod.equalsIgnoreCase("BOKU")){
                            bonusByPaymentMethodsDTOIterator.remove()
                            break
                        }
                    }
                }
            }
        }
    }

    /**
     * method to OptIn/OptOut player to a Promotion.
     * @return The updated settings
     */
    def optInToPromotion() {
        def payload = request.JSON
        Session session = getEvolvePlayerSession()
        if (session == null || !session.isActive()) {
            createErrorResponse(APIReturnCode.INVALID_SESSION)
            return
        }
        if(StringUtils.isEmpty(payload."identifier"?.trim())){
            createErrorResponse(APIReturnCode.INVALID_PROMOTION_ID)
            return
        }
        String promotionIdentifier = payload."identifier"?.trim()
        boolean optIn = "${payload.optIn}".trim().toBoolean()
        log.debug("optInToPromotion playerId: " + session.player.id + " promotionIdetifier: " + promotionIdentifier + " OptInFlag:" + optIn+" isBonusAbuser:"+session.player.isBonusAbuser)
        if( optIn && session.player.bonusOptOut) {
            createErrorResponse(APIReturnCode.PROMOTION_NOT_OPTEDIN_AS_OPTED_OUT_OF_BONUS)
            return
        }
        if( optIn && session.player.isBonusAbuser ){
            createErrorResponse(APIReturnCode.PROMOTION_NOT_OPTEDIN_BY_BONUS_ABUSER)
            return
        }
        def result = optIn ? playerPromotionService.addPlayerToPromotion(promotionIdentifier, session.player) : playerPromotionService.removePlayerFromPromotion(promotionIdentifier, session.player)

        if (result.returnCode == APIReturnCode.OK) {
            String noteText = (optIn ? "Player has Opted-In to the promotion: " : "Player has OptedOut from the promotion: ") + result?.promotionName
            notesService.create(session.player, Operator.findByUsername("nektan"), NoteType.findByShortName(NoteType.SHORT_NAMES.PLAYER_OPTIN_OPTOUT), noteText, Note.SEVERITY_NORMAL, null, false)
            render(status: 200, contentType: 'application/json') {
                [
                        optIn ? g.message(code: 'promotion.player.optin.succ.msg') : g.message(code: 'promotion.player.optout.succ.msg')
                ]
            }
        } else {
            createErrorResponse(result.returnCode)
        }
    }

    /**
     * method to check the given bonusCode is valid or not by the event type.
     * @param eventType
     * @param bonusCode
     * @param accountSystemTag
     * @param countryCode
     * @return ["valid" : true/false]
     */
    def isBonusCodeValid() {
        def payload = request.JSON
        try{
            if(StringUtils.isEmpty(payload?.eventType)){
                log.info("isBonusCodeValid:: event type is invalid or empty")
                createErrorResponse(APIReturnCode.INVALID_PARAMS)
                return
            }
            if(StringUtils.isEmpty(payload?.bonusCode)){
                log.info("isBonusCodeValid:: bonus code is invalid or empty")
                createErrorResponse(APIReturnCode.INVALID_PARAMS)
                return
            }
            String eventType = payload?.eventType
            List<PlayerEligibleBonusDTO> playerEligibleBonusDTOLst
            if(eventType.equalsIgnoreCase("Registration")){
                Site site = siteService.getSite(payload?.accountSystemTag)
                if (null == site) {
                    log.info("isBonusCodeValid:: site code is invalid or empty " + payload?.accountSystemTag)
                    createErrorResponse(APIReturnCode.INVALID_SITE_ID)
                    return
                }
                Country country = Country.findByIso3(payload?.countryCode)
                if(null == country){
                    log.info("isBonusCodeValid:: country is invalid " + payload?.countryCode)
                    createErrorResponse(APIReturnCode.INVALID_PARAMS)
                    return
                }
                playerEligibleBonusDTOLst = playerBonusService.getPlayerEligibleRegistrationBonus(site, null, true, payload?.bonusCode, null, country)
            } else {
                Session session = getEvolvePlayerSession()
                if (session == null || !session.isActive()) {
                    createErrorResponse(APIReturnCode.INVALID_SESSION)
                    return
                }
                if(session?.player?.isBonusAbuser || session?.player?.isBonusOptOut() ){
                    log.info("isBonusCodeValid::Player:: bonus abuser" + session?.player?.id)
                    respond new ArrayList<PlayerEligibleBonusDTO>();
                    return
                }
                if(eventType.equalsIgnoreCase("AccountValidation")){
                    playerEligibleBonusDTOLst = playerBonusService.getPlayerEligibleValidationBonus(session.player, true, payload?.bonusCode, null, AccountValidationType.SMS.id)
                } else if(eventType.equalsIgnoreCase("Deposit")){
                    if(StringUtils.isEmpty(payload?.paymentMethod)){
                        log.info("isBonusCodeValid:: paymentMethod is invalid ")
                        createErrorResponse(APIReturnCode.INVALID_PARAMS)
                        return
                    }
                    playerEligibleBonusDTOLst = playerBonusService.getPlayerEligibleDepositBonus(session.player, null, null, true, payload?.bonusCode, payload?.paymentMethod)
                }
            }
            boolean isValidBonusCode = false
            if(null != playerEligibleBonusDTOLst && playerEligibleBonusDTOLst.size() > 0){
                isValidBonusCode = true
            }
            render(status: 200, contentType: 'application/json') {
                [
                        "isBonusCodeValid" : isValidBonusCode
                ]
            }
            return
        } catch(Exception _exp){
            log.error("Exception occured in isBonusCodeValid and the exception is " + _exp.getMessage());
            createErrorResponse(APIReturnCode.ERROR)
            return
        }

    }

}
