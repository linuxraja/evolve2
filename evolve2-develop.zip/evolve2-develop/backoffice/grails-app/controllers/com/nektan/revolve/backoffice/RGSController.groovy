package com.nektan.revolve.backoffice

import com.nektan.revolve.coreservices.RGS
import grails.plugin.springsecurity.annotation.Secured

@Secured(['ROLE_SUPERUSER'])
class RGSController {

    def scaffold = RGS
}
