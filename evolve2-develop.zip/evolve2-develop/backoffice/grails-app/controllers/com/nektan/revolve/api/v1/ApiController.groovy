package com.nektan.revolve.api.v1

import com.nektan.revolve.api.APIReturnCode
import com.nektan.revolve.api.ErrorDTO
import com.nektan.revolve.api.ErrorPropertyDTO
import com.nektan.revolve.api.EvolveConstants
import com.nektan.revolve.api.MultipleErrorsDTO
import com.nektan.revolve.api.ReturnCodes
import com.nektan.revolve.coreservices.Session
import org.apache.commons.lang.StringUtils
import org.codehaus.groovy.runtime.InvokerHelper

import javax.servlet.http.Cookie
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse
import javax.servlet.http.HttpSession

class ApiController implements GroovyInterceptable {



       //Logging aspect

    private def renderResult(ReturnCodes.Code code, HashMap objectMap) {


        render(sstatus: code.httpCode(), contentType: 'application/json')  {
            String s = '{result: '

            objectMap.each { item ->


            }
        }
    }

    private def renderError(ReturnCodes.Code code, String reason) {
        //log.error("renderError(): API ERROR:" + code.toString() + ", reason:" + reason)
        render(status: code.httpCode(), contentType: 'application/json') {
            def result = [:]
            result.put('result', code.value())
            if (code != ReturnCodes.Code.OK) {
                result.put('error', code.description())
            }
            if (reason != null && reason != "null") {result.put('reason', reason)}
            return result
        }
    }


    private def renderError(ReturnCodes.Code code) {
        renderError(code, null)
    }

    // returns null if no errors, string with error message if found a missing one.
    private static String checkParams(requestJSON, String[] expectedParams) {
        String response = null;
        expectedParams.each { String param ->
            if (requestJSON[param] == null) {
                if (response == null) {
                    response = "Missing parameters:" + param
                } else {
                    response += "," + param
                }
            }
        }
        return response
    }

    /**
     * "NA" if no ip
     * @param request
     * @return
     */
    private static String getIp (HttpServletRequest request) {
        return   com.nektan.revolve.extras.Utils.getIP(request)
    } // getIp


    // --------------------
    // used by Evolve1 API
    // --------------------



    /**
     * Check if all cookies are set and set if not.
     * @param response
     * @param token
     */
    void setEvolveCookies(HttpServletRequest request,HttpServletResponse response, Session session) {

        /*Cookie sessionCookie = new Cookie( EvolveConstants.cookieSessionCorrelation, session.token)
        sessionCookie.setPath("/")
        sessionCookie.setMaxAge(-1)
        response.addCookie(sessionCookie)*/
//        Cookie[] cookies = request.getCookies();
//        for(Cookie cookie : cookies) {
//            if(cookie.name.equalsIgnoreCase(EvolveConstants.cookieSessionCorrelation)) {
//                cookie.setValue(null);
//                cookie.setMaxAge(0);
//                response.addCookie(cookie);
//            }
//        }
        Cookie domainSessionCookie = new Cookie( EvolveConstants.cookieSessionCorrelation, session.token)
        domainSessionCookie.setPath("/")
        if(session != null && session.site != null && StringUtils.isNotEmpty(session.site.cookieDomain)){
            domainSessionCookie.setDomain(session.site.cookieDomain);
        }
        domainSessionCookie.setMaxAge(-1)
        response.addCookie(domainSessionCookie)



        Cookie userCorrelationCookie = new Cookie( EvolveConstants.cookieUserCorrelation, session.player.userCorrelationId)
        userCorrelationCookie.setPath("/")
        userCorrelationCookie.setMaxAge(2147483647)
        response.addCookie(userCorrelationCookie)
    }

    
    Session initialiseEvolveSession() {
        String token = g.cookie(name: EvolveConstants.cookieSessionCorrelation)
        Session session = sessionService.getSession(token)

        def lastAccessed = request.getSession(true).getLastAccessedTime(); // read active the session to get update
		if(session == null){
			render( status: 401, contentType: 'application/json' ) {
				createErrorJSONResponse('ValidationError', g.message(code: 'evovle1.lobby.sessioninvalid') )
			}
		}else if (!session.isActive() ) {
            log.debug("no active session!")
            Cookie sessionCookie = new Cookie( EvolveConstants.cookieSessionCorrelation, "")
            sessionCookie.setPath("/")
            sessionCookie.setMaxAge(-1)
            response.addCookie(sessionCookie)

            render( status: 401, contentType: 'application/json' ) {
                createErrorJSONResponse('ValidationError', g.message(code: 'evovle1.lobby.sessioninvalid') )
            }
        }
        return session
    }

    Session getEvolveSession() {
        String token = g.cookie(name: EvolveConstants.cookieSessionCorrelation)
        Session session = sessionService.getSession(token)
        return session
    }


    /**
     * Create a error response JSON for the lobby
     * @param type The type of the error
     * @param message The message to send
     * @return
     */
    def createErrorJSONResponse(String type, String message ) {
        def jsonResponse = [
                "error":
                        [
                                "type": "$type",
                                "message": "$message"
                        ]
        ]
        return jsonResponse
    }

    /**
     * method to get the player active session
     * @return
     */
    Session getEvolvePlayerSession() {
        String token = g.cookie(name: EvolveConstants.cookieSessionCorrelation)
        Session session = sessionService.getSession(token)
        if (session!=null && !session.isActive() ) {
            log.debug("no active session!")
            Cookie sessionCookie = new Cookie( EvolveConstants.cookieSessionCorrelation, "")
            sessionCookie.setPath("/")
            sessionCookie.setMaxAge(-1)
            response.addCookie(sessionCookie)
        }
        return session
    }

    /**
     * Method to render the api error response
     * @param returnCode
     * @return
     */
    def createErrorResponse(APIReturnCode returnCode ) {
        createDynamicErrorResponse(returnCode,null,null)
        return
    }

    /**
     * Method to render the api error response with dynamic message
     * @param returnCode
     * @param message
     * @param paramValues
     * @return
     */
    def createDynamicErrorResponse(APIReturnCode returnCode,String message,String[] paramValues) {
        //Preparing the error dto object
        ErrorDTO errorDTO = new ErrorDTO(returnCode.code(),returnCode.httpCode(),returnCode.type(),message !=null ? message : returnCode.message())
        if(paramValues!=null){
            errorDTO.setParamValues(paramValues)
        }
        //Rendering error json response
        render(status:errorDTO.httpCode,contentType:'application/json') {
            ["error": errorDTO]
        }
        return
    }

    /**
     * Method to render the api multiple error response
     * @param returnCode
     * @param message
     * @param errorMap
     * @return
     */
    def createMultipleErrorResponse(APIReturnCode returnCode,String message,Map<Integer,String> errorMap ) {
        //Preparing the multiple error dto object
        MultipleErrorsDTO errorDTO = new MultipleErrorsDTO(returnCode.code(),returnCode.httpCode(),returnCode.type(),message !=null ? message : returnCode.message())
        List<ErrorPropertyDTO> errorDTOList = new ArrayList<ErrorPropertyDTO>()
        if(errorMap!=null) {
            errorMap.each { it ->
                APIReturnCode code = APIReturnCode.getApiReturnCode(String.valueOf(it.getKey()))
                if (code != null) {
                    errorDTOList.add(new ErrorPropertyDTO(code.code(), it.getValue(), code.message()))
                }
            }
        }
        errorDTO.setErrorProperties(errorDTOList)
        //Rendering error json response
        render(status:errorDTO.httpCode,contentType:'application/json') {
            ["error": errorDTO]
        }
        return
    }

} // ApiController
