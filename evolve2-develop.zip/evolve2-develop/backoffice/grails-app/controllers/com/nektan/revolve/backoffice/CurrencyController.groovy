package com.nektan.revolve.backoffice

import com.nektan.revolve.coreservices.Currency
import grails.plugin.springsecurity.annotation.Secured

@Secured(['ROLE_PERMISSION_SYSTEM_EDIT'])
class CurrencyController {

    def scaffold = Currency

    def beforeInterceptor = {
        response.characterEncoding = 'UTF-8' //workaround for https://jira.grails.org/browse/GRAILS-11830
    }
}
