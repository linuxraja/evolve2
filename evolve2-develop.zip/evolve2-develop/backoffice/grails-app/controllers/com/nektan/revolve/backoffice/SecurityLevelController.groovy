package com.nektan.revolve.backoffice

import com.nektan.revolve.coreservices.SecurityLevel
import grails.plugin.springsecurity.annotation.Secured

@Secured(['ROLE_PERMISSION_CONFIG_EDIT','ROLE_PERMISSION_SYSTEM_EDIT'])
class SecurityLevelController {

    def scaffold = SecurityLevel

	def show()  {
		redirect(action: "index")
	}

}
