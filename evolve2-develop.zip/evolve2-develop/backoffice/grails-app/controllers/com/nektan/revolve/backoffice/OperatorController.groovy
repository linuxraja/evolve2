package com.nektan.revolve.backoffice

import com.nektan.revolve.coreservices.EventLog
import grails.plugin.springsecurity.annotation.Secured
import grails.transaction.Transactional

import com.nektan.revolve.coreservices.Operator
import com.nektan.revolve.coreservices.OperatorRole
import com.nektan.revolve.coreservices.Permission
import com.nektan.revolve.coreservices.Role
import com.nektan.revolve.coreservices.RolePermissionMap
import com.nektan.revolve.coreservices.Site
import com.nektan.revolve.services.EventLogService
import com.nektan.revolve.services.SiteService
import com.nektan.revolve.coreservices.Currency

@Secured(['ROLE_PERMISSION_OPERATOR_VIEW'])
class OperatorController extends BackofficeController {

    def springSecurityService
    SiteService siteService
    EventLogService eventLogService

	def currencyService
    def scaffold = Operator
    def operatorService

    String ILLEGAL_ACCESS = "Illegal access. This event has been reported"

    def index() {
        redirect(action: 'list')
    }


    def beforeInterceptor = [action: this.&checkAuthorised, only: ['show','edit','update','save']]

    /***
     * assume that prams.id is not null
     * @return false if not allowed.
     */
    private checkAuthorised() {

        Operator currentLoggedInUser = springSecurityService.getCurrentUser();

        Operator operator

        if (params.id) {
            operator = operatorService.findById(params.id)
        }
        List sites = operatorService.operatingSites(currentLoggedInUser)

        boolean found

        if (operator != null) {

            found = sites.find { Site site -> site.id == operator.operates.id }

            if (!found) {

                eventLogService.logEvent([className  : this.getClass().getName(),
                                          methodName : "checkAuthorized",
                                          IP         : getIp(request),
                                          eventName  : EventLog.EventName.operatorIllegalAccessAttempt,
                                          description: "Unathorsized attempt to view or edit operator with id: " + params.id,
                                          level      : EventLog.LEVELS.alert,
                                          operator   : currentLoggedInUser,
                                          level      : EventLog.LEVELS.warning,
                                          subjectId  : params.id,
                                          param1     : "${actionUri}"
                ])

                flash.message = ILLEGAL_ACCESS
                redirect(action: 'list')
                return false
            }
        }

        def willOperateId = params?.operates?.id
        if (willOperateId != null) {

            Site willOperateSite = Site.get(willOperateId)
            if (willOperateSite != null) {

                found = sites.find{ Site site -> site.id ==  willOperateSite.id }

                if (!found) {
                    eventLogService.logEvent([className: this.getClass().getName(),
                                              methodName: "checkAuthorized",
                                              IP: getIp(request),
                                              eventName:EventLog.EventName.operatorIllegalAccessAttempt,
                                              description: "Attempt to update an operator with an unauthorized site: operator " + params.id + " site Id:" + willOperateId,
                                              level: EventLog.LEVELS.alert,
                                              operator: currentLoggedInUser,
                                              level:EventLog.LEVELS.warning,
                                              objectId:willOperateId,
                                              param1:"${actionUri}"
                    ])

                    flash.message = ILLEGAL_ACCESS
                    redirect(action: 'list')
                    return false
                }
            }
        } // if found an edited site.
    } // checkAuthorized()

    /**
     * only list operators in your site or sub sites.
     * @return
     */
    def list() {
        Operator currentLoggedInUser = springSecurityService.getCurrentUser();

        def operators = operatorService.listViewable(currentLoggedInUser)

        render(view: "list", model: [operatorInstanceList: operators])
    }

    /**
     * only show an operator in your site(s)
     * @return
     */
    def show() {

        Operator operator = operatorService.findById( params.id )
        render(view:"show", model: [operatorInstance: operator])
    }

    /**
     * edit an operator that you are allowed to manage.
     *
     * @return
     */
    def edit() {
        Operator currentLoggedInUser = springSecurityService.getCurrentUser();
        def sites = siteService.getChildren(currentLoggedInUser.operates)
        //def sites = Site.findAll()

        Operator operator = operatorService.findById( params.id )
		List<com.nektan.revolve.coreservices.Currency> currencies=currencyService.listAll()			
        render(view:"edit", model: [operatorInstance: operator, sites: sites,currencies:currencies])
    }

    /***
     * create an operator
     * TODO: check the operator being edited is in the operates sites.
     * TODO: check the site of the edited operator is in the list of sites.
     * @return
     */
    @Secured(['ROLE_PERMISSION_OPERATOR_EDIT'])
    def create() {
        Operator currentLoggedInUser = springSecurityService.getCurrentUser();		
        def sites = siteService.getChildren(currentLoggedInUser.operates)
		List<com.nektan.revolve.coreservices.Currency> currencies=currencyService.listAll()		
        render(view:"create", model: [operatorInstance: null, sites: sites,currencies:currencies])
    }


	@Secured(['IS_AUTHENTICATED_FULLY'])
	def profile() {
		Operator currentLoggedInUser = springSecurityService.getCurrentUser();
		render(view:"profile", model: [operatorInstance: currentLoggedInUser])
	}

    def makeAdmin() {
        render ("Not implemented yet")
    }

    /***
     * Save a new operator?
     *
     * TODO: check the site of the edited operator is in the list of sites.
     * @return
     */
    @Secured(['ROLE_PERMISSION_OPERATOR_EDIT'])
    def save() {
		List<com.nektan.revolve.coreservices.Currency> currencies=currencyService.listAll()
        // the UI shows enabled as "suspended", i.e. opposite sense.
        if (params.enabled == null) {
            params.enabled = true
        } else {
            params.enabled = false
        }
       
        Operator operator = operatorService.create( params )
        if ( operator.hasErrors() ) {
            Operator currentLoggedInUser = springSecurityService.getCurrentUser();
            def sites = siteService.getChildren(currentLoggedInUser.operates)
            render(view:'create', model:[operatorInstance: operator, sites: sites,currencies:currencies])
        } else {
            flash.message="Operator ${operator.username} created."
            render(view:'show', model:[operatorInstance: operator])
        }
    }

    /***
     * save an updated version of an operator.
     * TODO: check the site of the edited operator is in the list of sites.
     *
     * @return
     */
    @Secured(['ROLE_PERMISSION_OPERATOR_EDIT'])
    @Transactional
    def update() {
		List<com.nektan.revolve.coreservices.Currency> currencies=currencyService.listAll()
        Operator currentLoggedInUser = springSecurityService.getCurrentUser();

        Operator operator = operatorService.findById( params.id )

        // the UI shows enabled as "suspended", i.e. opposite sense.
        if (params.enabled == null) {
            params.enabled = true
        } else {
            params.enabled = false
        }
        operatorService.update(operator, params)

        if ( !operator.hasErrors() ) {
            render(view:'show', model:[operatorInstance: operator])
        } else {
            def sites = siteService.getChildren(currentLoggedInUser.operates)
            render(view:'edit', model:[operatorInstance: operator, sites:sites,currencies:currencies])
        }
    }

//    // TODO: move logic into service
//    @Secured(['ROLE_PERMISSION_OPERATOR_EDIT'])
//    @Transactional
//    def update() {
//
//        Operator currentLoggedInUser = springSecurityService.getCurrentUser();
//
//        Operator operator = operatorService.findById( params.id )
//
//        // the UI shows enabled as "suspended", i.e. opposite sense.
//        if (params.enabled == null) {
//            params.enabled = true
//        } else {
//            params.enabled = false
//        }
//
//        if ( operator.password != params.password) {
//            operator.lastPasswordUpdate = new Date()
//            operator.properties = params
//        } else {
//            operator.properties = params
//        }
//
//        // this should not be allowed by the UI!
//        if (currentLoggedInUser.id == operator.id && params.enabled == false) {
//            operator.errors.rejectValue("enabled", "Cannot suspend yourself")
//            def sites = siteService.getChildren(currentLoggedInUser.operates)
//            render(view:'edit', model:[operatorInstance: operator,sites:sites])
//            operator.discard()
//            return
//        }
//
//
//        if ( operator.save(flush: true) ) {
//            render(view:'show', model:[operatorInstance: operator])
//        } else {
//            def sites = siteService.getChildren(currentLoggedInUser.operates)
//            render(view:'edit', model:[operatorInstance: operator, sites:sites])
//        }
//    }


    @Secured(['ROLE_PERMISSION_OPERATOR_ROLE'])
    def listRoles() {
        render(view:"listRoles", model:[ roleInstanceList: operatorService.allRoles ])
    }

    @Secured(['ROLE_PERMISSION_OPERATOR_ROLE'])
    def createNewRole() {
        render(view:"createRole")
    }

    // TODO: move logic into service
    @Secured(['ROLE_PERMISSION_OPERATOR_ROLE'])
    @Transactional
    def saveRole() {
        Role role = operatorService.createRole(params)
        if ( role.hasErrors() ) {
            render(view:"createRole", model:[roleInstance: role])
        } else {
            flash.message="Role ${role.authority} created."
            redirect(action: "listRoles")
        }
    }

    @Secured(['ROLE_PERMISSION_OPERATOR_ROLE'])
    def permissions() {
        Role role = operatorService.getRole( params.id )
        def permissions = operatorService.allPermissions
        render(view:"permissions", model: [roleInstance: role, permissions: permissions])
    }


    // TODO: move logic into service
    @Secured(['ROLE_PERMISSION_OPERATOR_ROLE'])
    @Transactional
    def updatePermissions() {

        Role role = operatorService.getRole( params.id )

        if ( params.permissions == null ) {
            def permissions = operatorService.allPermissions
            flash.message = "A role must have at least one permission."
            render (view: 'permissions',model: [roleInstance: role, permissions: permissions])
            return
        }

        RolePermissionMap.executeUpdate("delete RolePermissionMap where role_permissions_id = :id", [id: role.id])

	    role.permissions = null
	    params.list("permissions").each { value ->
		    role.addToPermissions( Permission.get( Long.parseLong( value )) )
	    }
	    role.save(flush: true, failOnError: true)

        flash.message = "Role ${role.authority} was updated."
        render(view:"listRoles", model:[ roleInstanceList: operatorService.allRoles ])
    }

    /***
     * called when you want to edit the roles assigned to an operator.  It does do any assigning,
     * it should perhaps be called view roles for operator.
     *
     * @return
     */
    @Secured(['ROLE_PERMISSION_OPERATOR_ROLE'])
    def assignRoles() {

        def operator = operatorService.findById(params.id)
        def roles = operatorService.allRoles

        render (view: 'roles',model: [operatorInstance: operator, roles: roles])
    }



    // TODO: move logic into service.
    /***
     * SH: This has been modified so that you cant assign a role which you dont have, unless you are super
     * @return
     */
    @Secured(['ROLE_PERMISSION_OPERATOR_ROLE'])
    @Transactional
    def updateRoles() {

        Operator operator = operatorService.findById(params.id)

        if (params.roles == null ) {
            flash.message = "A operator must have at least one role."
            render(view: 'show', model: [operatorInstance: operator])
            return
        }

        def newRoles = params.list('roles') // make sure its a list, even if only one item selected.


        Operator currentLoggedInUser = springSecurityService.getCurrentUser();
        def currentLoggedInUserRoles = currentLoggedInUser.getRolesAndPermissions().roles

        boolean permissionError = false


// SWH:  temporarily commented out so it can be finished later
//        newRoles.each { String roleId ->
//            Role role = Role.get(Long.parseLong(roleId))
//            if (!currentLoggedInUserRoles.contains(role)) {
//                flash.message = "Sorry, you dont have permission to add role $role.authority as you do not have this role"
//                permissionError = true
//                return // out of this closure
//            }
//        }
// DO NOT DELETE


        if (permissionError) {
            render(view: 'show', model: [operatorInstance: operator])
            return
        }


        params.remove("_roles")
        OperatorRole.executeUpdate("delete OperatorRole where operator_id = :id and role_id not in (:roleIds)", [id: operator.id, roleIds: newRoles])

        newRoles.each { roleId ->
            Role newRole =  Role.get(Long.parseLong( roleId))
            if(OperatorRole.countByOperatorAndRole(operator,newRole) == 0) {
               OperatorRole.create(operator, newRole, true)
            }
        }

        if (operator.hasErrors()) {
            render (view: 'show',model: [operatorInstance: operator])
            return
        } else {
            flash.message = "Roles updated"
            redirect(action:'list')
        }

    }

	def passwordExpired() {
		render( view: "changePassword", model: [operator: session['SPRING_SECURITY_LAST_USERNAME']])
	}

    @Secured(['IS_AUTHENTICATED_FULLY'])
    def changeMyPassword() {
        render( view: "changeMyPassword", model: [operator: springSecurityService.getCurrentUser()])
    }


    @Secured(['IS_AUTHENTICATED_FULLY'])
    def saveMyPassword() {

        Operator currentLoggedInUser = springSecurityService.getCurrentUser();

        if (!currentLoggedInUser) {
            flash.message = 'Sorry, an error has occurred'
            redirect controller: 'login', action: 'auth'
            return
        }

        String password = params.password
        String newPassword = params.password_new
        String newPassword2 = params.password_new_2

        if (!password || !newPassword || !newPassword2) {
            flash.message = "Please enter your current password and a valid new password"
            render (view: 'changeMyPassword', model: [operator: currentLoggedInUser] )
            return
        }

        if ( newPassword != newPassword2) {
            flash.message = "New Password and New Password (repeat) do not match"
            render (view: 'changeMyPassword', model: [operator: currentLoggedInUser] )
            return
        }

        currentLoggedInUser = Operator.get(currentLoggedInUser.id)

        def result = operatorService.updatePassword(currentLoggedInUser, password, newPassword)

        if (result) {
            flash.message = 'Password changed.'
            render (view: 'changeMyPassword', model: [operator: currentLoggedInUser] )
            return
        } else {
            flash.message = 'Could not change password'
            render (view: 'changeMyPassword', model: [operator: currentLoggedInUser] )
            return
        }

        redirect (controller: 'portal', action: 'index')
//        redirect( view: "changeMyPassword", model: [operator: currentLoggedInUser])
    }

    /**
     * This is called when the players password has expired.
     * @return
     */
    def updatePassword() {
        String operatorName = session['SPRING_SECURITY_LAST_USERNAME']

        if (!operatorName) {
            flash.message = 'Sorry, an error has occurred, operator not found'
            redirect controller: 'login', action: 'auth'
            return
        }

        String password = params.password
        String newPassword = params.password_new
        String newPassword2 = params.password_new_2

        if (!password || !newPassword || !newPassword2) {
            flash.message = "Please enter your current password and a valid new password"
            render (view: 'changePassword', model: [operator: session['SPRING_SECURITY_LAST_USERNAME']] )
            return
        }

   		if (password == newPassword) {
			flash.message = 'Please choose a different password from your current one'
			render (view: 'changePassword', model: [operator: session['SPRING_SECURITY_LAST_USERNAME']] )
			return
		}

        if ( newPassword != newPassword2) {
            flash.message = "New Password and New Password (repeat) do not match"
            render (view: 'changePassword', model: [operator: session['SPRING_SECURITY_LAST_USERNAME']] )
            return
        }

        Operator op = Operator.findByUsername(operatorName)

        def result = operatorService.updatePassword(op, password, newPassword)

        if (result) {
            flash.message = 'Password changed. Please login with your new credentials.'
        } else {
            flash.message = 'Could not change password'
            render (view: 'changePassword', model: [operator: op] )
            return
        }

        redirect (controller: 'login', action: 'auth')
    } // updatePassword

    // TODO: move logic into service
//    @Transactional
//	def updatePasswordOld() {
//		String operator = session['SPRING_SECURITY_LAST_USERNAME']
//
//		if (!operator) {
//			flash.message = 'Sorry, an error has occurred'
//			redirect controller: 'login', action: 'auth'
//			return
//		}
//
//		String password = params.password
//		String newPassword = params.password_new
//		String newPassword2 = params.password_new_2
//
//		if (!password || !newPassword || !newPassword2 || newPassword != newPassword2) {
//			flash.message = "Please enter your current password and a valid new password"
//			render (view: 'changePassword', model: [operator: session['SPRING_SECURITY_LAST_USERNAME']] )
//			return
//		}
//
//		Operator op = Operator.findByUsername(operator)
//		if (!springSecurityService.passwordEncoder.isPasswordValid(op.password, password, null )) {
//			flash.message = 'Current password is incorrect'
//			render (view: 'changePassword', model: [operator: session['SPRING_SECURITY_LAST_USERNAME']] )
//			return
//		}
//
//		if (springSecurityService.passwordEncoder.isPasswordValid(op.password, newPassword, null )) {
//			flash.message = 'Please choose a different password from your current one'
//			render (view: 'changePassword', model: [operator: session['SPRING_SECURITY_LAST_USERNAME']] )
//			return
//		}
//
// //       println "new password: $newPassword"
// //       println "$op"
//
//		op.password = newPassword
//		op.passwordExpired = false
//        op.lastPasswordUpdate = new Date()
//		if (op.save()) {
//            flash.message = 'Password changed. Please login with your new credentials.'
//        } else {
//
//            flash.message = 'Could not change password'
//            render (view: 'changePassword', model: [operator: op] )
//            return
//        }
//
//		redirect (controller: 'login', action: 'auth')
//	} // updatePassword Old

}
