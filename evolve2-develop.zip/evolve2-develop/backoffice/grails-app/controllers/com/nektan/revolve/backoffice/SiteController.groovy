package com.nektan.revolve.backoffice

import com.nektan.revolve.api.ReturnCodes
import com.nektan.revolve.api.geofence.Point
import com.nektan.revolve.api.geofence.Polygon
import com.nektan.revolve.coreservices.Country
import com.nektan.revolve.coreservices.Currency
import com.nektan.revolve.coreservices.KycPassScore
import com.nektan.revolve.coreservices.QuickAmount
import com.nektan.revolve.coreservices.Site
import com.nektan.revolve.services.SiteService
import grails.plugin.springsecurity.annotation.Secured
import grails.transaction.Transactional
import org.apache.commons.lang.StringUtils
import org.springframework.orm.hibernate4.HibernateOptimisticLockingFailureException

@Secured(['ROLE_PERMISSION_SYSTEM_EDIT'])
class SiteController {

    def scaffold = Site
    def operatorService
    def siteService
    def springSecurityService

    def beforeInterceptor = {
        response.characterEncoding = 'UTF-8' //workaround for https://jira.grails.org/browse/GRAILS-11830
    }


    def search(params) {
        List<Site> siteList = siteService.search(params)
        if (siteList == null || siteList.isEmpty()) {
            render(view: 'index', model: [params: params,siteInstanceCount:0])
        } else {
            render(view: 'index', model: [params: params, siteInstanceList: siteList, siteInstanceCount: siteList.size(), siteCount: siteList.getTotalCount()])
        }
    }

    def save(Site site) {
        /*if (site.validateWithdrawConditions == true && site.kycPassScore.size() == 0) {
            flash.message = "Select Kyc Pass Score."
            render(view: "create", model: [siteInstance: site])
            return
        }*/
        site.validate()
        if (!site.hasErrors()) {
            site.save(flush: true, failOnError: true)
            Site parent = site.parent
            if (parent) {
                parent.addToSubSites(site)
                parent.save(flush: true, failOnError: true)
            }
            Currency currency = siteService.getInheritedValue(site, "currency")
            Country country = siteService.getInheritedValue(site, "country")

            if (currency == null) {
                site.currency = Currency.findByIso("USD")
                flash.message = "Site ${site.shortName} created. - ATTN: No currency given in site or parents, default currency set to ${site.currency.iso}!"
            } else {
                flash.message = "Site ${site.shortName} created."
            }
            redirect(action: "search")
        }
        List<QuickAmount> quickAmountList = Arrays.asList(new  QuickAmount(),new  QuickAmount(),new  QuickAmount(),new  QuickAmount(),new  QuickAmount())
        render(view: "create", model: [siteInstance: site, quickAmountList: (site.quickAmount != null && site.quickAmount.size() > 0) ? site.quickAmount : quickAmountList])
    }

    def create() {
        Site site = new Site()
        List<QuickAmount> quickAmountList = Arrays.asList(new  QuickAmount(),new  QuickAmount(),new  QuickAmount(),new  QuickAmount(),new  QuickAmount())
        render(view: "create", model: [quickAmountList: quickAmountList, siteInstance: site])
    }


    def edit() {
        Site site = Site.get(params.id)
        List<QuickAmount> quickAmountList = Arrays.asList(new  QuickAmount(),new  QuickAmount(),new  QuickAmount(),new  QuickAmount(),new  QuickAmount())
        render(view: "edit", model: [siteInstance: site, currentParent: site.parent, quickAmountList: (site.quickAmount != null && site.quickAmount.size() > 0) ? site.quickAmount : quickAmountList])
    }


    def update() {
        List<QuickAmount> quickAmountList = Arrays.asList(new  QuickAmount(),new  QuickAmount(),new  QuickAmount(),new  QuickAmount(),new  QuickAmount())
        try{
            def response = siteService.update(params)
            if(response?.site?.hasErrors() || null != response.errorMsg){
                if(null != response.errorMsg){
                    flash.message = response.errorMsg
                }
                render(view: "edit", model: [siteInstance: response?.site, currentParent: response?.site?.parent, quickAmountList: (null != response.quickAmountList && response.quickAmountList.size() > 0) ? response.quickAmountList : quickAmountList])
                return
            }
            redirect(action: "show", id: response.site.id)
        } catch(Exception _exp){
            flash.message = _exp.getMessage()
            Site site = Site.findById(params.long("id"))
            render(view: "edit", model: [siteInstance: site, currentParent: site.parent, quickAmountList: (null != site.quickAmount && site.quickAmount.size() > 0) ? site.quickAmount : quickAmountList])
            return
        }

    }


    def geoFence() {
        Site site = Site.get(params.id)
        render(view: "geofence", model: [siteInstance: site])
    }


    def newFence() {
        Site site = Site.get(params.id)
        render(view: "edit", model: [siteInstance: site, newFenceInstance: params.geoFence, currentParent: site.parent])
    }
}
