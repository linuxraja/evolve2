package com.nektan.revolve.api.evolve1

import com.nektan.revolve.api.APIReturnCode
import com.nektan.revolve.api.EvolveConstants
import com.nektan.revolve.api.v1.ApiController
import com.nektan.revolve.coreservices.Player
import com.nektan.revolve.coreservices.PlayerMessagesConfig
import com.nektan.revolve.coreservices.Session
import com.nektan.revolve.dto.PlayerMessagesAcknowledgmentResponse
import com.nektan.revolve.dto.PlayerMessagesResponse
import com.nektan.revolve.services.ExternalPusherService
import com.nektan.revolve.services.PlayerService
import com.nektan.revolve.services.SessionService
import com.nektan.revolve.services.SiteService
import grails.plugin.springsecurity.annotation.Secured
import org.apache.commons.lang.StringUtils

import java.util.regex.Pattern

@Secured(['permitAll'])
class PusherAuthenticationController extends ApiController implements EvolveConstants {

    public static namespace = 'evolve1'

    static allowedMethods = [
            authenticatePlayer: 'POST',
            playerMessages: 'POST',
            playerMessagesAcknowledgment:'POST'
    ]

    static responseFormats = ['json']
    SessionService sessionService
    PlayerService playerService
    SiteService siteService
    ExternalPusherService externalPusherService

    def authenticatePlayer() {
        try {
            log.info("authenticatePlayer.. params:: " + params)
            String auth = null;
            String authToken = request?.getHeader("Auth-Token");
            log.info("authenticatePlayer..Auth Token::" + authToken);
            if(StringUtils.isNotEmpty(authToken)){
                //authToken In Base-64 encoded form we need to decrypt it
                String decryptedAuthToken = new String(authToken.decodeBase64())
                log.info("authenticatePlayer..Decrypted Auth Token::" + decryptedAuthToken);
                String[] splittedAuthToken = decryptedAuthToken.split(Pattern.quote("||"));
                String sessionCorrelationId = splittedAuthToken[0];
                String userCorrelationId = splittedAuthToken[1];
                Session session = sessionService.getSession(sessionCorrelationId);
                String internalChannelName = "private-" + session?.player?.userCorrelationId;
                log.info("authenticatePlayer..sessionCorrelationId::" + sessionCorrelationId +", userCorrelationId :: "+ userCorrelationId + ",internalChannelName::"+internalChannelName+", sessionId::"+session?.token);
                String channelName = params.channel_name
                String socketId = params.socket_id;
                if (session?.isActive() &&
                        StringUtils.equals(session?.player?.userCorrelationId, userCorrelationId) &&
                        StringUtils.equals(channelName, internalChannelName)) {
                    auth = externalPusherService.genAuthString(socketId, channelName);
                    log.info("authenticatePlayer..Auth::" + auth);
                    render(status: 200, contentType: 'application/json') {
                        ["auth": auth]
                    }
                    return;
                } else {
                    log.info("authenticatePlayer..Session is Inactive");
                }
            } else{
                log.info("authenticatePlayer..Auth-Token is Empty ");
            }
            render(status: 403, contentType: 'application/json', text: "Forbidden");
            return;
        }catch(Exception exp){
            log.error("Exception occured while authenticating pusher ");
            render(status: 403, contentType: 'application/json', text: "Forbidden");
            return;
        }
    }

    /**
     *
     * @return
     */
    def playerMessages() {
        try {
            log.info("playerMessages.. params:: " + params)
            PlayerMessagesResponse playerMessagesResponse = null;
            String authToken = request?.getHeader("Auth-Token");
            log.info("playerMessages..Auth Token::" + authToken);
            if(StringUtils.isNotEmpty(authToken)){
                //authToken In Base-64 encoded form we need to decrypt it
                String decryptedAuthToken = new String(authToken.decodeBase64())
                log.info("playerMessages..Decrypted Auth Token::" + decryptedAuthToken);
                String[] splittedAuthToken = decryptedAuthToken.split(Pattern.quote("||"));
                String sessionCorrelationId = splittedAuthToken[0];
                String userCorrelationId = splittedAuthToken[1];
                Session session = sessionService.getSession(sessionCorrelationId);
                String internalChannelName = "private-" + session?.player?.userCorrelationId;
                log.info("playerMessages..sessionCorrelationId::" + sessionCorrelationId +", userCorrelationId :: "+ userCorrelationId + ",internalChannelName::"+internalChannelName+", sessionId::"+session?.token);
                String channelName = params.channel_name
                String socketId = params.socket_id;
                if (session?.isActive() &&
                        StringUtils.equals(session?.player?.userCorrelationId, userCorrelationId) &&
                        StringUtils.equals(channelName, internalChannelName)) {
                    playerMessagesResponse = externalPusherService.getPlayerMessages(socketId, channelName,session);
                    log.info("playerMessagesResponse..:" + playerMessagesResponse);
                    render(status: 200, contentType: 'application/json') {
                        [playerMessagesResponse]
                    }
                    return;
                } else {
                    log.info("playerMessages..Session is Inactive or mismatch in channel name or wrong correlation id");
                }
            } else{
                log.info("playerMessages..Auth-Token is Empty ");
            }
            render(status: 403, contentType: 'application/json', text: "Forbidden");
            return;
        }catch(Exception exp){
            log.error("Exception occured while playerMessages pusher "+exp.getMessage());
            render(status: 403, contentType: 'application/json', text: "Forbidden");
            return;
        }
    }

    /**
     *
     * @return
     */
    def playerMessagesAcknowledgment() {
        try {
            def payload = request.JSON
            log.info("playerMessagesAcknowledgment.. payload:: " + payload)
            Session session = getEvolvePlayerSession()
            if (session == null || !session.isActive()) {
                createErrorResponse(APIReturnCode.INVALID_SESSION)
                return
            }
            Player player = Player.findByUserCorrelationId(payload?.userCorrelationId)
            if (player == null) {
                createErrorResponse(APIReturnCode.INVALID_PLAYER)
                return
            }
            PlayerMessagesConfig playerMessagesConfig = PlayerMessagesConfig.findByName(payload?.name)
            if (playerMessagesConfig == null) {
                createErrorResponse(APIReturnCode.INVALID_PARAMS)
                return
            }
            PlayerMessagesAcknowledgmentResponse response = externalPusherService.processPlayerMessagesAcknowledgment(playerMessagesConfig,player)
            log.info("playerMessagesAcknowledgment response..:" + response);
            if(response!=null) {
                render(status: 200, contentType: 'application/json') {
                    [response]
                }
                return;
            }else{
                render(status: 500, contentType: 'application/json') {
                    [response]
                }
                return;
            }
        }catch(Exception exp){
            log.error("playerMessagesAcknowledgment exception occured while playerMessagesAcknowledgment "+exp.getMessage());
            render(status: 403, contentType: 'application/json', text: "Forbidden");
            return;
        }
    }
}

