package com.nektan.revolve.backoffice

import com.nektan.revolve.coreservices.Operator
import com.nektan.revolve.coreservices.Player
import com.nektan.revolve.services.EventLogService
import grails.plugin.springsecurity.SpringSecurityUtils
import grails.plugin.springsecurity.annotation.Secured


@Secured(['ROLE_PERMISSION_PLAYER_DETAILS_CHANGE','ROLE_PERMISSION_PLAYER_DEPOSIT_LIMIT_CHANGE'])
class PlayerHistoryController {

    def notesService
    def playerService
    def operatorService
    def springSecurityService

    EventLogService eventLogService
    String ILLEGAL_ACCESS = "Illegal access. Unauthorized attempt to view or edit player"

    /**
     * Render the player history for a given player.
     * @return View to a widget
     */
    def index() {
        Player player = playerService.findById( params.id )
        redirect(action: "search", params: params, playerInstance: player)
    }

    /**
     * It will render the page for search the players
     * @return
     */
    def search() {
        Player player = playerService.findById( params.id )
        render(view: "tab_playerHistory", model:[playerInstance: player, params: params])
    }

    /**
     * Executes a search for player history of a particualr Player
     * @return
     */
    def searchHistory() {
        Date createdAtStart, createdAtEnd
        Player player = playerService.findById( params.id )

        if ( params.createdAtStart?.length() == 0 || params.createdAtEnd?.length() == 0 ) {
            flash.message = "Please specify date range!"
            render(view: "tab_playerHistory", model:[playerInstance: player])
            return
        }

        if (params.createdAtStart != null && params.createdAtStart.length() > 0 && params.createdAtEnd != null && params.createdAtEnd.length() > 0) {
            int days = playerService.getBetweenDays(params.createdAtStart, params.createdAtEnd)
            if( days > 30 ){
                flash.message = "Date range should be in 30 Days only"
                render(view: "tab_playerHistory", model:[playerInstance: player])
                return
            }
        }


        params.depositId = player.playerDepositLimitsId
        def data = playerService.findPlayerHistory(params)
        def results = data.results
        def total = data.totalCount[0]



        if (results == null) {
            flash.message = message(code: "revolve.search.error.nousersfound", args: [params.playerId])
            render(view: "tab_playerHistory", model: [params: params])
        } else {
            render(view: "tab_playerHistory", model: [playerInstance: player, params: params, auditLogList: results, auditLogListCount : total])
        }
    }

    /**
     * It will return operator's accessable permissions of type of player history
     * @return
     */
    Map getAccessableHistoryTypes(){

        Operator currentLoggedInUser = springSecurityService.getCurrentUser()
        def permissions = currentLoggedInUser.getRolesAndPermissions().permissions

        Map<String, String> historyTypes = new LinkedHashMap<String, String>();
        StringBuilder allBuilder = new StringBuilder("''");
        permissions.each { permission ->
           if( permission.getAuthority().equals('ROLE_PERMISSION_PLAYER_DETAILS_CHANGE')){
               historyTypes.put("Player Details Changes","Player")
               allBuilder.append(",'Player'");
           }else if( permission.getAuthority().equals('ROLE_PERMISSION_PLAYER_DEPOSIT_LIMIT_CHANGE')){
               historyTypes.put("Deposit Limit Changes","PlayerDepositLimits")
               allBuilder.append(",'PlayerDepositLimits'")
           }
        }
        if( !historyTypes.isEmpty()){
            historyTypes.put("ALL", allBuilder.toString())
        }

        return historyTypes
    }

}
