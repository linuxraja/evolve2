package com.nektan.revolve.api.v1

import com.nektan.revolve.api.Format
import com.nektan.revolve.api.ReturnCodes
import com.nektan.revolve.coreservices.*
import com.nektan.revolve.services.AccountService
import com.nektan.revolve.services.EventLogService
import com.nektan.revolve.services.ParamService
import com.nektan.revolve.services.SessionService
import com.nektan.revolve.services.TransactionService
import com.nektan.revolve.sightline.W2gRecord
import com.nektan.revolve.sightline.W2gRecordService
import grails.plugin.springsecurity.annotation.Secured
import groovy.json.JsonBuilder

@Secured(['permitAll'])
class AccountController extends ApiController{

    static namespace = 'v1'
    AccountService accountService
    TransactionService transactionService
    SessionService sessionService
    ParamService paramService
    EventLogService eventLogService
    W2gRecordService w2gRecordService

    static allowedMethods = [createTransaction: "POST", getBalance: "POST", getTransactions: "POST"]

    /**
     * Get the balance for a given player
     */
    def getBalance() {
        try {
            def payload = request.JSON

            String[] requiredParams = ["token"]
            String paramError = checkParams(payload, requiredParams)
            if (paramError != null) {
                renderError(ReturnCodes.Code.INVALID_PARAMS, paramError)
                return
            }

            Session session = sessionService.getSession(payload.token)

            if (session == null) {
                renderError(ReturnCodes.Code.SESSION_INVALID)
                return
            }

            if (!sessionService.isActiveSession(session)) {
                renderError(ReturnCodes.Code.SESSION_EXPIRED)
                return
            }

            Player player = session.player
            sessionService.refreshSession(session)

            def accountResult = accountService.getBalance(player)

            BigDecimal playableBalance = 0
            BigDecimal w2gTotal = 0

            playableBalance = accountService.getRealBalance(player)
            def w2gCount = w2gRecordService.getOpenRecordCount(player)
            List<W2gRecord> w2gRecords = w2gRecordService.getOpenRecords(player)

            if (w2gCount > 0) {
                w2gRecords.each { W2gRecord w2gRecord ->
                    w2gTotal += w2gRecord.totalWin
                }
            } // if we have w2gRecords to deal with.

            if (accountResult == null) {
                renderError(ReturnCodes.Code.ERROR, "accountService.getBalance returned Null")
                return
            } else if (accountResult.returncode == ReturnCodes.Code.OK) {

                render(status: 200, contentType: 'application/json') {
                    [
                            'result'  : 0,
                            'accounts': accountResult.accounts,
                            'w2gRecords': w2gRecords,
                            'w2gCount' :  w2gCount,
                            'playableBalance' : playableBalance - w2gTotal
                    ]
                }

                return
            } else  {
                renderError(result.returnCode, result.errors)
                return
            }
        } catch (Exception e) {
            renderError(ReturnCodes.Code.ERROR, e.toString())
            log.error("createGameTransaction API Error:" + e.toString(), e)
            return
        }
    } // getBalance()


    /**
     * Retrieve all transactions for the player, optionally within a date range and / or filtered by account
     * @param token
     * @param enddate (optional)
     * @param startdate (optional)
     * @param offset (mandetory)
     * @param max (mandetory)
     * @return
     */
    def retrieveTransactions() {
        try {
            def payload = request.JSON

            String[] requiredParams = ["token", "max", "offset"]
            String paramError = checkParams(payload, requiredParams)
            if (paramError != null) {
                renderError(ReturnCodes.Code.INVALID_PARAMS, paramError)
                return
            }

            Session session = sessionService.getSession(payload.token)

            if (session == null) {
                renderError(ReturnCodes.Code.SESSION_INVALID)
                return
            }

            if (!sessionService.isActiveSession(session)) {
                renderError(ReturnCodes.Code.SESSION_EXPIRED)
                return
            }

            Player player = session.player

            Date startAt, endAt
            if (payload.startdate != null) {
                startAt = Date.parse("yyyy-MM-dd", payload.startdate)
            }

            if (payload.enddate != null) {
                endAt = Date.parse("yyyy-MM-dd", payload.enddate)
            }

            Long accountId
            if (payload.accountid != null) {
                accountId = Long.parseLong(payload.accountid)
            }

            def params = [:]
            params.max = payload.max
            params.offset = payload.offset

            def transResult = accountService.getTransactionsForPlayer(player, startAt, endAt, accountId, params)
            
            if (transResult == null) {
                renderError(ReturnCodes.Code.ERROR, "accountService.getTransactionsForPlayer returned Null")
                return
            }  else if (transResult.returnCode == ReturnCodes.Code.OK) {

                def builder = new JsonBuilder()
                def root = builder {
                    result 0
                    transactions(
                            transResult.transactions.collect() { Transaction t ->
                                def gameMap = [:]
                                def transMap =
                                        [
                                                id            : "${t.id}",
                                                type          : "${t.type?.name}",
                                                account       : "${t.account.id}",
                                                createdAt     : "${t.createdAt.format(Format.dateFormat)}",
                                                debit         : "${g.formatNumber(number:t.debit, formatName:"global.number.format", groupingUsed:"false")}",
                                                credit        : "${g.formatNumber(number:t.credit, formatName:"global.number.format", groupingUsed:"false")}",
                                                balanceAfter  : "${g.formatNumber(number:t.balanceAfter, formatName:"global.number.format", groupingUsed:"false")}",
                                                externalGameId: "${t.externalGameInstanceId}",
                                                description   : "${t.description}"
                                        ]

                                if (t.subType) transMap.put("subtype", t.subType.name)

                                if (t.game != null) {
                                    gameMap.put("name", t.game.name)
                                    gameMap.put("externalId", t.game?.externalId)
                                    gameMap.put("rgs", t.game.rgs?.name)

                                    transMap.put("game", gameMap)
                                }
                                return transMap
                            }
                    )
                }
                render(status: 200, contentType: 'application/json', text: builder.toPrettyString())

            } else {
                renderError(transResult.returnCode, transResult.errors)
                return
            }
        } catch (Exception e) {
            renderError(ReturnCodes.Code.ERROR, e.toString())
            log.error("statement API Error:" + e.toString(), e)
            return
        }
    } // retrieveTransactions()

}



